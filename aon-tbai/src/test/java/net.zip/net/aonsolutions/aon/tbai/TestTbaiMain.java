//package net.aonsolutions.aon.tbai;
//
//import static Toolkit.ConsoleToolkit.end_section;
//import static Toolkit.ConsoleToolkit.log;
//import static Toolkit.ConsoleToolkit.start_section;
//import static org.junit.Assert.fail;
//
//import java.io.InputStream;
//import java.util.ArrayList;
//import java.util.Arrays;
//import java.util.List;
//
//import org.junit.jupiter.api.Test;
//
////import com.esferalia.aon.occam.api.model.type.Country;
//
//import net.aonsolutions.aon.tbai.TbaiMain;
//import net.aonsolutions.aon.tbai.beans.invoice.TbaiEmisionInvoice;
//import net.aonsolutions.aon.tbai.beans.invoice.TbaiEmisionInvoice.TbaiEmisionInvoiceBuilder;
//import net.aonsolutions.aon.tbai.beans.invoice.parts.Entity;
//import net.aonsolutions.aon.tbai.beans.invoice.parts.InvoiceDetails;
//import net.aonsolutions.aon.tbai.beans.invoice.parts.RectificationData;
//
//class TestTbaiMain {
////
////	@Test
////	void invoice_emission_test() {
////		
////		try{
////			InputStream is = TestTbaiMain.class.getResourceAsStream("factura.json");
////			TbaiMain.json_to_invoice(is);
////		}catch(Exception e) {
////			e.printStackTrace();
////			fail("Unexpepected Extension " + e);
////		}
////	}
////
////	@Test
////	void invoice_emission_test_2() {
////		
////		try{
////			start_section("Ticketbai registry");
////			log(">> status", "starting....");
////			TbaiEmisionInvoiceBuilder builder = new TbaiEmisionInvoiceBuilder(); 	
////			
////			Entity sender  = 	new Entity("58658371X", "Aketza", Country.ES, "type 1", "1", "01470", "Federico Barrenegoa 25, 4A, Amurrio");
////			Entity receiver  = 	new Entity("12323032R", "Juan Urtado", Country.ES, "type 1", "1", "01470", "Oceano Pacifico 21, 7A, Vitoria");
////			Entity aon  = 		new Entity("10101010T", "AON SOLUTIION S.L", Country.ES, "type 2", "1", "01010", "Landaberde kalea 9,Vitoria");
////			
////			RectificationData rectification = new RectificationData("001", "tipo1", 199.99, 20.05, 1.25, "CCC");
////			List<InvoiceDetails> details = new ArrayList<InvoiceDetails>();
////			
////			
////			
////			for (int i = 0; i < 20; i++) {
////				//InvoiceDetails det = new InvoiceDetails(, detail_amount, detail_unit_amount, detail_discount, detail_total_amount)
////			}
////			
////			builder
////			.setSender(sender)
////			.setRecievers(Arrays.asList(new Entity[]{receiver}))
////			.setNumber("478329823")
////			.setSeries("AAA")
////			.setDeveloper_entity(aon)
////			.setTotal_amount(120512.00)
////			.setDevice_number("1278263423")
////			.setSimplified(true)
////			.setExternal(true)
////			.setMultiple(false)
////			.setReplace_simplified(true)
////			.setSupported_retention(150.75)
////			.setRectification(rectification)
////			.setSoftware_name("AON APPLICATION")
////			.setSoftware_version("3.2")
////			.setVersionTBAI("1.2")
////			.setDetails(details)
////			;
////			
////			TbaiEmisionInvoice invoice = builder.build();
////			
////			log(">> status", "DONE.");
////			TbaiMain.tbai_emision(invoice);
////		end_section();
////		}catch(Exception e) {
////			e.printStackTrace();
////			fail("Unexpepected Extension " + e);
////		}
////	}
//}
