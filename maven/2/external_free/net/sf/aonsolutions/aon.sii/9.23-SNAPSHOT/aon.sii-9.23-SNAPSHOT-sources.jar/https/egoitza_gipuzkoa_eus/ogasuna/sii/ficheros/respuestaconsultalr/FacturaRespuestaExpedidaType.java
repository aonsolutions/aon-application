
package https.egoitza_gipuzkoa_eus.ogasuna.sii.ficheros.respuestaconsultalr;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import https.egoitza_gipuzkoa_eus.ogasuna.sii.ficheros.suministroinformacion.CompletaSinDestinatarioType;
import https.egoitza_gipuzkoa_eus.ogasuna.sii.ficheros.suministroinformacion.CuponType;
import https.egoitza_gipuzkoa_eus.ogasuna.sii.ficheros.suministroinformacion.DatosInmuebleType;
import https.egoitza_gipuzkoa_eus.ogasuna.sii.ficheros.suministroinformacion.EmitidaPorTercerosType;
import https.egoitza_gipuzkoa_eus.ogasuna.sii.ficheros.suministroinformacion.PersonaFisicaJuridicaType;
import https.egoitza_gipuzkoa_eus.ogasuna.sii.ficheros.suministroinformacion.TipoConDesgloseType;
import https.egoitza_gipuzkoa_eus.ogasuna.sii.ficheros.suministroinformacion.TipoSinDesgloseType;
import https.egoitza_gipuzkoa_eus.ogasuna.sii.ficheros.suministroinformacion.VariosDestinatariosType;


/**
 *  Apunte correspondiente al libro de facturas expedidas. 
 * 
 * <p>Java class for FacturaRespuestaExpedidaType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="FacturaRespuestaExpedidaType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{https://egoitza.gipuzkoa.eus/ogasuna/sii/ficheros/RespuestaConsultaLR.xsd}FacturaRespuestaType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="DatosInmueble" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="DetalleInmueble" type="{https://egoitza.gipuzkoa.eus/ogasuna/sii/ficheros/SuministroInformacion.xsd}DatosInmuebleType" maxOccurs="15"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ImporteTransmisionInmueblesSujetoAIVA" type="{https://egoitza.gipuzkoa.eus/ogasuna/sii/ficheros/SuministroInformacion.xsd}ImporteSgn12.2Type" minOccurs="0"/&gt;
 *         &lt;element name="EmitidaPorTercerosODestinatario" type="{https://egoitza.gipuzkoa.eus/ogasuna/sii/ficheros/SuministroInformacion.xsd}EmitidaPorTercerosType" minOccurs="0"/&gt;
 *         &lt;element name="FacturacionDispAdicionalTerceraYsextayDelMercadoOrganizadoDelGas" type="{https://egoitza.gipuzkoa.eus/ogasuna/sii/ficheros/SuministroInformacion.xsd}EmitidaPorTercerosType" minOccurs="0"/&gt;
 *         &lt;element name="VariosDestinatarios" type="{https://egoitza.gipuzkoa.eus/ogasuna/sii/ficheros/SuministroInformacion.xsd}VariosDestinatariosType" minOccurs="0"/&gt;
 *         &lt;element name="Cupon" type="{https://egoitza.gipuzkoa.eus/ogasuna/sii/ficheros/SuministroInformacion.xsd}CuponType" minOccurs="0"/&gt;
 *         &lt;element name="FacturaSinIdentifDestinatarioAritculo6.1.d" type="{https://egoitza.gipuzkoa.eus/ogasuna/sii/ficheros/SuministroInformacion.xsd}CompletaSinDestinatarioType" minOccurs="0"/&gt;
 *         &lt;element name="Contraparte" type="{https://egoitza.gipuzkoa.eus/ogasuna/sii/ficheros/SuministroInformacion.xsd}PersonaFisicaJuridicaType" minOccurs="0"/&gt;
 *         &lt;element name="TipoDesglose"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;choice&gt;
 *                   &lt;element name="DesgloseFactura" type="{https://egoitza.gipuzkoa.eus/ogasuna/sii/ficheros/SuministroInformacion.xsd}TipoSinDesgloseType"/&gt;
 *                   &lt;element name="DesgloseTipoOperacion" type="{https://egoitza.gipuzkoa.eus/ogasuna/sii/ficheros/SuministroInformacion.xsd}TipoConDesgloseType"/&gt;
 *                 &lt;/choice&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Cobros" type="{https://egoitza.gipuzkoa.eus/ogasuna/sii/ficheros/RespuestaConsultaLR.xsd}FacturaARType"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FacturaRespuestaExpedidaType", propOrder = {
    "datosInmueble",
    "importeTransmisionInmueblesSujetoAIVA",
    "emitidaPorTercerosODestinatario",
    "facturacionDispAdicionalTerceraYsextayDelMercadoOrganizadoDelGas",
    "variosDestinatarios",
    "cupon",
    "facturaSinIdentifDestinatarioAritculo61D",
    "contraparte",
    "tipoDesglose",
    "cobros"
})
public class FacturaRespuestaExpedidaType
    extends FacturaRespuestaType
{

    @XmlElement(name = "DatosInmueble")
    protected FacturaRespuestaExpedidaType.DatosInmueble datosInmueble;
    @XmlElement(name = "ImporteTransmisionInmueblesSujetoAIVA")
    protected String importeTransmisionInmueblesSujetoAIVA;
    @XmlElement(name = "EmitidaPorTercerosODestinatario")
    @XmlSchemaType(name = "string")
    protected EmitidaPorTercerosType emitidaPorTercerosODestinatario;
    @XmlElement(name = "FacturacionDispAdicionalTerceraYsextayDelMercadoOrganizadoDelGas")
    @XmlSchemaType(name = "string")
    protected EmitidaPorTercerosType facturacionDispAdicionalTerceraYsextayDelMercadoOrganizadoDelGas;
    @XmlElement(name = "VariosDestinatarios")
    @XmlSchemaType(name = "string")
    protected VariosDestinatariosType variosDestinatarios;
    @XmlElement(name = "Cupon")
    @XmlSchemaType(name = "string")
    protected CuponType cupon;
    @XmlElement(name = "FacturaSinIdentifDestinatarioAritculo6.1.d")
    @XmlSchemaType(name = "string")
    protected CompletaSinDestinatarioType facturaSinIdentifDestinatarioAritculo61D;
    @XmlElement(name = "Contraparte")
    protected PersonaFisicaJuridicaType contraparte;
    @XmlElement(name = "TipoDesglose", required = true)
    protected FacturaRespuestaExpedidaType.TipoDesglose tipoDesglose;
    @XmlElement(name = "Cobros", required = true)
    @XmlSchemaType(name = "string")
    protected FacturaARType cobros;

    /**
     * Gets the value of the datosInmueble property.
     * 
     * @return
     *     possible object is
     *     {@link FacturaRespuestaExpedidaType.DatosInmueble }
     *     
     */
    public FacturaRespuestaExpedidaType.DatosInmueble getDatosInmueble() {
        return datosInmueble;
    }

    /**
     * Sets the value of the datosInmueble property.
     * 
     * @param value
     *     allowed object is
     *     {@link FacturaRespuestaExpedidaType.DatosInmueble }
     *     
     */
    public void setDatosInmueble(FacturaRespuestaExpedidaType.DatosInmueble value) {
        this.datosInmueble = value;
    }

    /**
     * Gets the value of the importeTransmisionInmueblesSujetoAIVA property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getImporteTransmisionInmueblesSujetoAIVA() {
        return importeTransmisionInmueblesSujetoAIVA;
    }

    /**
     * Sets the value of the importeTransmisionInmueblesSujetoAIVA property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setImporteTransmisionInmueblesSujetoAIVA(String value) {
        this.importeTransmisionInmueblesSujetoAIVA = value;
    }

    /**
     * Gets the value of the emitidaPorTercerosODestinatario property.
     * 
     * @return
     *     possible object is
     *     {@link EmitidaPorTercerosType }
     *     
     */
    public EmitidaPorTercerosType getEmitidaPorTercerosODestinatario() {
        return emitidaPorTercerosODestinatario;
    }

    /**
     * Sets the value of the emitidaPorTercerosODestinatario property.
     * 
     * @param value
     *     allowed object is
     *     {@link EmitidaPorTercerosType }
     *     
     */
    public void setEmitidaPorTercerosODestinatario(EmitidaPorTercerosType value) {
        this.emitidaPorTercerosODestinatario = value;
    }

    /**
     * Gets the value of the facturacionDispAdicionalTerceraYsextayDelMercadoOrganizadoDelGas property.
     * 
     * @return
     *     possible object is
     *     {@link EmitidaPorTercerosType }
     *     
     */
    public EmitidaPorTercerosType getFacturacionDispAdicionalTerceraYsextayDelMercadoOrganizadoDelGas() {
        return facturacionDispAdicionalTerceraYsextayDelMercadoOrganizadoDelGas;
    }

    /**
     * Sets the value of the facturacionDispAdicionalTerceraYsextayDelMercadoOrganizadoDelGas property.
     * 
     * @param value
     *     allowed object is
     *     {@link EmitidaPorTercerosType }
     *     
     */
    public void setFacturacionDispAdicionalTerceraYsextayDelMercadoOrganizadoDelGas(EmitidaPorTercerosType value) {
        this.facturacionDispAdicionalTerceraYsextayDelMercadoOrganizadoDelGas = value;
    }

    /**
     * Gets the value of the variosDestinatarios property.
     * 
     * @return
     *     possible object is
     *     {@link VariosDestinatariosType }
     *     
     */
    public VariosDestinatariosType getVariosDestinatarios() {
        return variosDestinatarios;
    }

    /**
     * Sets the value of the variosDestinatarios property.
     * 
     * @param value
     *     allowed object is
     *     {@link VariosDestinatariosType }
     *     
     */
    public void setVariosDestinatarios(VariosDestinatariosType value) {
        this.variosDestinatarios = value;
    }

    /**
     * Gets the value of the cupon property.
     * 
     * @return
     *     possible object is
     *     {@link CuponType }
     *     
     */
    public CuponType getCupon() {
        return cupon;
    }

    /**
     * Sets the value of the cupon property.
     * 
     * @param value
     *     allowed object is
     *     {@link CuponType }
     *     
     */
    public void setCupon(CuponType value) {
        this.cupon = value;
    }

    /**
     * Gets the value of the facturaSinIdentifDestinatarioAritculo61D property.
     * 
     * @return
     *     possible object is
     *     {@link CompletaSinDestinatarioType }
     *     
     */
    public CompletaSinDestinatarioType getFacturaSinIdentifDestinatarioAritculo61D() {
        return facturaSinIdentifDestinatarioAritculo61D;
    }

    /**
     * Sets the value of the facturaSinIdentifDestinatarioAritculo61D property.
     * 
     * @param value
     *     allowed object is
     *     {@link CompletaSinDestinatarioType }
     *     
     */
    public void setFacturaSinIdentifDestinatarioAritculo61D(CompletaSinDestinatarioType value) {
        this.facturaSinIdentifDestinatarioAritculo61D = value;
    }

    /**
     * Gets the value of the contraparte property.
     * 
     * @return
     *     possible object is
     *     {@link PersonaFisicaJuridicaType }
     *     
     */
    public PersonaFisicaJuridicaType getContraparte() {
        return contraparte;
    }

    /**
     * Sets the value of the contraparte property.
     * 
     * @param value
     *     allowed object is
     *     {@link PersonaFisicaJuridicaType }
     *     
     */
    public void setContraparte(PersonaFisicaJuridicaType value) {
        this.contraparte = value;
    }

    /**
     * Gets the value of the tipoDesglose property.
     * 
     * @return
     *     possible object is
     *     {@link FacturaRespuestaExpedidaType.TipoDesglose }
     *     
     */
    public FacturaRespuestaExpedidaType.TipoDesglose getTipoDesglose() {
        return tipoDesglose;
    }

    /**
     * Sets the value of the tipoDesglose property.
     * 
     * @param value
     *     allowed object is
     *     {@link FacturaRespuestaExpedidaType.TipoDesglose }
     *     
     */
    public void setTipoDesglose(FacturaRespuestaExpedidaType.TipoDesglose value) {
        this.tipoDesglose = value;
    }

    /**
     * Gets the value of the cobros property.
     * 
     * @return
     *     possible object is
     *     {@link FacturaARType }
     *     
     */
    public FacturaARType getCobros() {
        return cobros;
    }

    /**
     * Sets the value of the cobros property.
     * 
     * @param value
     *     allowed object is
     *     {@link FacturaARType }
     *     
     */
    public void setCobros(FacturaARType value) {
        this.cobros = value;
    }


    /**
     * Desglose de inmuebles
     * 
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="DetalleInmueble" type="{https://egoitza.gipuzkoa.eus/ogasuna/sii/ficheros/SuministroInformacion.xsd}DatosInmuebleType" maxOccurs="15"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "detalleInmueble"
    })
    public static class DatosInmueble {

        @XmlElement(name = "DetalleInmueble", required = true)
        protected List<DatosInmuebleType> detalleInmueble;

        /**
         * Gets the value of the detalleInmueble property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the detalleInmueble property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getDetalleInmueble().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link DatosInmuebleType }
         * 
         * 
         */
        public List<DatosInmuebleType> getDetalleInmueble() {
            if (detalleInmueble == null) {
                detalleInmueble = new ArrayList<DatosInmuebleType>();
            }
            return this.detalleInmueble;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;choice&gt;
     *         &lt;element name="DesgloseFactura" type="{https://egoitza.gipuzkoa.eus/ogasuna/sii/ficheros/SuministroInformacion.xsd}TipoSinDesgloseType"/&gt;
     *         &lt;element name="DesgloseTipoOperacion" type="{https://egoitza.gipuzkoa.eus/ogasuna/sii/ficheros/SuministroInformacion.xsd}TipoConDesgloseType"/&gt;
     *       &lt;/choice&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "desgloseFactura",
        "desgloseTipoOperacion"
    })
    public static class TipoDesglose {

        @XmlElement(name = "DesgloseFactura")
        protected TipoSinDesgloseType desgloseFactura;
        @XmlElement(name = "DesgloseTipoOperacion")
        protected TipoConDesgloseType desgloseTipoOperacion;

        /**
         * Gets the value of the desgloseFactura property.
         * 
         * @return
         *     possible object is
         *     {@link TipoSinDesgloseType }
         *     
         */
        public TipoSinDesgloseType getDesgloseFactura() {
            return desgloseFactura;
        }

        /**
         * Sets the value of the desgloseFactura property.
         * 
         * @param value
         *     allowed object is
         *     {@link TipoSinDesgloseType }
         *     
         */
        public void setDesgloseFactura(TipoSinDesgloseType value) {
            this.desgloseFactura = value;
        }

        /**
         * Gets the value of the desgloseTipoOperacion property.
         * 
         * @return
         *     possible object is
         *     {@link TipoConDesgloseType }
         *     
         */
        public TipoConDesgloseType getDesgloseTipoOperacion() {
            return desgloseTipoOperacion;
        }

        /**
         * Sets the value of the desgloseTipoOperacion property.
         * 
         * @param value
         *     allowed object is
         *     {@link TipoConDesgloseType }
         *     
         */
        public void setDesgloseTipoOperacion(TipoConDesgloseType value) {
            this.desgloseTipoOperacion = value;
        }

    }

}
