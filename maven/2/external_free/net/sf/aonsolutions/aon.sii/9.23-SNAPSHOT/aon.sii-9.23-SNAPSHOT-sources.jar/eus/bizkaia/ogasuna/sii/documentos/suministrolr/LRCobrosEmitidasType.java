
package eus.bizkaia.ogasuna.sii.documentos.suministrolr;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import eus.bizkaia.ogasuna.sii.documentos.suministroinformacion.CobrosType;
import eus.bizkaia.ogasuna.sii.documentos.suministroinformacion.IDFacturaExpedidaBCType;


/**
 * <p>Java class for LRCobrosEmitidasType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="LRCobrosEmitidasType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="IDFactura" type="{http://www.bizkaia.eus/ogasuna/sii/documentos/SuministroInformacion.xsd}IDFacturaExpedidaBCType"/&gt;
 *         &lt;element name="Cobros" type="{http://www.bizkaia.eus/ogasuna/sii/documentos/SuministroInformacion.xsd}CobrosType"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "LRCobrosEmitidasType", propOrder = {
    "idFactura",
    "cobros"
})
public class LRCobrosEmitidasType {

    @XmlElement(name = "IDFactura", required = true)
    protected IDFacturaExpedidaBCType idFactura;
    @XmlElement(name = "Cobros", required = true)
    protected CobrosType cobros;

    /**
     * Gets the value of the idFactura property.
     * 
     * @return
     *     possible object is
     *     {@link IDFacturaExpedidaBCType }
     *     
     */
    public IDFacturaExpedidaBCType getIDFactura() {
        return idFactura;
    }

    /**
     * Sets the value of the idFactura property.
     * 
     * @param value
     *     allowed object is
     *     {@link IDFacturaExpedidaBCType }
     *     
     */
    public void setIDFactura(IDFacturaExpedidaBCType value) {
        this.idFactura = value;
    }

    /**
     * Gets the value of the cobros property.
     * 
     * @return
     *     possible object is
     *     {@link CobrosType }
     *     
     */
    public CobrosType getCobros() {
        return cobros;
    }

    /**
     * Sets the value of the cobros property.
     * 
     * @param value
     *     allowed object is
     *     {@link CobrosType }
     *     
     */
    public void setCobros(CobrosType value) {
        this.cobros = value;
    }

}
