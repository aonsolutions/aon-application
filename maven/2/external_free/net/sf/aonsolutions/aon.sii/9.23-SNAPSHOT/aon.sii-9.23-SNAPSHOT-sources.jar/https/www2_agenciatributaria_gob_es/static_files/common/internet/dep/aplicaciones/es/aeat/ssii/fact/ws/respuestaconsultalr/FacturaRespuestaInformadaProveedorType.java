
package https.www2_agenciatributaria_gob_es.static_files.common.internet.dep.aplicaciones.es.aeat.ssii.fact.ws.respuestaconsultalr;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import https.www2_agenciatributaria_gob_es.static_files.common.internet.dep.aplicaciones.es.aeat.ssii.fact.ws.suministroinformacion.CompletaSinDestinatarioType;
import https.www2_agenciatributaria_gob_es.static_files.common.internet.dep.aplicaciones.es.aeat.ssii.fact.ws.suministroinformacion.CuponType;
import https.www2_agenciatributaria_gob_es.static_files.common.internet.dep.aplicaciones.es.aeat.ssii.fact.ws.suministroinformacion.DatosInmuebleType;
import https.www2_agenciatributaria_gob_es.static_files.common.internet.dep.aplicaciones.es.aeat.ssii.fact.ws.suministroinformacion.EmitidaPorTercerosType;
import https.www2_agenciatributaria_gob_es.static_files.common.internet.dep.aplicaciones.es.aeat.ssii.fact.ws.suministroinformacion.TipoConDesgloseType;
import https.www2_agenciatributaria_gob_es.static_files.common.internet.dep.aplicaciones.es.aeat.ssii.fact.ws.suministroinformacion.TipoSinDesgloseType;
import https.www2_agenciatributaria_gob_es.static_files.common.internet.dep.aplicaciones.es.aeat.ssii.fact.ws.suministroinformacion.VariosDestinatariosType;


/**
 *  Apunte correspondiente al libro de facturas expedidas. 
 * 
 * <p>Java class for FacturaRespuestaInformadaProveedorType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="FacturaRespuestaInformadaProveedorType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{https://www2.agenciatributaria.gob.es/static_files/common/internet/dep/aplicaciones/es/aeat/ssii/fact/ws/RespuestaConsultaLR.xsd}FacturaRespuestaType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="DatosInmueble" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="DetalleInmueble" type="{https://www2.agenciatributaria.gob.es/static_files/common/internet/dep/aplicaciones/es/aeat/ssii/fact/ws/SuministroInformacion.xsd}DatosInmuebleType" maxOccurs="15"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ImporteTransmisionInmueblesSujetoAIVA" type="{https://www2.agenciatributaria.gob.es/static_files/common/internet/dep/aplicaciones/es/aeat/ssii/fact/ws/SuministroInformacion.xsd}ImporteSgn12.2Type" minOccurs="0"/&gt;
 *         &lt;element name="EmitidaPorTercerosODestinatario" type="{https://www2.agenciatributaria.gob.es/static_files/common/internet/dep/aplicaciones/es/aeat/ssii/fact/ws/SuministroInformacion.xsd}EmitidaPorTercerosType" minOccurs="0"/&gt;
 *         &lt;element name="FacturacionDispAdicionalTerceraYsextayDelMercadoOrganizadoDelGas" type="{https://www2.agenciatributaria.gob.es/static_files/common/internet/dep/aplicaciones/es/aeat/ssii/fact/ws/SuministroInformacion.xsd}EmitidaPorTercerosType" minOccurs="0"/&gt;
 *         &lt;element name="VariosDestinatarios" type="{https://www2.agenciatributaria.gob.es/static_files/common/internet/dep/aplicaciones/es/aeat/ssii/fact/ws/SuministroInformacion.xsd}VariosDestinatariosType" minOccurs="0"/&gt;
 *         &lt;element name="Cupon" type="{https://www2.agenciatributaria.gob.es/static_files/common/internet/dep/aplicaciones/es/aeat/ssii/fact/ws/SuministroInformacion.xsd}CuponType" minOccurs="0"/&gt;
 *         &lt;element name="FacturaSinIdentifDestinatarioAritculo6.1.d" type="{https://www2.agenciatributaria.gob.es/static_files/common/internet/dep/aplicaciones/es/aeat/ssii/fact/ws/SuministroInformacion.xsd}CompletaSinDestinatarioType" minOccurs="0"/&gt;
 *         &lt;element name="TipoDesglose"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;choice&gt;
 *                   &lt;element name="DesgloseFactura" type="{https://www2.agenciatributaria.gob.es/static_files/common/internet/dep/aplicaciones/es/aeat/ssii/fact/ws/SuministroInformacion.xsd}TipoSinDesgloseType"/&gt;
 *                   &lt;element name="DesgloseTipoOperacion" type="{https://www2.agenciatributaria.gob.es/static_files/common/internet/dep/aplicaciones/es/aeat/ssii/fact/ws/SuministroInformacion.xsd}TipoConDesgloseType"/&gt;
 *                 &lt;/choice&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Cobros" type="{https://www2.agenciatributaria.gob.es/static_files/common/internet/dep/aplicaciones/es/aeat/ssii/fact/ws/RespuestaConsultaLR.xsd}FacturaARType"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FacturaRespuestaInformadaProveedorType", propOrder = {
    "datosInmueble",
    "importeTransmisionInmueblesSujetoAIVA",
    "emitidaPorTercerosODestinatario",
    "facturacionDispAdicionalTerceraYsextayDelMercadoOrganizadoDelGas",
    "variosDestinatarios",
    "cupon",
    "facturaSinIdentifDestinatarioAritculo61D",
    "tipoDesglose",
    "cobros"
})
public class FacturaRespuestaInformadaProveedorType
    extends FacturaRespuestaType
{

    @XmlElement(name = "DatosInmueble")
    protected FacturaRespuestaInformadaProveedorType.DatosInmueble datosInmueble;
    @XmlElement(name = "ImporteTransmisionInmueblesSujetoAIVA")
    protected String importeTransmisionInmueblesSujetoAIVA;
    @XmlElement(name = "EmitidaPorTercerosODestinatario")
    @XmlSchemaType(name = "string")
    protected EmitidaPorTercerosType emitidaPorTercerosODestinatario;
    @XmlElement(name = "FacturacionDispAdicionalTerceraYsextayDelMercadoOrganizadoDelGas")
    @XmlSchemaType(name = "string")
    protected EmitidaPorTercerosType facturacionDispAdicionalTerceraYsextayDelMercadoOrganizadoDelGas;
    @XmlElement(name = "VariosDestinatarios")
    @XmlSchemaType(name = "string")
    protected VariosDestinatariosType variosDestinatarios;
    @XmlElement(name = "Cupon")
    @XmlSchemaType(name = "string")
    protected CuponType cupon;
    @XmlElement(name = "FacturaSinIdentifDestinatarioAritculo6.1.d")
    @XmlSchemaType(name = "string")
    protected CompletaSinDestinatarioType facturaSinIdentifDestinatarioAritculo61D;
    @XmlElement(name = "TipoDesglose", required = true)
    protected FacturaRespuestaInformadaProveedorType.TipoDesglose tipoDesglose;
    @XmlElement(name = "Cobros", required = true)
    @XmlSchemaType(name = "string")
    protected FacturaARType cobros;

    /**
     * Gets the value of the datosInmueble property.
     * 
     * @return
     *     possible object is
     *     {@link FacturaRespuestaInformadaProveedorType.DatosInmueble }
     *     
     */
    public FacturaRespuestaInformadaProveedorType.DatosInmueble getDatosInmueble() {
        return datosInmueble;
    }

    /**
     * Sets the value of the datosInmueble property.
     * 
     * @param value
     *     allowed object is
     *     {@link FacturaRespuestaInformadaProveedorType.DatosInmueble }
     *     
     */
    public void setDatosInmueble(FacturaRespuestaInformadaProveedorType.DatosInmueble value) {
        this.datosInmueble = value;
    }

    /**
     * Gets the value of the importeTransmisionInmueblesSujetoAIVA property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getImporteTransmisionInmueblesSujetoAIVA() {
        return importeTransmisionInmueblesSujetoAIVA;
    }

    /**
     * Sets the value of the importeTransmisionInmueblesSujetoAIVA property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setImporteTransmisionInmueblesSujetoAIVA(String value) {
        this.importeTransmisionInmueblesSujetoAIVA = value;
    }

    /**
     * Gets the value of the emitidaPorTercerosODestinatario property.
     * 
     * @return
     *     possible object is
     *     {@link EmitidaPorTercerosType }
     *     
     */
    public EmitidaPorTercerosType getEmitidaPorTercerosODestinatario() {
        return emitidaPorTercerosODestinatario;
    }

    /**
     * Sets the value of the emitidaPorTercerosODestinatario property.
     * 
     * @param value
     *     allowed object is
     *     {@link EmitidaPorTercerosType }
     *     
     */
    public void setEmitidaPorTercerosODestinatario(EmitidaPorTercerosType value) {
        this.emitidaPorTercerosODestinatario = value;
    }

    /**
     * Gets the value of the facturacionDispAdicionalTerceraYsextayDelMercadoOrganizadoDelGas property.
     * 
     * @return
     *     possible object is
     *     {@link EmitidaPorTercerosType }
     *     
     */
    public EmitidaPorTercerosType getFacturacionDispAdicionalTerceraYsextayDelMercadoOrganizadoDelGas() {
        return facturacionDispAdicionalTerceraYsextayDelMercadoOrganizadoDelGas;
    }

    /**
     * Sets the value of the facturacionDispAdicionalTerceraYsextayDelMercadoOrganizadoDelGas property.
     * 
     * @param value
     *     allowed object is
     *     {@link EmitidaPorTercerosType }
     *     
     */
    public void setFacturacionDispAdicionalTerceraYsextayDelMercadoOrganizadoDelGas(EmitidaPorTercerosType value) {
        this.facturacionDispAdicionalTerceraYsextayDelMercadoOrganizadoDelGas = value;
    }

    /**
     * Gets the value of the variosDestinatarios property.
     * 
     * @return
     *     possible object is
     *     {@link VariosDestinatariosType }
     *     
     */
    public VariosDestinatariosType getVariosDestinatarios() {
        return variosDestinatarios;
    }

    /**
     * Sets the value of the variosDestinatarios property.
     * 
     * @param value
     *     allowed object is
     *     {@link VariosDestinatariosType }
     *     
     */
    public void setVariosDestinatarios(VariosDestinatariosType value) {
        this.variosDestinatarios = value;
    }

    /**
     * Gets the value of the cupon property.
     * 
     * @return
     *     possible object is
     *     {@link CuponType }
     *     
     */
    public CuponType getCupon() {
        return cupon;
    }

    /**
     * Sets the value of the cupon property.
     * 
     * @param value
     *     allowed object is
     *     {@link CuponType }
     *     
     */
    public void setCupon(CuponType value) {
        this.cupon = value;
    }

    /**
     * Gets the value of the facturaSinIdentifDestinatarioAritculo61D property.
     * 
     * @return
     *     possible object is
     *     {@link CompletaSinDestinatarioType }
     *     
     */
    public CompletaSinDestinatarioType getFacturaSinIdentifDestinatarioAritculo61D() {
        return facturaSinIdentifDestinatarioAritculo61D;
    }

    /**
     * Sets the value of the facturaSinIdentifDestinatarioAritculo61D property.
     * 
     * @param value
     *     allowed object is
     *     {@link CompletaSinDestinatarioType }
     *     
     */
    public void setFacturaSinIdentifDestinatarioAritculo61D(CompletaSinDestinatarioType value) {
        this.facturaSinIdentifDestinatarioAritculo61D = value;
    }

    /**
     * Gets the value of the tipoDesglose property.
     * 
     * @return
     *     possible object is
     *     {@link FacturaRespuestaInformadaProveedorType.TipoDesglose }
     *     
     */
    public FacturaRespuestaInformadaProveedorType.TipoDesglose getTipoDesglose() {
        return tipoDesglose;
    }

    /**
     * Sets the value of the tipoDesglose property.
     * 
     * @param value
     *     allowed object is
     *     {@link FacturaRespuestaInformadaProveedorType.TipoDesglose }
     *     
     */
    public void setTipoDesglose(FacturaRespuestaInformadaProveedorType.TipoDesglose value) {
        this.tipoDesglose = value;
    }

    /**
     * Gets the value of the cobros property.
     * 
     * @return
     *     possible object is
     *     {@link FacturaARType }
     *     
     */
    public FacturaARType getCobros() {
        return cobros;
    }

    /**
     * Sets the value of the cobros property.
     * 
     * @param value
     *     allowed object is
     *     {@link FacturaARType }
     *     
     */
    public void setCobros(FacturaARType value) {
        this.cobros = value;
    }


    /**
     * Desglose de inmuebles
     * 
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="DetalleInmueble" type="{https://www2.agenciatributaria.gob.es/static_files/common/internet/dep/aplicaciones/es/aeat/ssii/fact/ws/SuministroInformacion.xsd}DatosInmuebleType" maxOccurs="15"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "detalleInmueble"
    })
    public static class DatosInmueble {

        @XmlElement(name = "DetalleInmueble", required = true)
        protected List<DatosInmuebleType> detalleInmueble;

        /**
         * Gets the value of the detalleInmueble property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the detalleInmueble property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getDetalleInmueble().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link DatosInmuebleType }
         * 
         * 
         */
        public List<DatosInmuebleType> getDetalleInmueble() {
            if (detalleInmueble == null) {
                detalleInmueble = new ArrayList<DatosInmuebleType>();
            }
            return this.detalleInmueble;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;choice&gt;
     *         &lt;element name="DesgloseFactura" type="{https://www2.agenciatributaria.gob.es/static_files/common/internet/dep/aplicaciones/es/aeat/ssii/fact/ws/SuministroInformacion.xsd}TipoSinDesgloseType"/&gt;
     *         &lt;element name="DesgloseTipoOperacion" type="{https://www2.agenciatributaria.gob.es/static_files/common/internet/dep/aplicaciones/es/aeat/ssii/fact/ws/SuministroInformacion.xsd}TipoConDesgloseType"/&gt;
     *       &lt;/choice&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "desgloseFactura",
        "desgloseTipoOperacion"
    })
    public static class TipoDesglose {

        @XmlElement(name = "DesgloseFactura")
        protected TipoSinDesgloseType desgloseFactura;
        @XmlElement(name = "DesgloseTipoOperacion")
        protected TipoConDesgloseType desgloseTipoOperacion;

        /**
         * Gets the value of the desgloseFactura property.
         * 
         * @return
         *     possible object is
         *     {@link TipoSinDesgloseType }
         *     
         */
        public TipoSinDesgloseType getDesgloseFactura() {
            return desgloseFactura;
        }

        /**
         * Sets the value of the desgloseFactura property.
         * 
         * @param value
         *     allowed object is
         *     {@link TipoSinDesgloseType }
         *     
         */
        public void setDesgloseFactura(TipoSinDesgloseType value) {
            this.desgloseFactura = value;
        }

        /**
         * Gets the value of the desgloseTipoOperacion property.
         * 
         * @return
         *     possible object is
         *     {@link TipoConDesgloseType }
         *     
         */
        public TipoConDesgloseType getDesgloseTipoOperacion() {
            return desgloseTipoOperacion;
        }

        /**
         * Sets the value of the desgloseTipoOperacion property.
         * 
         * @param value
         *     allowed object is
         *     {@link TipoConDesgloseType }
         *     
         */
        public void setDesgloseTipoOperacion(TipoConDesgloseType value) {
            this.desgloseTipoOperacion = value;
        }

    }

}
