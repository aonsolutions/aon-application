
package https.www2_agenciatributaria_gob_es.static_files.common.internet.dep.aplicaciones.es.aeat.ssii.fact.ws.suministroinformacion;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import https.www2_agenciatributaria_gob_es.static_files.common.internet.dep.aplicaciones.es.aeat.ssii.fact.ws.consultalr.ConsultaLRFactInformadasAgrupadasClienteType;
import https.www2_agenciatributaria_gob_es.static_files.common.internet.dep.aplicaciones.es.aeat.ssii.fact.ws.consultalr.ConsultaLRFactInformadasClienteType;
import https.www2_agenciatributaria_gob_es.static_files.common.internet.dep.aplicaciones.es.aeat.ssii.fact.ws.respuestaconsultalr.RespuestaConsultaLRFacturasAgrupadasClienteType;
import https.www2_agenciatributaria_gob_es.static_files.common.internet.dep.aplicaciones.es.aeat.ssii.fact.ws.respuestaconsultalr.RespuestaConsultaLRFacturasClienteType;


/**
 *  Sii - Suministro Inmediato de Informaci�n, compuesto por datos de contexto y una secuencia de 1 o m�s registros. 
 * 
 * <p>Java class for ConsultaInformacionCliente complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ConsultaInformacionCliente"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Cabecera" type="{https://www2.agenciatributaria.gob.es/static_files/common/internet/dep/aplicaciones/es/aeat/ssii/fact/ws/SuministroInformacion.xsd}CabeceraConsultaSiiCliente"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ConsultaInformacionCliente", propOrder = {
    "cabecera"
})
@XmlSeeAlso({
    ConsultaLRFactInformadasClienteType.class,
    ConsultaLRFactInformadasAgrupadasClienteType.class,
    RespuestaConsultaLRFacturasClienteType.class,
    RespuestaConsultaLRFacturasAgrupadasClienteType.class
})
public class ConsultaInformacionCliente {

    @XmlElement(name = "Cabecera", required = true)
    protected CabeceraConsultaSiiCliente cabecera;

    /**
     * Gets the value of the cabecera property.
     * 
     * @return
     *     possible object is
     *     {@link CabeceraConsultaSiiCliente }
     *     
     */
    public CabeceraConsultaSiiCliente getCabecera() {
        return cabecera;
    }

    /**
     * Sets the value of the cabecera property.
     * 
     * @param value
     *     allowed object is
     *     {@link CabeceraConsultaSiiCliente }
     *     
     */
    public void setCabecera(CabeceraConsultaSiiCliente value) {
        this.cabecera = value;
    }

}
