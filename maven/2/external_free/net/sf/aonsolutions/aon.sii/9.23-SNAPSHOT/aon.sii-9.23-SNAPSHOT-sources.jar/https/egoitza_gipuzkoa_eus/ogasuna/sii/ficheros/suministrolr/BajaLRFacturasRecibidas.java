
package https.egoitza_gipuzkoa_eus.ogasuna.sii.ficheros.suministrolr;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import https.egoitza_gipuzkoa_eus.ogasuna.sii.ficheros.suministroinformacion.SuministroInformacionBaja;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{https://egoitza.gipuzkoa.eus/ogasuna/sii/ficheros/SuministroInformacion.xsd}SuministroInformacionBaja"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="RegistroLRBajaRecibidas" type="{https://egoitza.gipuzkoa.eus/ogasuna/sii/ficheros/SuministroLR.xsd}LRBajaRecibidasType" maxOccurs="10000"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "registroLRBajaRecibidas"
})
@XmlRootElement(name = "BajaLRFacturasRecibidas")
public class BajaLRFacturasRecibidas
    extends SuministroInformacionBaja
{

    @XmlElement(name = "RegistroLRBajaRecibidas", required = true)
    protected List<LRBajaRecibidasType> registroLRBajaRecibidas;

    /**
     * Gets the value of the registroLRBajaRecibidas property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the registroLRBajaRecibidas property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRegistroLRBajaRecibidas().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link LRBajaRecibidasType }
     * 
     * 
     */
    public List<LRBajaRecibidasType> getRegistroLRBajaRecibidas() {
        if (registroLRBajaRecibidas == null) {
            registroLRBajaRecibidas = new ArrayList<LRBajaRecibidasType>();
        }
        return this.registroLRBajaRecibidas;
    }

}
