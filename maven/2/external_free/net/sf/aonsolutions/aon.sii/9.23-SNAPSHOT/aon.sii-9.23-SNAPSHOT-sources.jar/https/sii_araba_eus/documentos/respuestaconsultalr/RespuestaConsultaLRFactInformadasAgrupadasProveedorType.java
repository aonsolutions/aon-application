
package https.sii_araba_eus.documentos.respuestaconsultalr;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for RespuestaConsultaLRFactInformadasAgrupadasProveedorType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="RespuestaConsultaLRFactInformadasAgrupadasProveedorType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{https://sii.araba.eus/documentos/RespuestaConsultaLR.xsd}RespuestaConsultaLRFacturasAgrupadasProveedorType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="RegistroRespuestaConsultaLRFactInformadasAgrupadasProveedor" type="{https://sii.araba.eus/documentos/RespuestaConsultaLR.xsd}RegistroRespuestaConsultaFactInformadasAgrupadasProveedorType" maxOccurs="10000" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "RespuestaConsultaLRFactInformadasAgrupadasProveedorType", propOrder = {
    "registroRespuestaConsultaLRFactInformadasAgrupadasProveedor"
})
public class RespuestaConsultaLRFactInformadasAgrupadasProveedorType
    extends RespuestaConsultaLRFacturasAgrupadasProveedorType
{

    @XmlElement(name = "RegistroRespuestaConsultaLRFactInformadasAgrupadasProveedor")
    protected List<RegistroRespuestaConsultaFactInformadasAgrupadasProveedorType> registroRespuestaConsultaLRFactInformadasAgrupadasProveedor;

    /**
     * Gets the value of the registroRespuestaConsultaLRFactInformadasAgrupadasProveedor property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the registroRespuestaConsultaLRFactInformadasAgrupadasProveedor property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRegistroRespuestaConsultaLRFactInformadasAgrupadasProveedor().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link RegistroRespuestaConsultaFactInformadasAgrupadasProveedorType }
     * 
     * 
     */
    public List<RegistroRespuestaConsultaFactInformadasAgrupadasProveedorType> getRegistroRespuestaConsultaLRFactInformadasAgrupadasProveedor() {
        if (registroRespuestaConsultaLRFactInformadasAgrupadasProveedor == null) {
            registroRespuestaConsultaLRFactInformadasAgrupadasProveedor = new ArrayList<RegistroRespuestaConsultaFactInformadasAgrupadasProveedorType>();
        }
        return this.registroRespuestaConsultaLRFactInformadasAgrupadasProveedor;
    }

}
