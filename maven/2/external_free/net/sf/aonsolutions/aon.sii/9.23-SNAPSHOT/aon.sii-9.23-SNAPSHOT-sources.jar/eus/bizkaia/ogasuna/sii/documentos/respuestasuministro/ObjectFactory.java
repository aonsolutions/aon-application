
package eus.bizkaia.ogasuna.sii.documentos.respuestasuministro;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the eus.bizkaia.ogasuna.sii.documentos.respuestasuministro package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _RespuestaLRFacturasEmitidas_QNAME = new QName("http://www.bizkaia.eus/ogasuna/sii/documentos/RespuestaSuministro.xsd", "RespuestaLRFacturasEmitidas");
    private final static QName _RespuestaLRBajaFacturasEmitidas_QNAME = new QName("http://www.bizkaia.eus/ogasuna/sii/documentos/RespuestaSuministro.xsd", "RespuestaLRBajaFacturasEmitidas");
    private final static QName _RespuestaLRFacturasRecibidas_QNAME = new QName("http://www.bizkaia.eus/ogasuna/sii/documentos/RespuestaSuministro.xsd", "RespuestaLRFacturasRecibidas");
    private final static QName _RespuestaLRBajaFacturasRecibidas_QNAME = new QName("http://www.bizkaia.eus/ogasuna/sii/documentos/RespuestaSuministro.xsd", "RespuestaLRBajaFacturasRecibidas");
    private final static QName _RespuestaLRBienesInversion_QNAME = new QName("http://www.bizkaia.eus/ogasuna/sii/documentos/RespuestaSuministro.xsd", "RespuestaLRBienesInversion");
    private final static QName _RespuestaLRBajaBienesInversion_QNAME = new QName("http://www.bizkaia.eus/ogasuna/sii/documentos/RespuestaSuministro.xsd", "RespuestaLRBajaBienesInversion");
    private final static QName _RespuestaLRDetOperacionesIntracomunitarias_QNAME = new QName("http://www.bizkaia.eus/ogasuna/sii/documentos/RespuestaSuministro.xsd", "RespuestaLRDetOperacionesIntracomunitarias");
    private final static QName _RespuestaLRBajaDetOperacionesIntracomunitarias_QNAME = new QName("http://www.bizkaia.eus/ogasuna/sii/documentos/RespuestaSuministro.xsd", "RespuestaLRBajaDetOperacionesIntracomunitarias");
    private final static QName _RespuestaLRAgenciasViajes_QNAME = new QName("http://www.bizkaia.eus/ogasuna/sii/documentos/RespuestaSuministro.xsd", "RespuestaLRAgenciasViajes");
    private final static QName _RespuestaLRCobrosMetalico_QNAME = new QName("http://www.bizkaia.eus/ogasuna/sii/documentos/RespuestaSuministro.xsd", "RespuestaLRCobrosMetalico");
    private final static QName _RespuestaLROperacionesSeguros_QNAME = new QName("http://www.bizkaia.eus/ogasuna/sii/documentos/RespuestaSuministro.xsd", "RespuestaLROperacionesSeguros");
    private final static QName _RespuestaLRBajaCobrosMetalico_QNAME = new QName("http://www.bizkaia.eus/ogasuna/sii/documentos/RespuestaSuministro.xsd", "RespuestaLRBajaCobrosMetalico");
    private final static QName _RespuestaLRBajaAgenciasViajes_QNAME = new QName("http://www.bizkaia.eus/ogasuna/sii/documentos/RespuestaSuministro.xsd", "RespuestaLRBajaAgenciasViajes");
    private final static QName _RespuestaLRBajaOperacionesSeguros_QNAME = new QName("http://www.bizkaia.eus/ogasuna/sii/documentos/RespuestaSuministro.xsd", "RespuestaLRBajaOperacionesSeguros");
    private final static QName _RespuestaLRCobrosEmitidas_QNAME = new QName("http://www.bizkaia.eus/ogasuna/sii/documentos/RespuestaSuministro.xsd", "RespuestaLRCobrosEmitidas");
    private final static QName _RespuestaLRPagosRecibidas_QNAME = new QName("http://www.bizkaia.eus/ogasuna/sii/documentos/RespuestaSuministro.xsd", "RespuestaLRPagosRecibidas");
    private final static QName _RespuestaLRInmueblesAdicionales_QNAME = new QName("http://www.bizkaia.eus/ogasuna/sii/documentos/RespuestaSuministro.xsd", "RespuestaLRInmueblesAdicionales");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: eus.bizkaia.ogasuna.sii.documentos.respuestasuministro
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link RespuestaOperacionesSegurosBajaType }
     * 
     */
    public RespuestaOperacionesSegurosBajaType createRespuestaOperacionesSegurosBajaType() {
        return new RespuestaOperacionesSegurosBajaType();
    }

    /**
     * Create an instance of {@link RespuestaOperacionesSegurosType }
     * 
     */
    public RespuestaOperacionesSegurosType createRespuestaOperacionesSegurosType() {
        return new RespuestaOperacionesSegurosType();
    }

    /**
     * Create an instance of {@link RespuestaAgenciasViajesBajaType }
     * 
     */
    public RespuestaAgenciasViajesBajaType createRespuestaAgenciasViajesBajaType() {
        return new RespuestaAgenciasViajesBajaType();
    }

    /**
     * Create an instance of {@link RespuestaMetalicoBajaType }
     * 
     */
    public RespuestaMetalicoBajaType createRespuestaMetalicoBajaType() {
        return new RespuestaMetalicoBajaType();
    }

    /**
     * Create an instance of {@link RespuestaAgenciasViajesType }
     * 
     */
    public RespuestaAgenciasViajesType createRespuestaAgenciasViajesType() {
        return new RespuestaAgenciasViajesType();
    }

    /**
     * Create an instance of {@link RespuestaMetalicoType }
     * 
     */
    public RespuestaMetalicoType createRespuestaMetalicoType() {
        return new RespuestaMetalicoType();
    }

    /**
     * Create an instance of {@link RespuestaBienBajaType }
     * 
     */
    public RespuestaBienBajaType createRespuestaBienBajaType() {
        return new RespuestaBienBajaType();
    }

    /**
     * Create an instance of {@link RespuestaBienType }
     * 
     */
    public RespuestaBienType createRespuestaBienType() {
        return new RespuestaBienType();
    }

    /**
     * Create an instance of {@link RespuestaLRFEmitidasType }
     * 
     */
    public RespuestaLRFEmitidasType createRespuestaLRFEmitidasType() {
        return new RespuestaLRFEmitidasType();
    }

    /**
     * Create an instance of {@link RespuestaLRBajaFEmitidasType }
     * 
     */
    public RespuestaLRBajaFEmitidasType createRespuestaLRBajaFEmitidasType() {
        return new RespuestaLRBajaFEmitidasType();
    }

    /**
     * Create an instance of {@link RespuestaLRFRecibidasType }
     * 
     */
    public RespuestaLRFRecibidasType createRespuestaLRFRecibidasType() {
        return new RespuestaLRFRecibidasType();
    }

    /**
     * Create an instance of {@link RespuestaLRBajaFRecibidasType }
     * 
     */
    public RespuestaLRBajaFRecibidasType createRespuestaLRBajaFRecibidasType() {
        return new RespuestaLRBajaFRecibidasType();
    }

    /**
     * Create an instance of {@link RespuestaLRBienesInversionType }
     * 
     */
    public RespuestaLRBienesInversionType createRespuestaLRBienesInversionType() {
        return new RespuestaLRBienesInversionType();
    }

    /**
     * Create an instance of {@link RespuestaLRBajaBienesInversionType }
     * 
     */
    public RespuestaLRBajaBienesInversionType createRespuestaLRBajaBienesInversionType() {
        return new RespuestaLRBajaBienesInversionType();
    }

    /**
     * Create an instance of {@link RespuestaLROComunitariasType }
     * 
     */
    public RespuestaLROComunitariasType createRespuestaLROComunitariasType() {
        return new RespuestaLROComunitariasType();
    }

    /**
     * Create an instance of {@link RespuestaLRBajaOComunitariasType }
     * 
     */
    public RespuestaLRBajaOComunitariasType createRespuestaLRBajaOComunitariasType() {
        return new RespuestaLRBajaOComunitariasType();
    }

    /**
     * Create an instance of {@link RespuestaLRAgenciasViajesType }
     * 
     */
    public RespuestaLRAgenciasViajesType createRespuestaLRAgenciasViajesType() {
        return new RespuestaLRAgenciasViajesType();
    }

    /**
     * Create an instance of {@link RespuestaLRIMetalicoType }
     * 
     */
    public RespuestaLRIMetalicoType createRespuestaLRIMetalicoType() {
        return new RespuestaLRIMetalicoType();
    }

    /**
     * Create an instance of {@link RespuestaLROperacionesSegurosType }
     * 
     */
    public RespuestaLROperacionesSegurosType createRespuestaLROperacionesSegurosType() {
        return new RespuestaLROperacionesSegurosType();
    }

    /**
     * Create an instance of {@link RespuestaLRBajaIMetalicoType }
     * 
     */
    public RespuestaLRBajaIMetalicoType createRespuestaLRBajaIMetalicoType() {
        return new RespuestaLRBajaIMetalicoType();
    }

    /**
     * Create an instance of {@link RespuestaLRBajaAgenciasViajesType }
     * 
     */
    public RespuestaLRBajaAgenciasViajesType createRespuestaLRBajaAgenciasViajesType() {
        return new RespuestaLRBajaAgenciasViajesType();
    }

    /**
     * Create an instance of {@link RespuestaLRBajaOperacionesSegurosType }
     * 
     */
    public RespuestaLRBajaOperacionesSegurosType createRespuestaLRBajaOperacionesSegurosType() {
        return new RespuestaLRBajaOperacionesSegurosType();
    }

    /**
     * Create an instance of {@link RespuestaLRCobrosEmitidasType }
     * 
     */
    public RespuestaLRCobrosEmitidasType createRespuestaLRCobrosEmitidasType() {
        return new RespuestaLRCobrosEmitidasType();
    }

    /**
     * Create an instance of {@link RespuestaLRPagosRecibidasType }
     * 
     */
    public RespuestaLRPagosRecibidasType createRespuestaLRPagosRecibidasType() {
        return new RespuestaLRPagosRecibidasType();
    }

    /**
     * Create an instance of {@link RespuestaLRInmueblesType }
     * 
     */
    public RespuestaLRInmueblesType createRespuestaLRInmueblesType() {
        return new RespuestaLRInmueblesType();
    }

    /**
     * Create an instance of {@link RespuestaComunAltaType }
     * 
     */
    public RespuestaComunAltaType createRespuestaComunAltaType() {
        return new RespuestaComunAltaType();
    }

    /**
     * Create an instance of {@link RespuestaLRBajaFRecibidasPagosType }
     * 
     */
    public RespuestaLRBajaFRecibidasPagosType createRespuestaLRBajaFRecibidasPagosType() {
        return new RespuestaLRBajaFRecibidasPagosType();
    }

    /**
     * Create an instance of {@link RespuestaComunBajaType }
     * 
     */
    public RespuestaComunBajaType createRespuestaComunBajaType() {
        return new RespuestaComunBajaType();
    }

    /**
     * Create an instance of {@link RespuestaCobrosPagosType }
     * 
     */
    public RespuestaCobrosPagosType createRespuestaCobrosPagosType() {
        return new RespuestaCobrosPagosType();
    }

    /**
     * Create an instance of {@link RespuestaInmueblesType }
     * 
     */
    public RespuestaInmueblesType createRespuestaInmueblesType() {
        return new RespuestaInmueblesType();
    }

    /**
     * Create an instance of {@link RespuestaExpedidaType }
     * 
     */
    public RespuestaExpedidaType createRespuestaExpedidaType() {
        return new RespuestaExpedidaType();
    }

    /**
     * Create an instance of {@link RespuestaExpedidaBajaType }
     * 
     */
    public RespuestaExpedidaBajaType createRespuestaExpedidaBajaType() {
        return new RespuestaExpedidaBajaType();
    }

    /**
     * Create an instance of {@link RespuestaExpedidaCobroType }
     * 
     */
    public RespuestaExpedidaCobroType createRespuestaExpedidaCobroType() {
        return new RespuestaExpedidaCobroType();
    }

    /**
     * Create an instance of {@link RespuestaExpedidaInmueblesType }
     * 
     */
    public RespuestaExpedidaInmueblesType createRespuestaExpedidaInmueblesType() {
        return new RespuestaExpedidaInmueblesType();
    }

    /**
     * Create an instance of {@link RespuestaRecibidaType }
     * 
     */
    public RespuestaRecibidaType createRespuestaRecibidaType() {
        return new RespuestaRecibidaType();
    }

    /**
     * Create an instance of {@link RespuestaRecibidaBajaType }
     * 
     */
    public RespuestaRecibidaBajaType createRespuestaRecibidaBajaType() {
        return new RespuestaRecibidaBajaType();
    }

    /**
     * Create an instance of {@link RespuestaRecibidaPagoType }
     * 
     */
    public RespuestaRecibidaPagoType createRespuestaRecibidaPagoType() {
        return new RespuestaRecibidaPagoType();
    }

    /**
     * Create an instance of {@link RespuestaComunitariaType }
     * 
     */
    public RespuestaComunitariaType createRespuestaComunitariaType() {
        return new RespuestaComunitariaType();
    }

    /**
     * Create an instance of {@link RespuestaComunitariaBajaType }
     * 
     */
    public RespuestaComunitariaBajaType createRespuestaComunitariaBajaType() {
        return new RespuestaComunitariaBajaType();
    }

    /**
     * Create an instance of {@link RespuestaOperacionesSegurosBajaType.PeriodoLiquidacion }
     * 
     */
    public RespuestaOperacionesSegurosBajaType.PeriodoLiquidacion createRespuestaOperacionesSegurosBajaTypePeriodoLiquidacion() {
        return new RespuestaOperacionesSegurosBajaType.PeriodoLiquidacion();
    }

    /**
     * Create an instance of {@link RespuestaOperacionesSegurosType.PeriodoLiquidacion }
     * 
     */
    public RespuestaOperacionesSegurosType.PeriodoLiquidacion createRespuestaOperacionesSegurosTypePeriodoLiquidacion() {
        return new RespuestaOperacionesSegurosType.PeriodoLiquidacion();
    }

    /**
     * Create an instance of {@link RespuestaAgenciasViajesBajaType.PeriodoLiquidacion }
     * 
     */
    public RespuestaAgenciasViajesBajaType.PeriodoLiquidacion createRespuestaAgenciasViajesBajaTypePeriodoLiquidacion() {
        return new RespuestaAgenciasViajesBajaType.PeriodoLiquidacion();
    }

    /**
     * Create an instance of {@link RespuestaMetalicoBajaType.PeriodoLiquidacion }
     * 
     */
    public RespuestaMetalicoBajaType.PeriodoLiquidacion createRespuestaMetalicoBajaTypePeriodoLiquidacion() {
        return new RespuestaMetalicoBajaType.PeriodoLiquidacion();
    }

    /**
     * Create an instance of {@link RespuestaAgenciasViajesType.PeriodoLiquidacion }
     * 
     */
    public RespuestaAgenciasViajesType.PeriodoLiquidacion createRespuestaAgenciasViajesTypePeriodoLiquidacion() {
        return new RespuestaAgenciasViajesType.PeriodoLiquidacion();
    }

    /**
     * Create an instance of {@link RespuestaMetalicoType.PeriodoLiquidacion }
     * 
     */
    public RespuestaMetalicoType.PeriodoLiquidacion createRespuestaMetalicoTypePeriodoLiquidacion() {
        return new RespuestaMetalicoType.PeriodoLiquidacion();
    }

    /**
     * Create an instance of {@link RespuestaBienBajaType.PeriodoLiquidacion }
     * 
     */
    public RespuestaBienBajaType.PeriodoLiquidacion createRespuestaBienBajaTypePeriodoLiquidacion() {
        return new RespuestaBienBajaType.PeriodoLiquidacion();
    }

    /**
     * Create an instance of {@link RespuestaBienType.PeriodoLiquidacion }
     * 
     */
    public RespuestaBienType.PeriodoLiquidacion createRespuestaBienTypePeriodoLiquidacion() {
        return new RespuestaBienType.PeriodoLiquidacion();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RespuestaLRFEmitidasType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link RespuestaLRFEmitidasType }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.bizkaia.eus/ogasuna/sii/documentos/RespuestaSuministro.xsd", name = "RespuestaLRFacturasEmitidas")
    public JAXBElement<RespuestaLRFEmitidasType> createRespuestaLRFacturasEmitidas(RespuestaLRFEmitidasType value) {
        return new JAXBElement<RespuestaLRFEmitidasType>(_RespuestaLRFacturasEmitidas_QNAME, RespuestaLRFEmitidasType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RespuestaLRBajaFEmitidasType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link RespuestaLRBajaFEmitidasType }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.bizkaia.eus/ogasuna/sii/documentos/RespuestaSuministro.xsd", name = "RespuestaLRBajaFacturasEmitidas")
    public JAXBElement<RespuestaLRBajaFEmitidasType> createRespuestaLRBajaFacturasEmitidas(RespuestaLRBajaFEmitidasType value) {
        return new JAXBElement<RespuestaLRBajaFEmitidasType>(_RespuestaLRBajaFacturasEmitidas_QNAME, RespuestaLRBajaFEmitidasType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RespuestaLRFRecibidasType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link RespuestaLRFRecibidasType }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.bizkaia.eus/ogasuna/sii/documentos/RespuestaSuministro.xsd", name = "RespuestaLRFacturasRecibidas")
    public JAXBElement<RespuestaLRFRecibidasType> createRespuestaLRFacturasRecibidas(RespuestaLRFRecibidasType value) {
        return new JAXBElement<RespuestaLRFRecibidasType>(_RespuestaLRFacturasRecibidas_QNAME, RespuestaLRFRecibidasType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RespuestaLRBajaFRecibidasType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link RespuestaLRBajaFRecibidasType }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.bizkaia.eus/ogasuna/sii/documentos/RespuestaSuministro.xsd", name = "RespuestaLRBajaFacturasRecibidas")
    public JAXBElement<RespuestaLRBajaFRecibidasType> createRespuestaLRBajaFacturasRecibidas(RespuestaLRBajaFRecibidasType value) {
        return new JAXBElement<RespuestaLRBajaFRecibidasType>(_RespuestaLRBajaFacturasRecibidas_QNAME, RespuestaLRBajaFRecibidasType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RespuestaLRBienesInversionType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link RespuestaLRBienesInversionType }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.bizkaia.eus/ogasuna/sii/documentos/RespuestaSuministro.xsd", name = "RespuestaLRBienesInversion")
    public JAXBElement<RespuestaLRBienesInversionType> createRespuestaLRBienesInversion(RespuestaLRBienesInversionType value) {
        return new JAXBElement<RespuestaLRBienesInversionType>(_RespuestaLRBienesInversion_QNAME, RespuestaLRBienesInversionType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RespuestaLRBajaBienesInversionType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link RespuestaLRBajaBienesInversionType }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.bizkaia.eus/ogasuna/sii/documentos/RespuestaSuministro.xsd", name = "RespuestaLRBajaBienesInversion")
    public JAXBElement<RespuestaLRBajaBienesInversionType> createRespuestaLRBajaBienesInversion(RespuestaLRBajaBienesInversionType value) {
        return new JAXBElement<RespuestaLRBajaBienesInversionType>(_RespuestaLRBajaBienesInversion_QNAME, RespuestaLRBajaBienesInversionType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RespuestaLROComunitariasType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link RespuestaLROComunitariasType }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.bizkaia.eus/ogasuna/sii/documentos/RespuestaSuministro.xsd", name = "RespuestaLRDetOperacionesIntracomunitarias")
    public JAXBElement<RespuestaLROComunitariasType> createRespuestaLRDetOperacionesIntracomunitarias(RespuestaLROComunitariasType value) {
        return new JAXBElement<RespuestaLROComunitariasType>(_RespuestaLRDetOperacionesIntracomunitarias_QNAME, RespuestaLROComunitariasType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RespuestaLRBajaOComunitariasType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link RespuestaLRBajaOComunitariasType }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.bizkaia.eus/ogasuna/sii/documentos/RespuestaSuministro.xsd", name = "RespuestaLRBajaDetOperacionesIntracomunitarias")
    public JAXBElement<RespuestaLRBajaOComunitariasType> createRespuestaLRBajaDetOperacionesIntracomunitarias(RespuestaLRBajaOComunitariasType value) {
        return new JAXBElement<RespuestaLRBajaOComunitariasType>(_RespuestaLRBajaDetOperacionesIntracomunitarias_QNAME, RespuestaLRBajaOComunitariasType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RespuestaLRAgenciasViajesType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link RespuestaLRAgenciasViajesType }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.bizkaia.eus/ogasuna/sii/documentos/RespuestaSuministro.xsd", name = "RespuestaLRAgenciasViajes")
    public JAXBElement<RespuestaLRAgenciasViajesType> createRespuestaLRAgenciasViajes(RespuestaLRAgenciasViajesType value) {
        return new JAXBElement<RespuestaLRAgenciasViajesType>(_RespuestaLRAgenciasViajes_QNAME, RespuestaLRAgenciasViajesType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RespuestaLRIMetalicoType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link RespuestaLRIMetalicoType }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.bizkaia.eus/ogasuna/sii/documentos/RespuestaSuministro.xsd", name = "RespuestaLRCobrosMetalico")
    public JAXBElement<RespuestaLRIMetalicoType> createRespuestaLRCobrosMetalico(RespuestaLRIMetalicoType value) {
        return new JAXBElement<RespuestaLRIMetalicoType>(_RespuestaLRCobrosMetalico_QNAME, RespuestaLRIMetalicoType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RespuestaLROperacionesSegurosType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link RespuestaLROperacionesSegurosType }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.bizkaia.eus/ogasuna/sii/documentos/RespuestaSuministro.xsd", name = "RespuestaLROperacionesSeguros")
    public JAXBElement<RespuestaLROperacionesSegurosType> createRespuestaLROperacionesSeguros(RespuestaLROperacionesSegurosType value) {
        return new JAXBElement<RespuestaLROperacionesSegurosType>(_RespuestaLROperacionesSeguros_QNAME, RespuestaLROperacionesSegurosType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RespuestaLRBajaIMetalicoType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link RespuestaLRBajaIMetalicoType }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.bizkaia.eus/ogasuna/sii/documentos/RespuestaSuministro.xsd", name = "RespuestaLRBajaCobrosMetalico")
    public JAXBElement<RespuestaLRBajaIMetalicoType> createRespuestaLRBajaCobrosMetalico(RespuestaLRBajaIMetalicoType value) {
        return new JAXBElement<RespuestaLRBajaIMetalicoType>(_RespuestaLRBajaCobrosMetalico_QNAME, RespuestaLRBajaIMetalicoType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RespuestaLRBajaAgenciasViajesType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link RespuestaLRBajaAgenciasViajesType }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.bizkaia.eus/ogasuna/sii/documentos/RespuestaSuministro.xsd", name = "RespuestaLRBajaAgenciasViajes")
    public JAXBElement<RespuestaLRBajaAgenciasViajesType> createRespuestaLRBajaAgenciasViajes(RespuestaLRBajaAgenciasViajesType value) {
        return new JAXBElement<RespuestaLRBajaAgenciasViajesType>(_RespuestaLRBajaAgenciasViajes_QNAME, RespuestaLRBajaAgenciasViajesType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RespuestaLRBajaOperacionesSegurosType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link RespuestaLRBajaOperacionesSegurosType }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.bizkaia.eus/ogasuna/sii/documentos/RespuestaSuministro.xsd", name = "RespuestaLRBajaOperacionesSeguros")
    public JAXBElement<RespuestaLRBajaOperacionesSegurosType> createRespuestaLRBajaOperacionesSeguros(RespuestaLRBajaOperacionesSegurosType value) {
        return new JAXBElement<RespuestaLRBajaOperacionesSegurosType>(_RespuestaLRBajaOperacionesSeguros_QNAME, RespuestaLRBajaOperacionesSegurosType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RespuestaLRCobrosEmitidasType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link RespuestaLRCobrosEmitidasType }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.bizkaia.eus/ogasuna/sii/documentos/RespuestaSuministro.xsd", name = "RespuestaLRCobrosEmitidas")
    public JAXBElement<RespuestaLRCobrosEmitidasType> createRespuestaLRCobrosEmitidas(RespuestaLRCobrosEmitidasType value) {
        return new JAXBElement<RespuestaLRCobrosEmitidasType>(_RespuestaLRCobrosEmitidas_QNAME, RespuestaLRCobrosEmitidasType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RespuestaLRPagosRecibidasType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link RespuestaLRPagosRecibidasType }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.bizkaia.eus/ogasuna/sii/documentos/RespuestaSuministro.xsd", name = "RespuestaLRPagosRecibidas")
    public JAXBElement<RespuestaLRPagosRecibidasType> createRespuestaLRPagosRecibidas(RespuestaLRPagosRecibidasType value) {
        return new JAXBElement<RespuestaLRPagosRecibidasType>(_RespuestaLRPagosRecibidas_QNAME, RespuestaLRPagosRecibidasType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RespuestaLRInmueblesType }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link RespuestaLRInmueblesType }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.bizkaia.eus/ogasuna/sii/documentos/RespuestaSuministro.xsd", name = "RespuestaLRInmueblesAdicionales")
    public JAXBElement<RespuestaLRInmueblesType> createRespuestaLRInmueblesAdicionales(RespuestaLRInmueblesType value) {
        return new JAXBElement<RespuestaLRInmueblesType>(_RespuestaLRInmueblesAdicionales_QNAME, RespuestaLRInmueblesType.class, null, value);
    }

}
