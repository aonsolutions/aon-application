
package eus.bizkaia.ogasuna.sii.documentos.consultalr;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import eus.bizkaia.ogasuna.sii.documentos.suministroinformacion.ClaveOperacionType;
import eus.bizkaia.ogasuna.sii.documentos.suministroinformacion.ContraparteConsultaType;
import eus.bizkaia.ogasuna.sii.documentos.suministroinformacion.FacturaModificadaType;
import eus.bizkaia.ogasuna.sii.documentos.suministroinformacion.PersonaFisicaJuridicaType;
import eus.bizkaia.ogasuna.sii.documentos.suministroinformacion.RangoFechaPresentacionType;
import eus.bizkaia.ogasuna.sii.documentos.suministroinformacion.RegistroSii;


/**
 * <p>Java class for LRFiltroOperacionesSegurosType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="LRFiltroOperacionesSegurosType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://www.bizkaia.eus/ogasuna/sii/documentos/SuministroInformacion.xsd}RegistroSii"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Contraparte" type="{http://www.bizkaia.eus/ogasuna/sii/documentos/SuministroInformacion.xsd}ContraparteConsultaType" minOccurs="0"/&gt;
 *         &lt;element name="ClaveOperacion" type="{http://www.bizkaia.eus/ogasuna/sii/documentos/SuministroInformacion.xsd}ClaveOperacionType" minOccurs="0"/&gt;
 *         &lt;element name="FechaPresentacion" type="{http://www.bizkaia.eus/ogasuna/sii/documentos/SuministroInformacion.xsd}RangoFechaPresentacionType" minOccurs="0"/&gt;
 *         &lt;element name="OperacionModificada" type="{http://www.bizkaia.eus/ogasuna/sii/documentos/SuministroInformacion.xsd}FacturaModificadaType" minOccurs="0"/&gt;
 *         &lt;element name="ClavePaginacion" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="Contraparte" type="{http://www.bizkaia.eus/ogasuna/sii/documentos/SuministroInformacion.xsd}PersonaFisicaJuridicaType"/&gt;
 *                   &lt;element name="ClaveOperacion" type="{http://www.bizkaia.eus/ogasuna/sii/documentos/SuministroInformacion.xsd}ClaveOperacionType"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "LRFiltroOperacionesSegurosType", propOrder = {
    "contraparte",
    "claveOperacion",
    "fechaPresentacion",
    "operacionModificada",
    "clavePaginacion"
})
public class LRFiltroOperacionesSegurosType
    extends RegistroSii
{

    @XmlElement(name = "Contraparte")
    protected ContraparteConsultaType contraparte;
    @XmlElement(name = "ClaveOperacion")
    @XmlSchemaType(name = "string")
    protected ClaveOperacionType claveOperacion;
    @XmlElement(name = "FechaPresentacion")
    protected RangoFechaPresentacionType fechaPresentacion;
    @XmlElement(name = "OperacionModificada")
    @XmlSchemaType(name = "string")
    protected FacturaModificadaType operacionModificada;
    @XmlElement(name = "ClavePaginacion")
    protected LRFiltroOperacionesSegurosType.ClavePaginacion clavePaginacion;

    /**
     * Gets the value of the contraparte property.
     * 
     * @return
     *     possible object is
     *     {@link ContraparteConsultaType }
     *     
     */
    public ContraparteConsultaType getContraparte() {
        return contraparte;
    }

    /**
     * Sets the value of the contraparte property.
     * 
     * @param value
     *     allowed object is
     *     {@link ContraparteConsultaType }
     *     
     */
    public void setContraparte(ContraparteConsultaType value) {
        this.contraparte = value;
    }

    /**
     * Gets the value of the claveOperacion property.
     * 
     * @return
     *     possible object is
     *     {@link ClaveOperacionType }
     *     
     */
    public ClaveOperacionType getClaveOperacion() {
        return claveOperacion;
    }

    /**
     * Sets the value of the claveOperacion property.
     * 
     * @param value
     *     allowed object is
     *     {@link ClaveOperacionType }
     *     
     */
    public void setClaveOperacion(ClaveOperacionType value) {
        this.claveOperacion = value;
    }

    /**
     * Gets the value of the fechaPresentacion property.
     * 
     * @return
     *     possible object is
     *     {@link RangoFechaPresentacionType }
     *     
     */
    public RangoFechaPresentacionType getFechaPresentacion() {
        return fechaPresentacion;
    }

    /**
     * Sets the value of the fechaPresentacion property.
     * 
     * @param value
     *     allowed object is
     *     {@link RangoFechaPresentacionType }
     *     
     */
    public void setFechaPresentacion(RangoFechaPresentacionType value) {
        this.fechaPresentacion = value;
    }

    /**
     * Gets the value of the operacionModificada property.
     * 
     * @return
     *     possible object is
     *     {@link FacturaModificadaType }
     *     
     */
    public FacturaModificadaType getOperacionModificada() {
        return operacionModificada;
    }

    /**
     * Sets the value of the operacionModificada property.
     * 
     * @param value
     *     allowed object is
     *     {@link FacturaModificadaType }
     *     
     */
    public void setOperacionModificada(FacturaModificadaType value) {
        this.operacionModificada = value;
    }

    /**
     * Gets the value of the clavePaginacion property.
     * 
     * @return
     *     possible object is
     *     {@link LRFiltroOperacionesSegurosType.ClavePaginacion }
     *     
     */
    public LRFiltroOperacionesSegurosType.ClavePaginacion getClavePaginacion() {
        return clavePaginacion;
    }

    /**
     * Sets the value of the clavePaginacion property.
     * 
     * @param value
     *     allowed object is
     *     {@link LRFiltroOperacionesSegurosType.ClavePaginacion }
     *     
     */
    public void setClavePaginacion(LRFiltroOperacionesSegurosType.ClavePaginacion value) {
        this.clavePaginacion = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="Contraparte" type="{http://www.bizkaia.eus/ogasuna/sii/documentos/SuministroInformacion.xsd}PersonaFisicaJuridicaType"/&gt;
     *         &lt;element name="ClaveOperacion" type="{http://www.bizkaia.eus/ogasuna/sii/documentos/SuministroInformacion.xsd}ClaveOperacionType"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "contraparte",
        "claveOperacion"
    })
    public static class ClavePaginacion {

        @XmlElement(name = "Contraparte", required = true)
        protected PersonaFisicaJuridicaType contraparte;
        @XmlElement(name = "ClaveOperacion", required = true)
        @XmlSchemaType(name = "string")
        protected ClaveOperacionType claveOperacion;

        /**
         * Gets the value of the contraparte property.
         * 
         * @return
         *     possible object is
         *     {@link PersonaFisicaJuridicaType }
         *     
         */
        public PersonaFisicaJuridicaType getContraparte() {
            return contraparte;
        }

        /**
         * Sets the value of the contraparte property.
         * 
         * @param value
         *     allowed object is
         *     {@link PersonaFisicaJuridicaType }
         *     
         */
        public void setContraparte(PersonaFisicaJuridicaType value) {
            this.contraparte = value;
        }

        /**
         * Gets the value of the claveOperacion property.
         * 
         * @return
         *     possible object is
         *     {@link ClaveOperacionType }
         *     
         */
        public ClaveOperacionType getClaveOperacion() {
            return claveOperacion;
        }

        /**
         * Sets the value of the claveOperacion property.
         * 
         * @param value
         *     allowed object is
         *     {@link ClaveOperacionType }
         *     
         */
        public void setClaveOperacion(ClaveOperacionType value) {
            this.claveOperacion = value;
        }

    }

}
