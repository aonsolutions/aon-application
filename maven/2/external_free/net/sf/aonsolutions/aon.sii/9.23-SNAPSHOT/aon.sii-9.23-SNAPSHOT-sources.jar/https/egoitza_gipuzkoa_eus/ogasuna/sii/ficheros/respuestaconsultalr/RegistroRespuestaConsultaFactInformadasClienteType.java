
package https.egoitza_gipuzkoa_eus.ogasuna.sii.ficheros.respuestaconsultalr;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import https.egoitza_gipuzkoa_eus.ogasuna.sii.ficheros.suministroinformacion.IDFacturaImputacionType;
import https.egoitza_gipuzkoa_eus.ogasuna.sii.ficheros.suministroinformacion.PersonaFisicaJuridicaUnicaESType;


/**
 * <p>Java class for RegistroRespuestaConsultaFactInformadasClienteType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="RegistroRespuestaConsultaFactInformadasClienteType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="IDFactura" type="{https://egoitza.gipuzkoa.eus/ogasuna/sii/ficheros/SuministroInformacion.xsd}IDFacturaImputacionType"/&gt;
 *         &lt;element name="PeriodoLiquidacion"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="Ejercicio" type="{https://egoitza.gipuzkoa.eus/ogasuna/sii/ficheros/SuministroInformacion.xsd}YearType"/&gt;
 *                   &lt;element name="Periodo" type="{https://egoitza.gipuzkoa.eus/ogasuna/sii/ficheros/SuministroInformacion.xsd}TipoPeriodoType"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="DatosFacturaInformadaCliente" type="{https://egoitza.gipuzkoa.eus/ogasuna/sii/ficheros/RespuestaConsultaLR.xsd}FacturaRespuestaInformadaClienteType"/&gt;
 *         &lt;element name="Cliente" type="{https://egoitza.gipuzkoa.eus/ogasuna/sii/ficheros/SuministroInformacion.xsd}PersonaFisicaJuridicaUnicaESType"/&gt;
 *         &lt;element name="EstadoFactura" type="{https://egoitza.gipuzkoa.eus/ogasuna/sii/ficheros/RespuestaConsultaLR.xsd}EstadoFacturaImputacionType"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "RegistroRespuestaConsultaFactInformadasClienteType", propOrder = {
    "idFactura",
    "periodoLiquidacion",
    "datosFacturaInformadaCliente",
    "cliente",
    "estadoFactura"
})
public class RegistroRespuestaConsultaFactInformadasClienteType {

    @XmlElement(name = "IDFactura", required = true)
    protected IDFacturaImputacionType idFactura;
    @XmlElement(name = "PeriodoLiquidacion", required = true)
    protected RegistroRespuestaConsultaFactInformadasClienteType.PeriodoLiquidacion periodoLiquidacion;
    @XmlElement(name = "DatosFacturaInformadaCliente", required = true)
    protected FacturaRespuestaInformadaClienteType datosFacturaInformadaCliente;
    @XmlElement(name = "Cliente", required = true)
    protected PersonaFisicaJuridicaUnicaESType cliente;
    @XmlElement(name = "EstadoFactura", required = true)
    protected EstadoFacturaImputacionType estadoFactura;

    /**
     * Gets the value of the idFactura property.
     * 
     * @return
     *     possible object is
     *     {@link IDFacturaImputacionType }
     *     
     */
    public IDFacturaImputacionType getIDFactura() {
        return idFactura;
    }

    /**
     * Sets the value of the idFactura property.
     * 
     * @param value
     *     allowed object is
     *     {@link IDFacturaImputacionType }
     *     
     */
    public void setIDFactura(IDFacturaImputacionType value) {
        this.idFactura = value;
    }

    /**
     * Gets the value of the periodoLiquidacion property.
     * 
     * @return
     *     possible object is
     *     {@link RegistroRespuestaConsultaFactInformadasClienteType.PeriodoLiquidacion }
     *     
     */
    public RegistroRespuestaConsultaFactInformadasClienteType.PeriodoLiquidacion getPeriodoLiquidacion() {
        return periodoLiquidacion;
    }

    /**
     * Sets the value of the periodoLiquidacion property.
     * 
     * @param value
     *     allowed object is
     *     {@link RegistroRespuestaConsultaFactInformadasClienteType.PeriodoLiquidacion }
     *     
     */
    public void setPeriodoLiquidacion(RegistroRespuestaConsultaFactInformadasClienteType.PeriodoLiquidacion value) {
        this.periodoLiquidacion = value;
    }

    /**
     * Gets the value of the datosFacturaInformadaCliente property.
     * 
     * @return
     *     possible object is
     *     {@link FacturaRespuestaInformadaClienteType }
     *     
     */
    public FacturaRespuestaInformadaClienteType getDatosFacturaInformadaCliente() {
        return datosFacturaInformadaCliente;
    }

    /**
     * Sets the value of the datosFacturaInformadaCliente property.
     * 
     * @param value
     *     allowed object is
     *     {@link FacturaRespuestaInformadaClienteType }
     *     
     */
    public void setDatosFacturaInformadaCliente(FacturaRespuestaInformadaClienteType value) {
        this.datosFacturaInformadaCliente = value;
    }

    /**
     * Gets the value of the cliente property.
     * 
     * @return
     *     possible object is
     *     {@link PersonaFisicaJuridicaUnicaESType }
     *     
     */
    public PersonaFisicaJuridicaUnicaESType getCliente() {
        return cliente;
    }

    /**
     * Sets the value of the cliente property.
     * 
     * @param value
     *     allowed object is
     *     {@link PersonaFisicaJuridicaUnicaESType }
     *     
     */
    public void setCliente(PersonaFisicaJuridicaUnicaESType value) {
        this.cliente = value;
    }

    /**
     * Gets the value of the estadoFactura property.
     * 
     * @return
     *     possible object is
     *     {@link EstadoFacturaImputacionType }
     *     
     */
    public EstadoFacturaImputacionType getEstadoFactura() {
        return estadoFactura;
    }

    /**
     * Sets the value of the estadoFactura property.
     * 
     * @param value
     *     allowed object is
     *     {@link EstadoFacturaImputacionType }
     *     
     */
    public void setEstadoFactura(EstadoFacturaImputacionType value) {
        this.estadoFactura = value;
    }


    /**
     *  Per�odo al que corresponden los apuntes 
     * 
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="Ejercicio" type="{https://egoitza.gipuzkoa.eus/ogasuna/sii/ficheros/SuministroInformacion.xsd}YearType"/&gt;
     *         &lt;element name="Periodo" type="{https://egoitza.gipuzkoa.eus/ogasuna/sii/ficheros/SuministroInformacion.xsd}TipoPeriodoType"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "ejercicio",
        "periodo"
    })
    public static class PeriodoLiquidacion {

        @XmlElement(name = "Ejercicio", required = true)
        protected String ejercicio;
        @XmlElement(name = "Periodo", required = true)
        protected String periodo;

        /**
         * Gets the value of the ejercicio property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getEjercicio() {
            return ejercicio;
        }

        /**
         * Sets the value of the ejercicio property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setEjercicio(String value) {
            this.ejercicio = value;
        }

        /**
         * Gets the value of the periodo property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getPeriodo() {
            return periodo;
        }

        /**
         * Sets the value of the periodo property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setPeriodo(String value) {
            this.periodo = value;
        }

    }

}
