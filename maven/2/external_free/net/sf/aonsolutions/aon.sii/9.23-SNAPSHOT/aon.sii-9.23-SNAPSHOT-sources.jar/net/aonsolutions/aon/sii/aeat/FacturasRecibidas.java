package net.aonsolutions.aon.sii.aeat;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.stream.Collectors;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.namespace.QName;

import com.esferalia.aon.occam.api.ACCOUNTING;
import com.esferalia.aon.occam.api.AON;
import com.esferalia.aon.occam.api.model.Account;
import com.esferalia.aon.occam.api.model.AccountEntryDetail;
import com.esferalia.aon.occam.api.model.AccountingInvoice;
import com.esferalia.aon.occam.api.model.ApplicationParameter;
import com.esferalia.aon.occam.api.model.Company;
import com.esferalia.aon.occam.api.model.Domain;
import com.esferalia.aon.occam.api.model.finance.Finance;
import com.esferalia.aon.occam.api.model.finance.Invoice;
import com.esferalia.aon.occam.api.model.fiscal.VatContext;
import com.esferalia.aon.occam.api.model.fiscal.VatData;
import com.esferalia.aon.occam.api.model.type.AppParam;
import com.esferalia.aon.occam.api.model.type.Country;
import com.esferalia.aon.occam.api.model.type.DocumentType;
import com.esferalia.aon.occam.api.model.type.InvoiceType;
import com.esferalia.aon.occam.api.model.type.PayMethodType;
import com.esferalia.aon.watson.server.AonDateUtils;
import com.esferalia.aon.watson.server.io.ByteArrayOutputStream;
import com.esferalia.aon.watson.util.AonMathUtils;

import https.www2_agenciatributaria_gob_es.static_files.common.internet.dep.aplicaciones.es.aeat.ssii.fact.ws.respuestasuministro.RespuestaLRBajaFRecibidasType;
import https.www2_agenciatributaria_gob_es.static_files.common.internet.dep.aplicaciones.es.aeat.ssii.fact.ws.respuestasuministro.RespuestaLRFRecibidasType;
import https.www2_agenciatributaria_gob_es.static_files.common.internet.dep.aplicaciones.es.aeat.ssii.fact.ws.respuestasuministro.RespuestaLRPagosRecibidasType;
import https.www2_agenciatributaria_gob_es.static_files.common.internet.dep.aplicaciones.es.aeat.ssii.fact.ws.suministroinformacion.CabeceraSii;
import https.www2_agenciatributaria_gob_es.static_files.common.internet.dep.aplicaciones.es.aeat.ssii.fact.ws.suministroinformacion.CabeceraSiiBaja;
import https.www2_agenciatributaria_gob_es.static_files.common.internet.dep.aplicaciones.es.aeat.ssii.fact.ws.suministroinformacion.CabeceraSiiCobrosPagos;
import https.www2_agenciatributaria_gob_es.static_files.common.internet.dep.aplicaciones.es.aeat.ssii.fact.ws.suministroinformacion.ClaveTipoComunicacionType;
import https.www2_agenciatributaria_gob_es.static_files.common.internet.dep.aplicaciones.es.aeat.ssii.fact.ws.suministroinformacion.ClaveTipoFacturaType;
import https.www2_agenciatributaria_gob_es.static_files.common.internet.dep.aplicaciones.es.aeat.ssii.fact.ws.suministroinformacion.CountryType2;
import https.www2_agenciatributaria_gob_es.static_files.common.internet.dep.aplicaciones.es.aeat.ssii.fact.ws.suministroinformacion.DatosPagoCobroType;
import https.www2_agenciatributaria_gob_es.static_files.common.internet.dep.aplicaciones.es.aeat.ssii.fact.ws.suministroinformacion.DesgloseFacturaRecibidasType;
import https.www2_agenciatributaria_gob_es.static_files.common.internet.dep.aplicaciones.es.aeat.ssii.fact.ws.suministroinformacion.DesgloseFacturaRecibidasType.DesgloseIVA;
import https.www2_agenciatributaria_gob_es.static_files.common.internet.dep.aplicaciones.es.aeat.ssii.fact.ws.suministroinformacion.DesgloseFacturaRecibidasType.InversionSujetoPasivo;
import https.www2_agenciatributaria_gob_es.static_files.common.internet.dep.aplicaciones.es.aeat.ssii.fact.ws.suministroinformacion.DesgloseRectificacionType;
import https.www2_agenciatributaria_gob_es.static_files.common.internet.dep.aplicaciones.es.aeat.ssii.fact.ws.suministroinformacion.DetalleIVARecibida2Type;
import https.www2_agenciatributaria_gob_es.static_files.common.internet.dep.aplicaciones.es.aeat.ssii.fact.ws.suministroinformacion.DetalleIVARecibidaType;
import https.www2_agenciatributaria_gob_es.static_files.common.internet.dep.aplicaciones.es.aeat.ssii.fact.ws.suministroinformacion.FacturaRecibidaType;
import https.www2_agenciatributaria_gob_es.static_files.common.internet.dep.aplicaciones.es.aeat.ssii.fact.ws.suministroinformacion.FacturaType.FacturasAgrupadas;
import https.www2_agenciatributaria_gob_es.static_files.common.internet.dep.aplicaciones.es.aeat.ssii.fact.ws.suministroinformacion.FacturaType.FacturasRectificadas;
import https.www2_agenciatributaria_gob_es.static_files.common.internet.dep.aplicaciones.es.aeat.ssii.fact.ws.suministroinformacion.IDFacturaARType;
import https.www2_agenciatributaria_gob_es.static_files.common.internet.dep.aplicaciones.es.aeat.ssii.fact.ws.suministroinformacion.IDFacturaRecibidaNombreBCType;
import https.www2_agenciatributaria_gob_es.static_files.common.internet.dep.aplicaciones.es.aeat.ssii.fact.ws.suministroinformacion.IDFacturaRecibidaType;
import https.www2_agenciatributaria_gob_es.static_files.common.internet.dep.aplicaciones.es.aeat.ssii.fact.ws.suministroinformacion.IDFacturaRecibidaType.IDEmisorFactura;
import https.www2_agenciatributaria_gob_es.static_files.common.internet.dep.aplicaciones.es.aeat.ssii.fact.ws.suministroinformacion.IDOtroType;
import https.www2_agenciatributaria_gob_es.static_files.common.internet.dep.aplicaciones.es.aeat.ssii.fact.ws.suministroinformacion.MacrodatoType;
import https.www2_agenciatributaria_gob_es.static_files.common.internet.dep.aplicaciones.es.aeat.ssii.fact.ws.suministroinformacion.PagosType;
import https.www2_agenciatributaria_gob_es.static_files.common.internet.dep.aplicaciones.es.aeat.ssii.fact.ws.suministroinformacion.PersonaFisicaJuridicaESType;
import https.www2_agenciatributaria_gob_es.static_files.common.internet.dep.aplicaciones.es.aeat.ssii.fact.ws.suministroinformacion.PersonaFisicaJuridicaType;
import https.www2_agenciatributaria_gob_es.static_files.common.internet.dep.aplicaciones.es.aeat.ssii.fact.ws.suministrolr.BajaLRFacturasRecibidas;
import https.www2_agenciatributaria_gob_es.static_files.common.internet.dep.aplicaciones.es.aeat.ssii.fact.ws.suministrolr.LRBajaRecibidasType;
import https.www2_agenciatributaria_gob_es.static_files.common.internet.dep.aplicaciones.es.aeat.ssii.fact.ws.suministrolr.LRFacturasRecibidasType;
import https.www2_agenciatributaria_gob_es.static_files.common.internet.dep.aplicaciones.es.aeat.ssii.fact.ws.suministrolr.LRPagosEmitidasType;
import https.www2_agenciatributaria_gob_es.static_files.common.internet.dep.aplicaciones.es.aeat.ssii.fact.ws.suministrolr.SuministroLRFacturasRecibidas;
import https.www2_agenciatributaria_gob_es.static_files.common.internet.dep.aplicaciones.es.aeat.ssii.fact.ws.suministrolr.SuministroLRPagosRecibidas;
import net.aonsolutions.aon.sii.ClaveRegimenEspecialOTrascendenciaRecibidasType;
import net.aonsolutions.aon.sii.IDType;

public class FacturasRecibidas extends SIIBuilt {

	public static FacturasRecibidas getInstance() {
		return new FacturasRecibidas();
	}
	
	public FacturasRecibidas() {

	}
	// ------------------- FACTURAS RECIBIDAS

	public byte[] getSuministroFacturasRecibidas(Domain domain, String login, Company company, Integer invoiceId, LinkedList<VatContext> contextList, Boolean mod, String terceros) {
		JAXBContext ctx;
		byte[] b = null;
		try {
			ctx = JAXBContext.newInstance(SuministroLRFacturasRecibidas.class);
			b = writeXml(ctx, suministroFacturasRecibidas(domain, login, company, invoiceId, contextList, mod, terceros));
		} catch (JAXBException | IOException e) {
			e.printStackTrace();
		}
		return b;
	}
	
	protected byte[] getSuministroFacturasRecibidas(SuministroLRFacturasRecibidas suministro) {
		JAXBContext ctx;
		byte[] b = null;
		try {
			ctx = JAXBContext.newInstance(SuministroLRFacturasRecibidas.class);
			b = writeXml(ctx, suministro);
		} catch (JAXBException | IOException e) {
			e.printStackTrace();
		}
		return b;
	}

	protected byte[] getRespuestaSuministroFacturasRecibidas(RespuestaLRFRecibidasType suministro) {
		JAXBContext ctx;
		byte[] b = null;
		try {
			ctx = JAXBContext.newInstance(RespuestaLRFRecibidasType.class);
			QName qName = new QName("https.www2_agenciatributaria_gob_es.static_files.common.internet.dep.aplicaciones.es.aeat.ssii.fact.ws.respuestasuministro", "RespuestaLRFRecibidasType");
		    JAXBElement<RespuestaLRFRecibidasType> root = new JAXBElement<>(qName, RespuestaLRFRecibidasType.class, suministro);
			b = writeXml(ctx, root);
		} catch (JAXBException | IOException e) {
			e.printStackTrace();
		}
		return b;
	}

	protected byte[] getBajaFacturasRecibidas(BajaLRFacturasRecibidas suministro) {
		JAXBContext ctx;
		byte[] b = null;
		try {
			ctx = JAXBContext.newInstance(BajaLRFacturasRecibidas.class);
			b = writeXml(ctx, suministro);
		} catch (JAXBException | IOException e) {
			e.printStackTrace();
		}
		return b;
	}

	protected byte[] getRespuestaBajaFacturasRecibidas(RespuestaLRBajaFRecibidasType suministro) {
		JAXBContext ctx;
		byte[] b = null;
		try {
			ctx = JAXBContext.newInstance(RespuestaLRBajaFRecibidasType.class);
			QName qName = new QName("https.www2_agenciatributaria_gob_es.static_files.common.internet.dep.aplicaciones.es.aeat.ssii.fact.ws.respuestasuministro", "RespuestaLRBajaFRecibidasType");
		    JAXBElement<RespuestaLRBajaFRecibidasType> root = new JAXBElement<>(qName, RespuestaLRBajaFRecibidasType.class, suministro);
			b = writeXml(ctx, root);
		} catch (JAXBException | IOException e) {
			e.printStackTrace();
		}
		return b;
	}

	/**
	 * Libro de registro de Facturas recibidas.
	 * 
	 * @param company
	 * @param invoiceList
	 */
	protected SuministroLRFacturasRecibidas suministroFacturasRecibidas(Domain domain, String login, Company company, Integer invoiceId, LinkedList<VatContext> contextList, Boolean mod, String terceros) {
		SuministroLRFacturasRecibidas suministro = new SuministroLRFacturasRecibidas();

		// CABECERA
		System.out.println("SII FR GENERANDO XML - CABECERA");
		suministro.setCabecera(cabecera(company, mod, terceros));

		// BODY
		System.out.println("SII FR GENERANDO XML - BODY");
		VatContext vat = contextList.stream().filter(f -> f.getInvoice().equals(invoiceId)).findFirst().orElse(new VatContext());

		LinkedList<VatData> noExenta = new LinkedList<>();
		LinkedList<VatData> pasivoList = new LinkedList<>();
		if (!vat.isIntracommunity()) {
			noExenta = contextList.stream().filter(f -> f.getInvoice().equals(invoiceId) && !f.isOtherISP())
					.map(h -> new VatData().setBase(h.getBase()).setPercentage(h.getPercentage())
							.setQuota(h.getQuota()).setSurchargePercent(h.getSurchargePercent())
							.setSurchargeQuota(h.getSurchargeQuota()))
					.collect(Collectors.toCollection(LinkedList::new));

			pasivoList = contextList.stream().filter(f -> f.getInvoice().equals(invoiceId) && f.isOtherISP())
					.map(f -> new VatData().setBase(f.getBase()).setPercentage(f.getPercentage())
							.setQuota(f.getQuota()).setSurchargePercent(f.getSurchargePercent())
							.setSurchargeQuota(f.getSurchargeQuota()))
					.collect(Collectors.toCollection(LinkedList::new));
		} else {
			noExenta = contextList.stream().filter(f -> f.getInvoice().equals(invoiceId))
					.map(f -> new VatData().setBase(f.getBase()).setPercentage(f.getPercentage())
							.setQuota(f.getQuota()).setSurchargePercent(f.getSurchargePercent())
							.setSurchargeQuota(f.getSurchargeQuota()))
					.collect(Collectors.toCollection(LinkedList::new));
		}
		System.out.println("SII FR GENERANDO XML - TYPE");

		LRFacturasRecibidasType factura = new LRFacturasRecibidasType();

		// PeriodoLiquidacion || PeriodoImpositivo
		factura.setPeriodoLiquidacion(periodoLiquidacion(vat, false));
		
		// IDFactura
		IDFacturaRecibidaType f = new IDFacturaRecibidaType();
		
		IDEmisorFactura emisor = new IDEmisorFactura();
		System.out.println("SII FR GENERANDO XML - DOCUMENT");
		if (vat.getRegistryDocumentCountry().equals(Country.ES)) {
			emisor.setNIF(vat.getRegistryDocument());
		} else if(vat.isIntracommunity()){
			IDOtroType otro = new IDOtroType();
			otro.setCodigoPais(CountryType2.valueOf(vat.getRegistryDocumentCountry().getIso2()));
			String document = vat.getRegistryDocument();
			if(!document.substring(0,2).equals(vat.getRegistryDocumentCountry().getIso2())) {
				document = vat.getRegistryDocumentCountry().getIso2() + document;
			}
			otro.setID(document);		
			otro.setIDType(IDType.NIF_IVA.getName());
			emisor.setIDOtro(otro);
		} else {
			IDOtroType otro = new IDOtroType();
			otro.setCodigoPais(CountryType2.valueOf(vat.getRegistryDocumentCountry().getIso2()));
			otro.setID(vat.getRegistryDocument());
			otro.setIDType(IDType.valueOf(vat.getRegistryDocumentType()).getName());
			emisor.setIDOtro(otro);
		}
		
		System.out.println("SII FR GENERANDO XML - EMISOR");
		f.setIDEmisorFactura(emisor);

		f.setNumSerieFacturaEmisor(vat.getReferenceCode());// n� serie + n� factura
		// (optional) f.setNumSerieFacturaEmisorResumenFin("");
		f.setFechaExpedicionFacturaEmisor(AonDateUtils.format(vat.getIssueDate(), "dd-MM-yyyy"));
		System.out.println("SII FR GENERANDO XML - FACTURA");
		factura.setIDFactura(f);

		FacturaRecibidaType frt = new FacturaRecibidaType();
		// CONTRAPARTE
		System.out.println("SII FR GENERANDO XML - CONTRAPARTE");
		if(vat.isIntracommunity()) {
			frt.setContraparte(contraparteIntracomunitario(vat));
		} else frt.setContraparte(contraparte(vat));
		
		// CLAVE REGIMEN IVA || TRANSCENDENCIA
		System.out.println("SII FR GENERANDO XML - REGIMEN");
		frt.setClaveRegimenEspecialOTrascendencia(ClaveRegimenEspecialOTrascendenciaRecibidasType._01.getName()); // TODO

		if (vat.isVatAccrualRegime()) {
			frt.setClaveRegimenEspecialOTrascendencia(ClaveRegimenEspecialOTrascendenciaRecibidasType._07.getName());// TODO OPTIONAL
		}

		if (vat.isIntracommunity()) {
			frt.setClaveRegimenEspecialOTrascendencia(ClaveRegimenEspecialOTrascendenciaRecibidasType._09.getName());
		}
		ApplicationParameter ap = AON.getApplicationParameter(domain.getName(), domain.getId(), login, AppParam.FS_MODEL_CFG_SII);
		Boolean isRegistro = "R".equals(ap.getValue());
		Date opDate = isRegistro ? vat.getCreationDate() : vat.getTaxDate();
		
		ApplicationParameter ap2 = AON.getApplicationParameter(domain.getName(), domain.getId(), login,
				AppParam.SII_INCLUDE_DATE);
		
		Date siiDate = ap2 != null && ap2.getId() != null ? AonDateUtils.parse(ap2.getValue(), "yyyy-MM-dd") : AonDateUtils.getDate(2017, 6, 1);
		System.out.println("SII FR GENERANDO XML - DATES");
		System.out.println("SII - opDate is null ? " + opDate == null);
		System.out.println("SII - siiDate is null ? " + siiDate == null);
		
		if (opDate != null && siiDate != null && opDate.compareTo(siiDate) < 0) {
			frt.setClaveRegimenEspecialOTrascendencia(ClaveRegimenEspecialOTrascendenciaRecibidasType._14.getName());
		}

		// BASE IMPONIBLE A COSTE (OPTIONAL)
		System.out.println("SII FR GENERANDO XML - REGIMEN ESPECIAL => " + frt.getClaveRegimenEspecialOTrascendencia());
		if ((frt.getClaveRegimenEspecialOTrascendencia() != null && frt.getClaveRegimenEspecialOTrascendencia().equals("06"))
				|| (frt.getClaveRegimenEspecialOTrascendenciaAdicional1() != null
				&& frt.getClaveRegimenEspecialOTrascendenciaAdicional1().equals("06"))
				|| (frt.getClaveRegimenEspecialOTrascendenciaAdicional2() != null
				&& frt.getClaveRegimenEspecialOTrascendenciaAdicional2().equals("06"))) {
			Double base = noExenta.stream().mapToDouble(h -> h.getBase()).sum()
					+ pasivoList.stream().mapToDouble(h -> h.getBase()).sum();
			frt.setBaseImponibleACoste(Double.toString(AonMathUtils.round(base)));
		}
		System.out.println("SII FR GENERANDO XML - CUOTA");
		// CUOTA DEDUCIBLE
		frt.setCuotaDeducible(AonMathUtils.round(contextList.stream().filter(a -> a.getInvoice().equals(invoiceId))
				.mapToDouble(a -> a.getDeductibleQuota()).sum()) + ""); // TODO

			// DESCRIPCION OPERACION
		AccountingInvoice ai = ACCOUNTING.getAccountingInvoiceFromInvoice(domain.getName(), domain.getId(), login, invoiceId);
		String str = "";
		if (ai != null && ai.getAccountEntry() != null && ai.getAccountEntry().getDetails() != null) {
			for (AccountEntryDetail aed : ai.getAccountEntry().getDetails()) {
				Account a = ACCOUNTING.getAccount(domain.getName(), domain.getId(), login, aed.getAccount());
				if (a.getCode().substring(0, 1).equals("6") || a.getCode().substring(0, 1).equals("7")) {
					str = str + a.getDescription() + "-";
				}
			}
		}
		System.out.println("SII FR GENERANDO XML - DESCRIPTION");
		frt.setDescripcionOperacion(str + vat.getDetailDescription());

		// FECHA OPERACION
		frt.setFechaOperacion(AonDateUtils.format(vat.getIssueDate(), "dd-MM-yyyy"));// TODO

		// FECHA REGISTRO CONTABLE
		// frt.setFechaRegContable(AonDateUtils.format(vat.getRegContableDate(),
		// "dd-MM-yyyy"));
		frt.setFechaRegContable(AonDateUtils.format(opDate, "dd-MM-yyyy"));

		System.out.println("SII FR GENERANDO XML - AMOUNT");
		// IMPORTE TOTAL
		Double total = noExenta.stream().mapToDouble(h -> h.getBase() + h.getQuota()).sum()
				+ pasivoList.stream().mapToDouble(h -> h.getBase() + h.getQuota()).sum();
		frt.setImporteTotal(Double.toString(AonMathUtils.round(total)));// TODO
		frt.setMacrodato(total >= 100000000 ? MacrodatoType.S: MacrodatoType.N);

		// NUM REGISTRO ACUERDO FACTURACION
		frt.setNumRegistroAcuerdoFacturacion("");// TODO
		// TIPO FACTURA
		frt.setTipoFactura(ClaveTipoFacturaType.F_1);// TODO De momento a pi�on fijo!!!
		if (vat.isIntracommunity()) {
			//frt.setTipoFactura(ClaveTipoFacturaType.F_5);
		}

		if (vat.isRectification()) {
			frt.setTipoFactura(ClaveTipoFacturaType.R_1); // TODO R_1 || R_2 || R_3 || R_4 || R_4. De momento a
																// pi�on fijo!!!
			frt.setTipoRectificativa("I"); // TODO S (por sustitucion) || I (por diferencia). De momento a pi�on
												// fijo!!!

			// FACTURA RECTIFICADAS
			FacturasRectificadas fr = new FacturasRectificadas();
			Invoice rectificada = AON.getInvoice(domain.getName(), domain.getId(), login,
					h -> h.getIdProperty().eq(vat.getRectificationInvoice()));
			// SOLO 1 RECTIFICADA PARA CADA RECTIFICATIVA!
			IDFacturaARType a2 = new IDFacturaARType();
			a2.setFechaExpedicionFacturaEmisor(AonDateUtils.format(rectificada.getIssueDate(), "dd-MM-yyyy")); // TODO
			a2.setNumSerieFacturaEmisor(rectificada.getReferenceCode());
			fr.getIDFacturaRectificada().add(a2);
			frt.setFacturasRectificadas(fr);

			// IMPORTE RECTIFICACION
			if ("S".equalsIgnoreCase(frt.getTipoRectificativa())) {
				DesgloseRectificacionType drt = new DesgloseRectificacionType();
				drt.setBaseRectificada(Double.toString(AonMathUtils.round(rectificada.getTaxableBase())));
				// TODO
				// drt.setCuotaRecargoRectificado(Double.toString(vat.getRectified().getSurchargeQuota()));
				drt.setCuotaRectificada(Double.toString(AonMathUtils.round(rectificada.getVatQuota()))); // TODO �?
				frt.setImporteRectificacion(drt);
			}
		}

		// for!!!
		if (ClaveTipoFacturaType.F_3.equals(frt.getTipoFactura())) {
			// TODO FACTURAS AGRUPADAS
			FacturasAgrupadas fa = new FacturasAgrupadas();
				
			// FOR
			IDFacturaARType a = new IDFacturaARType();
			a.setFechaExpedicionFacturaEmisor("0.0");
			a.setNumSerieFacturaEmisor("0.0");
			fa.getIDFacturaAgrupada().add(a);
			frt.setFacturasAgrupadas(fa);
		}
		System.out.println("SII FR GENERANDO XML - TYPE FACTURA");
		DesgloseFacturaRecibidasType dfrt = new DesgloseFacturaRecibidasType();
		if (!noExenta.isEmpty()) {
			HashMap<Double, VatData> noExentaMap = new HashMap<>();
			LinkedList<VatData> noExentaAux = noExenta;
			noExentaAux.stream().forEach(r -> {
				if (noExentaMap.containsKey(r.getPercentage())) {
					VatData vd = noExentaMap.get(r.getPercentage());
					noExentaMap.get(r.getPercentage()).setBase(vd.getBase() + r.getBase());
					noExentaMap.get(r.getPercentage()).setQuota(vd.getQuota() + r.getQuota());
					noExentaMap.get(r.getPercentage()).setSurchargeQuota(vd.getSurchargeQuota() + r.getSurchargeQuota());
				} else noExentaMap.put(r.getPercentage(), r);
			});	

			DesgloseIVA diva = new DesgloseIVA();
			noExentaMap.keySet().stream().forEach(key -> {
				DetalleIVARecibidaType diet = new DetalleIVARecibidaType();
				diet.setBaseImponible(Double.toString(AonMathUtils.round(noExentaMap.get(key).getBase()))); // TODO
				String percent = Double.toString(AonMathUtils.round(noExentaMap.get(key).getPercentage()));
				if("12.0".equals(percent) || "10.5".equals(percent)) {
					diet.setPorcentCompensacionREAGYP(Double.toString(AonMathUtils.round(noExentaMap.get(key).getPercentage())));
					diet.setImporteCompensacionREAGYP(Double.toString(AonMathUtils.round(noExentaMap.get(key).getQuota())));
					frt.setClaveRegimenEspecialOTrascendencia(ClaveRegimenEspecialOTrascendenciaRecibidasType._02.getName());
				} else {
					diet.setCuotaSoportada(Double.toString(AonMathUtils.round(noExentaMap.get(key).getQuota())));
					diet.setTipoImpositivo(Double.toString(AonMathUtils.round(noExentaMap.get(key).getPercentage())));
				}
				if (noExentaMap.get(key).getSurchargePercent() > 0.0
						&& noExentaMap.get(key).getSurchargeQuota() > 0.0) {
					diet.setCuotaRecargoEquivalencia(
							Double.toString(AonMathUtils.round(noExentaMap.get(key).getSurchargeQuota())));
					diet.setTipoRecargoEquivalencia(
							Double.toString(AonMathUtils.round(noExentaMap.get(key).getSurchargePercent())));
				}
				diva.getDetalleIVA().add(diet);
			});
			dfrt.setDesgloseIVA(diva);
		}

		if (!pasivoList.isEmpty()) {
			HashMap<Double, VatData> pasivoMap = new HashMap<>();
			pasivoList.stream().forEach(r -> {
				if (pasivoMap.containsKey(r.getPercentage())) {
					VatData vd = pasivoMap.get(r.getPercentage());
					pasivoMap.get(r.getPercentage()).setBase(vd.getBase() + r.getBase());
					pasivoMap.get(r.getPercentage()).setQuota(vd.getQuota() + r.getQuota());
					pasivoMap.get(r.getPercentage())
							.setSurchargeQuota(vd.getSurchargeQuota() + r.getSurchargeQuota());
				} else pasivoMap.put(r.getPercentage(), r);
			});

			InversionSujetoPasivo isp = new InversionSujetoPasivo();
			pasivoMap.keySet().stream().forEach(key -> {
				DetalleIVARecibida2Type diet = new DetalleIVARecibida2Type();
				diet.setBaseImponible(Double.toString(AonMathUtils.round(pasivoMap.get(key).getBase()))); // TODO
				diet.setCuotaSoportada(Double.toString(AonMathUtils.round(pasivoMap.get(key).getQuota())));
				diet.setTipoImpositivo(Double.toString(AonMathUtils.round(pasivoMap.get(key).getPercentage())));
				if (pasivoMap.get(key).getSurchargePercent() > 0.0
						&& pasivoMap.get(key).getSurchargeQuota() > 0.0) {
					diet.setCuotaRecargoEquivalencia(
							Double.toString(AonMathUtils.round(pasivoMap.get(key).getSurchargeQuota())));
					diet.setTipoRecargoEquivalencia(
							Double.toString(AonMathUtils.round(pasivoMap.get(key).getSurchargePercent())));
				}
				isp.getDetalleIVA().add(diet);
			});
			dfrt.setInversionSujetoPasivo(isp);
		}
		frt.setDesgloseFactura(dfrt); // TODO
		factura.setFacturaRecibida(frt);

		suministro.getRegistroLRFacturasRecibidas().add(factura);
		System.out.println("SII FR GENERANDO XML - RETURN SUMINISTRO");
		return suministro;
	}

	protected BajaLRFacturasRecibidas bajaFacturasRecibidas(Company company, Integer invoiceId,
			LinkedList<VatContext> vatList, String terceros) {
		BajaLRFacturasRecibidas baja = new BajaLRFacturasRecibidas();
		baja.setCabecera(cabeceraBaja(company, terceros));

		VatContext vat = vatList.stream().filter(f -> f.getInvoice().equals(invoiceId)).findFirst().orElse(new VatContext());

		LRBajaRecibidasType factura = new LRBajaRecibidasType();

		IDFacturaRecibidaNombreBCType idFactura = new IDFacturaRecibidaNombreBCType();
		idFactura.setFechaExpedicionFacturaEmisor(AonDateUtils.format(vat.getIssueDate(), "dd-MM-yyyy"));
		idFactura.setNumSerieFacturaEmisor(vat.getReferenceCode());
		https.www2_agenciatributaria_gob_es.static_files.common.internet.dep.aplicaciones.es.aeat.ssii.fact.ws.suministroinformacion.IDFacturaRecibidaNombreBCType.IDEmisorFactura emisor = new https.www2_agenciatributaria_gob_es.static_files.common.internet.dep.aplicaciones.es.aeat.ssii.fact.ws.suministroinformacion.IDFacturaRecibidaNombreBCType.IDEmisorFactura();

		emisor.setNombreRazon(vat.getRegistryName());
		if (vat.getRegistryDocumentCountry().equals(Country.ES)) {
			emisor.setNIF(vat.getRegistryDocument());
		} else {
			IDOtroType otro = new IDOtroType();
			otro.setCodigoPais(CountryType2.valueOf(vat.getRegistryDocumentCountry().getIso2()));
			otro.setID(vat.getRegistryDocument());
			otro.setIDType(IDType.valueOf(vat.getRegistryDocumentType()).getName());
			emisor.setIDOtro(otro);
		}

		idFactura.setIDEmisorFactura(emisor);
		factura.setIDFactura(idFactura);

		factura.setPeriodoLiquidacion(periodoLiquidacion(vat, false));

		baja.getRegistroLRBajaRecibidas().add(factura);

		return baja;
	}

	// ------------------- SUMINISTRO FACTURAS RECIBIDAS PAGOS

	protected byte[] getSuministroFacturasRecibidasPagos(SuministroLRPagosRecibidas suministro) {
		JAXBContext ctx;
		byte[] b = null;
		try {
			ctx = JAXBContext.newInstance(SuministroLRPagosRecibidas.class);
			b = writeXml(ctx, suministro);
		} catch (JAXBException | IOException e) {
			e.printStackTrace();
		}
		return b;
	}

	protected byte[] getRespuestaSuministroFacturasRecibidasPagos(RespuestaLRPagosRecibidasType suministro) {
		JAXBContext ctx;
		byte[] b = null;
		try {
			ctx = JAXBContext.newInstance(RespuestaLRPagosRecibidasType.class);
			QName qName = new QName("https.www2_agenciatributaria_gob_es.static_files.common.internet.dep.aplicaciones.es.aeat.ssii.fact.ws.respuestasuministro", "RespuestaLRPagosRecibidasType");
		    JAXBElement<RespuestaLRPagosRecibidasType> root = new JAXBElement<>(qName, RespuestaLRPagosRecibidasType.class, suministro);
			b = writeXml(ctx, root);
		} catch (JAXBException | IOException e) {
			e.printStackTrace();
		}
		return b;
	}

	/**
	 * Libro de registro de Facturas recibidas, PAGOS.
	 * 
	 * @param company
	 */
	protected SuministroLRPagosRecibidas suministroFacturasRecibidasPagos(Domain domain, String login, Company company, LinkedList<Finance> financeList, Integer invoiceId) {
		SuministroLRPagosRecibidas suministro = new SuministroLRPagosRecibidas();

		// CABECERA
		suministro.setCabecera(cabeceraCobrosPagos(company));

		// FOR PAGOS

		LRPagosEmitidasType pagos = new LRPagosEmitidasType();
		PagosType pt = new PagosType();

		financeList.stream().filter(f -> f.getInvoice().getId().equals(invoiceId)).forEach(f -> {
			DatosPagoCobroType dpct = new DatosPagoCobroType();
			dpct.setFecha(AonDateUtils.format(f.getDueDate(), "dd-MM-yyyy"));
			dpct.setImporte(Double.toString(AonMathUtils.round(f.getAmount())));
			if (f.getPayMethodType().equals(PayMethodType.BANK_TRANSFER)) {
				dpct.setMedio("01");
			} else if (f.getPayMethodType().equals(PayMethodType.CHEQUE)) {
				dpct.setMedio("02");
			} else
				dpct.setMedio("04");
			pt.getPago().add(dpct);
		});
		pagos.setPagos(pt);
		Invoice invoice = financeList.stream().filter(f -> f.getInvoice().getId().equals(invoiceId)).findFirst().get().getInvoice();

		IDFacturaRecibidaNombreBCType f = new IDFacturaRecibidaNombreBCType();
		f.setFechaExpedicionFacturaEmisor(AonDateUtils.format(invoice.getIssueDate(), "dd-MM-yyyy"));

		https.www2_agenciatributaria_gob_es.static_files.common.internet.dep.aplicaciones.es.aeat.ssii.fact.ws.suministroinformacion.IDFacturaRecibidaNombreBCType.IDEmisorFactura emisor = new https.www2_agenciatributaria_gob_es.static_files.common.internet.dep.aplicaciones.es.aeat.ssii.fact.ws.suministroinformacion.IDFacturaRecibidaNombreBCType.IDEmisorFactura();
		emisor.setNombreRazon(invoice.getRegistryName());
		if (invoice.getRegistryDocumentCountry().equals(Country.ES)) {
			emisor.setNIF(invoice.getRegistryDocument());
		} else {
			IDOtroType otro = new IDOtroType();
			otro.setCodigoPais(CountryType2.valueOf(invoice.getRegistryDocumentCountry().getIso2()));
			otro.setID(invoice.getRegistryDocument());
			otro.setIDType(IDType.valueOf(invoice.getRegistryDocumentType()).getName());
			emisor.setIDOtro(otro);
		}
		f.setIDEmisorFactura(emisor);
		f.setNumSerieFacturaEmisor(invoice.getReferenceCode());
		pagos.setIDFactura(f);

		suministro.getRegistroLRPagos().add(pagos);
		return suministro;
	}
	
	// -------------------- FUNCIONES
	
	/**
	 * Devuelve la cabecera para cobros y pagos.
	 * 
	 * @param company
	 * @return CabeceraSiiCobrosPagos
	 */
	private CabeceraSiiCobrosPagos cabeceraCobrosPagos(Company company){
		CabeceraSiiCobrosPagos cabecera = new CabeceraSiiCobrosPagos();
		cabecera.setIDVersionSii("1.1");
		PersonaFisicaJuridicaESType titular = new PersonaFisicaJuridicaESType();
		titular.setNIF(company.getDocument());
		titular.setNombreRazon(company.getName());
		cabecera.setTitular(titular);
		return cabecera;
	}
	
	/**
	 * Devuelve la cabecera.
	 * 
	 * @param company
	 * @return CabeceraSii
	 */
	public CabeceraSii cabecera(Company company, Boolean mod, String terceros){
		CabeceraSii cabecera = new CabeceraSii();
		cabecera.setIDVersionSii("1.1");
		cabecera.setTipoComunicacion(mod ? ClaveTipoComunicacionType.A_1 : ClaveTipoComunicacionType.A_0);
		PersonaFisicaJuridicaESType titular = new PersonaFisicaJuridicaESType();
		titular.setNIF(company.getDocument());
		titular.setNombreRazon(company.getName());
		if(terceros != null && !terceros.equals("false"))
			titular.setNIFRepresentante(terceros);
		cabecera.setTitular(titular);
		
		
		return cabecera;
	}
	public CabeceraSii cabecera(Company company){
		CabeceraSii cabecera = new CabeceraSii();
		cabecera.setIDVersionSii("1.1");
		cabecera.setTipoComunicacion(ClaveTipoComunicacionType.A_0);
		PersonaFisicaJuridicaESType titular = new PersonaFisicaJuridicaESType();
		titular.setNIF(company.getDocument());
		titular.setNombreRazon(company.getName());
		cabecera.setTitular(titular);
		return cabecera;
	}
	
	/**
	 * Devuelve la cabecera para bajas.
	 * 
	 * @param company
	 * @return CabeceraSiiBaja
	 */
	private CabeceraSiiBaja cabeceraBaja(Company company, String terceros){
		CabeceraSiiBaja cabecera = new CabeceraSiiBaja();
		cabecera.setIDVersionSii("1.1");
		PersonaFisicaJuridicaESType titular = new PersonaFisicaJuridicaESType();
		titular.setNIF(company.getDocument());
		titular.setNombreRazon(company.getName());
		if(terceros != null && !terceros.equals("false"))
			titular.setNIFRepresentante(terceros);
		cabecera.setTitular(titular);
		return cabecera;
	}
	
	/**
	 * Devuelve la contraparte, persona fisica o juridica (cliente � proveedor).
	 * 
	 * @param invoice
	 * @return PersonaFisicaJuridicaType
	 */
	private PersonaFisicaJuridicaType contraparte(VatContext vat) {
		PersonaFisicaJuridicaType contraparte = new PersonaFisicaJuridicaType();
		contraparte.setNombreRazon(vat.getRegistryName());
	
		if((vat.getRegistryDocumentCountry() == null || vat.getRegistryDocumentCountry().equals(Country.ES))
				&& (!vat.getInvoiceType().equals(InvoiceType.SALES) || !isPersonaFisica(vat.getRegistryDocument()) ||  validateNif(vat.getRegistryDocument(), vat.getRegistryName(), vat.getRegistryDocumentType()))){
			contraparte.setNIF(vat.getRegistryDocument());
		} else {
			IDOtroType otro = new IDOtroType();
			otro.setCodigoPais(CountryType2.valueOf(vat.getRegistryDocumentCountry().getIso2()));
			otro.setID(vat.getRegistryDocument());
			otro.setIDType(vat.getRegistryDocumentCountry().equals(Country.ES) ? 
				IDType.NO_CENSADO.getName() : IDType.valueOf(vat.getRegistryDocumentType()).getName());
			contraparte.setIDOtro(otro);
		}	
		return contraparte;
	}
	
	private PersonaFisicaJuridicaType contraparteIntracomunitario(VatContext vat) {
		PersonaFisicaJuridicaType contraparte = new PersonaFisicaJuridicaType();
		contraparte.setNombreRazon(vat.getRegistryName());
		if(vat.getRegistryDocumentCountry().equals(Country.ES)
				&& validateNif(vat.getRegistryDocument(), vat.getRegistryName(),vat.getRegistryDocumentType())){
			contraparte.setNIF(vat.getRegistryDocument());
		} else {
			IDOtroType otro = new IDOtroType();
			otro.setCodigoPais(CountryType2.valueOf(vat.getRegistryDocumentCountry().getIso2()));

			String document = vat.getRegistryDocument();
			if(!document.substring(0,2).equalsIgnoreCase(vat.getRegistryDocumentCountry().getIso2())) {
				document = vat.getRegistryDocumentCountry().getIso2() + document;
			}
			otro.setID(document);		
			
			otro.setIDType(IDType.NIF_IVA.getName());
			contraparte.setIDOtro(otro);
		}	
		return contraparte;
	}
	
	private Boolean isPersonaFisica(String document){
		String pri = document.substring(0, 1);
	return document.length() == 9 
		&& (isNumber(pri) || pri.equals("L") || pri.equals("K"));
	}
	
	private Boolean isNumber(String s) {
		try {
			Integer.parseInt(s);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	public Boolean validateNif(String nif, String name, DocumentType type) {
		return !type.equals(DocumentType.NOT_CENSUSED);
		/*
		VNifV1Ent vnif = new VNifV1Ent();
		vnif.setNif(nif);
		vnif.setNombre(name);
		return NIFPost.getInstance(cert, pass).vnifV1(vnif);
		*/
	}
	
	public static byte[] writeXml(JAXBContext ctx, Object object) throws JAXBException, IOException{		
		Marshaller marshaller = ctx.createMarshaller();
		marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
		
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		marshaller.marshal(object, baos);
		baos.close();

		return baos.toByteArray();
	}

	public static Object readXml(JAXBContext ctx, byte[] xmlFile) throws JAXBException{
		Unmarshaller unmarshaller = ctx.createUnmarshaller();
	
		InputStream input = new ByteArrayInputStream(xmlFile);
		return unmarshaller.unmarshal(input);
	}
}
