
package eus.bizkaia.ogasuna.sii.documentos.suministrolr;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import eus.bizkaia.ogasuna.sii.documentos.suministroinformacion.IDFacturaExpedidaBCType;


/**
 * <p>Java class for LRInmueblesType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="LRInmueblesType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="IDFactura" type="{http://www.bizkaia.eus/ogasuna/sii/documentos/SuministroInformacion.xsd}IDFacturaExpedidaBCType"/&gt;
 *         &lt;element name="DatosInmueble" type="{http://www.bizkaia.eus/ogasuna/sii/documentos/SuministroLR.xsd}InmueblesAdicionalType"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "LRInmueblesType", propOrder = {
    "idFactura",
    "datosInmueble"
})
public class LRInmueblesType {

    @XmlElement(name = "IDFactura", required = true)
    protected IDFacturaExpedidaBCType idFactura;
    @XmlElement(name = "DatosInmueble", required = true)
    protected InmueblesAdicionalType datosInmueble;

    /**
     * Gets the value of the idFactura property.
     * 
     * @return
     *     possible object is
     *     {@link IDFacturaExpedidaBCType }
     *     
     */
    public IDFacturaExpedidaBCType getIDFactura() {
        return idFactura;
    }

    /**
     * Sets the value of the idFactura property.
     * 
     * @param value
     *     allowed object is
     *     {@link IDFacturaExpedidaBCType }
     *     
     */
    public void setIDFactura(IDFacturaExpedidaBCType value) {
        this.idFactura = value;
    }

    /**
     * Gets the value of the datosInmueble property.
     * 
     * @return
     *     possible object is
     *     {@link InmueblesAdicionalType }
     *     
     */
    public InmueblesAdicionalType getDatosInmueble() {
        return datosInmueble;
    }

    /**
     * Sets the value of the datosInmueble property.
     * 
     * @param value
     *     allowed object is
     *     {@link InmueblesAdicionalType }
     *     
     */
    public void setDatosInmueble(InmueblesAdicionalType value) {
        this.datosInmueble = value;
    }

}
