
package https.sii_araba_eus.documentos.suministroinformacion;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import https.sii_araba_eus.documentos.suministrolr.SuministroLRCobrosEmitidas;
import https.sii_araba_eus.documentos.suministrolr.SuministroLRPagosRecibidas;


/**
 *  Sii - Suministro Inmediato de Informaci�n, compuesto por datos 
 * 			                              de contexto y una secuencia de 1 o m�s registros. 
 * 
 * <p>Java class for SuministroInformacionCobrosPagos complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="SuministroInformacionCobrosPagos"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Cabecera" type="{https://sii.araba.eus/documentos/SuministroInformacion.xsd}CabeceraSiiCobrosPagos"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SuministroInformacionCobrosPagos", propOrder = {
    "cabecera"
})
@XmlSeeAlso({
    SuministroLRPagosRecibidas.class,
    SuministroLRCobrosEmitidas.class
})
public class SuministroInformacionCobrosPagos {

    @XmlElement(name = "Cabecera", required = true)
    protected CabeceraSiiCobrosPagos cabecera;

    /**
     * Gets the value of the cabecera property.
     * 
     * @return
     *     possible object is
     *     {@link CabeceraSiiCobrosPagos }
     *     
     */
    public CabeceraSiiCobrosPagos getCabecera() {
        return cabecera;
    }

    /**
     * Sets the value of the cabecera property.
     * 
     * @param value
     *     allowed object is
     *     {@link CabeceraSiiCobrosPagos }
     *     
     */
    public void setCabecera(CabeceraSiiCobrosPagos value) {
        this.cabecera = value;
    }

}
