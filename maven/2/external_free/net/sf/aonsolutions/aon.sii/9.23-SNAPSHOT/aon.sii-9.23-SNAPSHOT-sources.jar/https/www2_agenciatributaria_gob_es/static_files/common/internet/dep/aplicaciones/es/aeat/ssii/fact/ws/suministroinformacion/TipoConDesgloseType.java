
package https.www2_agenciatributaria_gob_es.static_files.common.internet.dep.aplicaciones.es.aeat.ssii.fact.ws.suministroinformacion;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * Desglose de Tipo de Operacion diferenciando entre Entrega de Bienes o Prestacion de Servicios
 * 
 * <p>Java class for TipoConDesgloseType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="TipoConDesgloseType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="PrestacionServicios" type="{https://www2.agenciatributaria.gob.es/static_files/common/internet/dep/aplicaciones/es/aeat/ssii/fact/ws/SuministroInformacion.xsd}TipoSinDesglosePrestacionType" minOccurs="0"/&gt;
 *         &lt;element name="Entrega" type="{https://www2.agenciatributaria.gob.es/static_files/common/internet/dep/aplicaciones/es/aeat/ssii/fact/ws/SuministroInformacion.xsd}TipoSinDesgloseType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TipoConDesgloseType", propOrder = {
    "prestacionServicios",
    "entrega"
})
public class TipoConDesgloseType {

    @XmlElement(name = "PrestacionServicios")
    protected TipoSinDesglosePrestacionType prestacionServicios;
    @XmlElement(name = "Entrega")
    protected TipoSinDesgloseType entrega;

    /**
     * Gets the value of the prestacionServicios property.
     * 
     * @return
     *     possible object is
     *     {@link TipoSinDesglosePrestacionType }
     *     
     */
    public TipoSinDesglosePrestacionType getPrestacionServicios() {
        return prestacionServicios;
    }

    /**
     * Sets the value of the prestacionServicios property.
     * 
     * @param value
     *     allowed object is
     *     {@link TipoSinDesglosePrestacionType }
     *     
     */
    public void setPrestacionServicios(TipoSinDesglosePrestacionType value) {
        this.prestacionServicios = value;
    }

    /**
     * Gets the value of the entrega property.
     * 
     * @return
     *     possible object is
     *     {@link TipoSinDesgloseType }
     *     
     */
    public TipoSinDesgloseType getEntrega() {
        return entrega;
    }

    /**
     * Sets the value of the entrega property.
     * 
     * @param value
     *     allowed object is
     *     {@link TipoSinDesgloseType }
     *     
     */
    public void setEntrega(TipoSinDesgloseType value) {
        this.entrega = value;
    }

}
