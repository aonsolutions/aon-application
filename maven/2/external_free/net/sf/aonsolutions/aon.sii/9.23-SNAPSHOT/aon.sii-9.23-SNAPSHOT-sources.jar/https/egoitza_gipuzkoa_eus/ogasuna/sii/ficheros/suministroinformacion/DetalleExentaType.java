
package https.egoitza_gipuzkoa_eus.ogasuna.sii.ficheros.suministroinformacion;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for DetalleExentaType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DetalleExentaType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="CausaExencion" type="{https://egoitza.gipuzkoa.eus/ogasuna/sii/ficheros/SuministroInformacion.xsd}CausaExencionType" minOccurs="0"/&gt;
 *         &lt;element name="BaseImponible" type="{https://egoitza.gipuzkoa.eus/ogasuna/sii/ficheros/SuministroInformacion.xsd}ImporteSgn12.2Type"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DetalleExentaType", propOrder = {
    "causaExencion",
    "baseImponible"
})
public class DetalleExentaType {

    @XmlElement(name = "CausaExencion")
    @XmlSchemaType(name = "string")
    protected CausaExencionType causaExencion;
    @XmlElement(name = "BaseImponible", required = true)
    protected String baseImponible;

    /**
     * Gets the value of the causaExencion property.
     * 
     * @return
     *     possible object is
     *     {@link CausaExencionType }
     *     
     */
    public CausaExencionType getCausaExencion() {
        return causaExencion;
    }

    /**
     * Sets the value of the causaExencion property.
     * 
     * @param value
     *     allowed object is
     *     {@link CausaExencionType }
     *     
     */
    public void setCausaExencion(CausaExencionType value) {
        this.causaExencion = value;
    }

    /**
     * Gets the value of the baseImponible property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBaseImponible() {
        return baseImponible;
    }

    /**
     * Sets the value of the baseImponible property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBaseImponible(String value) {
        this.baseImponible = value;
    }

}
