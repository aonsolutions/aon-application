
package https.sii_araba_eus.documentos.suministroinformacion;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for DatosInmuebleType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DatosInmuebleType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="SituacionInmueble" type="{https://sii.araba.eus/documentos/SuministroInformacion.xsd}SituacionInmuebleType"/&gt;
 *         &lt;element name="ReferenciaCatastral" type="{https://sii.araba.eus/documentos/SuministroInformacion.xsd}ReferenciaCatastralType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DatosInmuebleType", propOrder = {
    "situacionInmueble",
    "referenciaCatastral"
})
public class DatosInmuebleType {

    @XmlElement(name = "SituacionInmueble", required = true)
    protected String situacionInmueble;
    @XmlElement(name = "ReferenciaCatastral")
    protected String referenciaCatastral;

    /**
     * Gets the value of the situacionInmueble property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSituacionInmueble() {
        return situacionInmueble;
    }

    /**
     * Sets the value of the situacionInmueble property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSituacionInmueble(String value) {
        this.situacionInmueble = value;
    }

    /**
     * Gets the value of the referenciaCatastral property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReferenciaCatastral() {
        return referenciaCatastral;
    }

    /**
     * Sets the value of the referenciaCatastral property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReferenciaCatastral(String value) {
        this.referenciaCatastral = value;
    }

}
