
package eus.bizkaia.ogasuna.sii.documentos.suministroinformacion;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 *  Datos de contexto de un suministro sin especificar el timpo de comunicacion 
 * 
 * <p>Java class for CabeceraConsultaSiiCliente complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CabeceraConsultaSiiCliente"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="IDVersionSii" type="{http://www.bizkaia.eus/ogasuna/sii/documentos/SuministroInformacion.xsd}VersionSiiType"/&gt;
 *         &lt;element name="TitularLRFE" type="{http://www.bizkaia.eus/ogasuna/sii/documentos/SuministroInformacion.xsd}PersonaFisicaJuridicaUnicaESType"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CabeceraConsultaSiiCliente", propOrder = {
    "idVersionSii",
    "titularLRFE"
})
public class CabeceraConsultaSiiCliente {

    @XmlElement(name = "IDVersionSii", required = true)
    protected String idVersionSii;
    @XmlElement(name = "TitularLRFE", required = true)
    protected PersonaFisicaJuridicaUnicaESType titularLRFE;

    /**
     * Gets the value of the idVersionSii property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIDVersionSii() {
        return idVersionSii;
    }

    /**
     * Sets the value of the idVersionSii property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIDVersionSii(String value) {
        this.idVersionSii = value;
    }

    /**
     * Gets the value of the titularLRFE property.
     * 
     * @return
     *     possible object is
     *     {@link PersonaFisicaJuridicaUnicaESType }
     *     
     */
    public PersonaFisicaJuridicaUnicaESType getTitularLRFE() {
        return titularLRFE;
    }

    /**
     * Sets the value of the titularLRFE property.
     * 
     * @param value
     *     allowed object is
     *     {@link PersonaFisicaJuridicaUnicaESType }
     *     
     */
    public void setTitularLRFE(PersonaFisicaJuridicaUnicaESType value) {
        this.titularLRFE = value;
    }

}
