
package https.egoitza_gipuzkoa_eus.ogasuna.sii.ficheros.suministroinformacion;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import https.egoitza_gipuzkoa_eus.ogasuna.sii.ficheros.consultalr.LRFiltroFactInformadasAgrupadasClienteType;
import https.egoitza_gipuzkoa_eus.ogasuna.sii.ficheros.consultalr.LRFiltroFactInformadasAgrupadasProveedorType;
import https.egoitza_gipuzkoa_eus.ogasuna.sii.ficheros.consultalr.LRFiltroFactInformadasClienteType;
import https.egoitza_gipuzkoa_eus.ogasuna.sii.ficheros.consultalr.LRFiltroFactInformadasProveedorType;


/**
 *  Informaci�n b�sica que contienen los registros de imputacion 
 * 
 * <p>Java class for RegistroSiiImputacion complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="RegistroSiiImputacion"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="PeriodoImputacion"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="EjercicioImputacion" type="{https://egoitza.gipuzkoa.eus/ogasuna/sii/ficheros/SuministroInformacion.xsd}YearType"/&gt;
 *                   &lt;element name="PeriodoImputacion" type="{https://egoitza.gipuzkoa.eus/ogasuna/sii/ficheros/SuministroInformacion.xsd}TipoPeriodoType"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "RegistroSiiImputacion", propOrder = {
    "periodoImputacion"
})
@XmlSeeAlso({
    LRFiltroFactInformadasClienteType.class,
    LRFiltroFactInformadasAgrupadasClienteType.class,
    LRFiltroFactInformadasProveedorType.class,
    LRFiltroFactInformadasAgrupadasProveedorType.class
})
public class RegistroSiiImputacion {

    @XmlElement(name = "PeriodoImputacion", required = true)
    protected RegistroSiiImputacion.PeriodoImputacion periodoImputacion;

    /**
     * Gets the value of the periodoImputacion property.
     * 
     * @return
     *     possible object is
     *     {@link RegistroSiiImputacion.PeriodoImputacion }
     *     
     */
    public RegistroSiiImputacion.PeriodoImputacion getPeriodoImputacion() {
        return periodoImputacion;
    }

    /**
     * Sets the value of the periodoImputacion property.
     * 
     * @param value
     *     allowed object is
     *     {@link RegistroSiiImputacion.PeriodoImputacion }
     *     
     */
    public void setPeriodoImputacion(RegistroSiiImputacion.PeriodoImputacion value) {
        this.periodoImputacion = value;
    }


    /**
     *  Per�odo de imputacion de la factura 
     * 
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="EjercicioImputacion" type="{https://egoitza.gipuzkoa.eus/ogasuna/sii/ficheros/SuministroInformacion.xsd}YearType"/&gt;
     *         &lt;element name="PeriodoImputacion" type="{https://egoitza.gipuzkoa.eus/ogasuna/sii/ficheros/SuministroInformacion.xsd}TipoPeriodoType"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "ejercicioImputacion",
        "periodoImputacion"
    })
    public static class PeriodoImputacion {

        @XmlElement(name = "EjercicioImputacion", required = true)
        protected String ejercicioImputacion;
        @XmlElement(name = "PeriodoImputacion", required = true)
        protected String periodoImputacion;

        /**
         * Gets the value of the ejercicioImputacion property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getEjercicioImputacion() {
            return ejercicioImputacion;
        }

        /**
         * Sets the value of the ejercicioImputacion property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setEjercicioImputacion(String value) {
            this.ejercicioImputacion = value;
        }

        /**
         * Gets the value of the periodoImputacion property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getPeriodoImputacion() {
            return periodoImputacion;
        }

        /**
         * Sets the value of the periodoImputacion property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setPeriodoImputacion(String value) {
            this.periodoImputacion = value;
        }

    }

}
