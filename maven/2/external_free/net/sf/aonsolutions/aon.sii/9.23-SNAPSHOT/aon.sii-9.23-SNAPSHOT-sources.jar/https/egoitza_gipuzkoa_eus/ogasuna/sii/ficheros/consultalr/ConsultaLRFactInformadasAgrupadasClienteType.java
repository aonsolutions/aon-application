
package https.egoitza_gipuzkoa_eus.ogasuna.sii.ficheros.consultalr;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import https.egoitza_gipuzkoa_eus.ogasuna.sii.ficheros.suministroinformacion.ConsultaInformacionCliente;


/**
 * <p>Java class for ConsultaLRFactInformadasAgrupadasClienteType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ConsultaLRFactInformadasAgrupadasClienteType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{https://egoitza.gipuzkoa.eus/ogasuna/sii/ficheros/SuministroInformacion.xsd}ConsultaInformacionCliente"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="FiltroConsulta" type="{https://egoitza.gipuzkoa.eus/ogasuna/sii/ficheros/ConsultaLR.xsd}LRFiltroFactInformadasAgrupadasClienteType"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ConsultaLRFactInformadasAgrupadasClienteType", propOrder = {
    "filtroConsulta"
})
public class ConsultaLRFactInformadasAgrupadasClienteType
    extends ConsultaInformacionCliente
{

    @XmlElement(name = "FiltroConsulta", required = true)
    protected LRFiltroFactInformadasAgrupadasClienteType filtroConsulta;

    /**
     * Gets the value of the filtroConsulta property.
     * 
     * @return
     *     possible object is
     *     {@link LRFiltroFactInformadasAgrupadasClienteType }
     *     
     */
    public LRFiltroFactInformadasAgrupadasClienteType getFiltroConsulta() {
        return filtroConsulta;
    }

    /**
     * Sets the value of the filtroConsulta property.
     * 
     * @param value
     *     allowed object is
     *     {@link LRFiltroFactInformadasAgrupadasClienteType }
     *     
     */
    public void setFiltroConsulta(LRFiltroFactInformadasAgrupadasClienteType value) {
        this.filtroConsulta = value;
    }

}
