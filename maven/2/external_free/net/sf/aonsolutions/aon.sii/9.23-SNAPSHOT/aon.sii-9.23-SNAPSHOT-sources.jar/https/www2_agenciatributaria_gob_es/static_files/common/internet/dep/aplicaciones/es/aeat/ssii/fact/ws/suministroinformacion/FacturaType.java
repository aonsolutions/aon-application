
package https.www2_agenciatributaria_gob_es.static_files.common.internet.dep.aplicaciones.es.aeat.ssii.fact.ws.suministroinformacion;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;


/**
 *  Datos comunes de facturas emitidas y recibidas 
 * 
 * <p>Java class for FacturaType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="FacturaType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="TipoFactura" type="{https://www2.agenciatributaria.gob.es/static_files/common/internet/dep/aplicaciones/es/aeat/ssii/fact/ws/SuministroInformacion.xsd}ClaveTipoFacturaType"/&gt;
 *         &lt;element name="TipoRectificativa" type="{https://www2.agenciatributaria.gob.es/static_files/common/internet/dep/aplicaciones/es/aeat/ssii/fact/ws/SuministroInformacion.xsd}ClaveTipoRectificativaType" minOccurs="0"/&gt;
 *         &lt;element name="FacturasAgrupadas" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="IDFacturaAgrupada" type="{https://www2.agenciatributaria.gob.es/static_files/common/internet/dep/aplicaciones/es/aeat/ssii/fact/ws/SuministroInformacion.xsd}IDFacturaARType" maxOccurs="unbounded"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="FacturasRectificadas" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="IDFacturaRectificada" type="{https://www2.agenciatributaria.gob.es/static_files/common/internet/dep/aplicaciones/es/aeat/ssii/fact/ws/SuministroInformacion.xsd}IDFacturaARType" maxOccurs="unbounded"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ImporteRectificacion" type="{https://www2.agenciatributaria.gob.es/static_files/common/internet/dep/aplicaciones/es/aeat/ssii/fact/ws/SuministroInformacion.xsd}DesgloseRectificacionType" minOccurs="0"/&gt;
 *         &lt;element name="FechaOperacion" type="{https://www2.agenciatributaria.gob.es/static_files/common/internet/dep/aplicaciones/es/aeat/ssii/fact/ws/SuministroInformacion.xsd}fecha" minOccurs="0"/&gt;
 *         &lt;element name="ClaveRegimenEspecialOTrascendencia" type="{https://www2.agenciatributaria.gob.es/static_files/common/internet/dep/aplicaciones/es/aeat/ssii/fact/ws/SuministroInformacion.xsd}IdOperacionesTrascendenciaTributariaType"/&gt;
 *         &lt;element name="ClaveRegimenEspecialOTrascendenciaAdicional1" type="{https://www2.agenciatributaria.gob.es/static_files/common/internet/dep/aplicaciones/es/aeat/ssii/fact/ws/SuministroInformacion.xsd}IdOperacionesTrascendenciaTributariaType" minOccurs="0"/&gt;
 *         &lt;element name="ClaveRegimenEspecialOTrascendenciaAdicional2" type="{https://www2.agenciatributaria.gob.es/static_files/common/internet/dep/aplicaciones/es/aeat/ssii/fact/ws/SuministroInformacion.xsd}IdOperacionesTrascendenciaTributariaType" minOccurs="0"/&gt;
 *         &lt;element name="NumRegistroAcuerdoFacturacion" type="{https://www2.agenciatributaria.gob.es/static_files/common/internet/dep/aplicaciones/es/aeat/ssii/fact/ws/SuministroInformacion.xsd}TextMax15Type" minOccurs="0"/&gt;
 *         &lt;element name="ImporteTotal" type="{https://www2.agenciatributaria.gob.es/static_files/common/internet/dep/aplicaciones/es/aeat/ssii/fact/ws/SuministroInformacion.xsd}ImporteSgn12.2Type" minOccurs="0"/&gt;
 *         &lt;element name="BaseImponibleACoste" type="{https://www2.agenciatributaria.gob.es/static_files/common/internet/dep/aplicaciones/es/aeat/ssii/fact/ws/SuministroInformacion.xsd}ImporteSgn12.2Type" minOccurs="0"/&gt;
 *         &lt;element name="DescripcionOperacion" type="{https://www2.agenciatributaria.gob.es/static_files/common/internet/dep/aplicaciones/es/aeat/ssii/fact/ws/SuministroInformacion.xsd}TextMax500Type"/&gt;
 *         &lt;element name="RefExterna" type="{https://www2.agenciatributaria.gob.es/static_files/common/internet/dep/aplicaciones/es/aeat/ssii/fact/ws/SuministroInformacion.xsd}TextMax60Type" minOccurs="0"/&gt;
 *         &lt;element name="FacturaSimplificadaArticulos7.2_7.3" type="{https://www2.agenciatributaria.gob.es/static_files/common/internet/dep/aplicaciones/es/aeat/ssii/fact/ws/SuministroInformacion.xsd}SimplificadaCualificadaType" minOccurs="0"/&gt;
 *         &lt;element name="EntidadSucedida" type="{https://www2.agenciatributaria.gob.es/static_files/common/internet/dep/aplicaciones/es/aeat/ssii/fact/ws/SuministroInformacion.xsd}PersonaFisicaJuridicaUnicaESType" minOccurs="0"/&gt;
 *         &lt;element name="RegPrevioGGEEoREDEMEoCompetencia" type="{https://www2.agenciatributaria.gob.es/static_files/common/internet/dep/aplicaciones/es/aeat/ssii/fact/ws/SuministroInformacion.xsd}RegPrevioGGEEoREDEMEoCompetenciaType" minOccurs="0"/&gt;
 *         &lt;element name="Macrodato" type="{https://www2.agenciatributaria.gob.es/static_files/common/internet/dep/aplicaciones/es/aeat/ssii/fact/ws/SuministroInformacion.xsd}MacrodatoType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FacturaType", propOrder = {
    "tipoFactura",
    "tipoRectificativa",
    "facturasAgrupadas",
    "facturasRectificadas",
    "importeRectificacion",
    "fechaOperacion",
    "claveRegimenEspecialOTrascendencia",
    "claveRegimenEspecialOTrascendenciaAdicional1",
    "claveRegimenEspecialOTrascendenciaAdicional2",
    "numRegistroAcuerdoFacturacion",
    "importeTotal",
    "baseImponibleACoste",
    "descripcionOperacion",
    "refExterna",
    "facturaSimplificadaArticulos7273",
    "entidadSucedida",
    "regPrevioGGEEoREDEMEoCompetencia",
    "macrodato"
})
@XmlSeeAlso({
    FacturaExpedidaType.class,
    FacturaRecibidaType.class
})
public class FacturaType {

    @XmlElement(name = "TipoFactura", required = true)
    @XmlSchemaType(name = "string")
    protected ClaveTipoFacturaType tipoFactura;
    @XmlElement(name = "TipoRectificativa")
    protected String tipoRectificativa;
    @XmlElement(name = "FacturasAgrupadas")
    protected FacturaType.FacturasAgrupadas facturasAgrupadas;
    @XmlElement(name = "FacturasRectificadas")
    protected FacturaType.FacturasRectificadas facturasRectificadas;
    @XmlElement(name = "ImporteRectificacion")
    protected DesgloseRectificacionType importeRectificacion;
    @XmlElement(name = "FechaOperacion")
    protected String fechaOperacion;
    @XmlElement(name = "ClaveRegimenEspecialOTrascendencia", required = true)
    protected String claveRegimenEspecialOTrascendencia;
    @XmlElement(name = "ClaveRegimenEspecialOTrascendenciaAdicional1")
    protected String claveRegimenEspecialOTrascendenciaAdicional1;
    @XmlElement(name = "ClaveRegimenEspecialOTrascendenciaAdicional2")
    protected String claveRegimenEspecialOTrascendenciaAdicional2;
    @XmlElement(name = "NumRegistroAcuerdoFacturacion")
    protected String numRegistroAcuerdoFacturacion;
    @XmlElement(name = "ImporteTotal")
    protected String importeTotal;
    @XmlElement(name = "BaseImponibleACoste")
    protected String baseImponibleACoste;
    @XmlElement(name = "DescripcionOperacion", required = true)
    protected String descripcionOperacion;
    @XmlElement(name = "RefExterna")
    protected String refExterna;
    @XmlElement(name = "FacturaSimplificadaArticulos7.2_7.3")
    @XmlSchemaType(name = "string")
    protected SimplificadaCualificadaType facturaSimplificadaArticulos7273;
    @XmlElement(name = "EntidadSucedida")
    protected PersonaFisicaJuridicaUnicaESType entidadSucedida;
    @XmlElement(name = "RegPrevioGGEEoREDEMEoCompetencia")
    @XmlSchemaType(name = "string")
    protected RegPrevioGGEEoREDEMEoCompetenciaType regPrevioGGEEoREDEMEoCompetencia;
    @XmlElement(name = "Macrodato")
    @XmlSchemaType(name = "string")
    protected MacrodatoType macrodato;

    /**
     * Gets the value of the tipoFactura property.
     * 
     * @return
     *     possible object is
     *     {@link ClaveTipoFacturaType }
     *     
     */
    public ClaveTipoFacturaType getTipoFactura() {
        return tipoFactura;
    }

    /**
     * Sets the value of the tipoFactura property.
     * 
     * @param value
     *     allowed object is
     *     {@link ClaveTipoFacturaType }
     *     
     */
    public void setTipoFactura(ClaveTipoFacturaType value) {
        this.tipoFactura = value;
    }

    /**
     * Gets the value of the tipoRectificativa property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTipoRectificativa() {
        return tipoRectificativa;
    }

    /**
     * Sets the value of the tipoRectificativa property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTipoRectificativa(String value) {
        this.tipoRectificativa = value;
    }

    /**
     * Gets the value of the facturasAgrupadas property.
     * 
     * @return
     *     possible object is
     *     {@link FacturaType.FacturasAgrupadas }
     *     
     */
    public FacturaType.FacturasAgrupadas getFacturasAgrupadas() {
        return facturasAgrupadas;
    }

    /**
     * Sets the value of the facturasAgrupadas property.
     * 
     * @param value
     *     allowed object is
     *     {@link FacturaType.FacturasAgrupadas }
     *     
     */
    public void setFacturasAgrupadas(FacturaType.FacturasAgrupadas value) {
        this.facturasAgrupadas = value;
    }

    /**
     * Gets the value of the facturasRectificadas property.
     * 
     * @return
     *     possible object is
     *     {@link FacturaType.FacturasRectificadas }
     *     
     */
    public FacturaType.FacturasRectificadas getFacturasRectificadas() {
        return facturasRectificadas;
    }

    /**
     * Sets the value of the facturasRectificadas property.
     * 
     * @param value
     *     allowed object is
     *     {@link FacturaType.FacturasRectificadas }
     *     
     */
    public void setFacturasRectificadas(FacturaType.FacturasRectificadas value) {
        this.facturasRectificadas = value;
    }

    /**
     * Gets the value of the importeRectificacion property.
     * 
     * @return
     *     possible object is
     *     {@link DesgloseRectificacionType }
     *     
     */
    public DesgloseRectificacionType getImporteRectificacion() {
        return importeRectificacion;
    }

    /**
     * Sets the value of the importeRectificacion property.
     * 
     * @param value
     *     allowed object is
     *     {@link DesgloseRectificacionType }
     *     
     */
    public void setImporteRectificacion(DesgloseRectificacionType value) {
        this.importeRectificacion = value;
    }

    /**
     * Gets the value of the fechaOperacion property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFechaOperacion() {
        return fechaOperacion;
    }

    /**
     * Sets the value of the fechaOperacion property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFechaOperacion(String value) {
        this.fechaOperacion = value;
    }

    /**
     * Gets the value of the claveRegimenEspecialOTrascendencia property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClaveRegimenEspecialOTrascendencia() {
        return claveRegimenEspecialOTrascendencia;
    }

    /**
     * Sets the value of the claveRegimenEspecialOTrascendencia property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClaveRegimenEspecialOTrascendencia(String value) {
        this.claveRegimenEspecialOTrascendencia = value;
    }

    /**
     * Gets the value of the claveRegimenEspecialOTrascendenciaAdicional1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClaveRegimenEspecialOTrascendenciaAdicional1() {
        return claveRegimenEspecialOTrascendenciaAdicional1;
    }

    /**
     * Sets the value of the claveRegimenEspecialOTrascendenciaAdicional1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClaveRegimenEspecialOTrascendenciaAdicional1(String value) {
        this.claveRegimenEspecialOTrascendenciaAdicional1 = value;
    }

    /**
     * Gets the value of the claveRegimenEspecialOTrascendenciaAdicional2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClaveRegimenEspecialOTrascendenciaAdicional2() {
        return claveRegimenEspecialOTrascendenciaAdicional2;
    }

    /**
     * Sets the value of the claveRegimenEspecialOTrascendenciaAdicional2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClaveRegimenEspecialOTrascendenciaAdicional2(String value) {
        this.claveRegimenEspecialOTrascendenciaAdicional2 = value;
    }

    /**
     * Gets the value of the numRegistroAcuerdoFacturacion property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNumRegistroAcuerdoFacturacion() {
        return numRegistroAcuerdoFacturacion;
    }

    /**
     * Sets the value of the numRegistroAcuerdoFacturacion property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNumRegistroAcuerdoFacturacion(String value) {
        this.numRegistroAcuerdoFacturacion = value;
    }

    /**
     * Gets the value of the importeTotal property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getImporteTotal() {
        return importeTotal;
    }

    /**
     * Sets the value of the importeTotal property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setImporteTotal(String value) {
        this.importeTotal = value;
    }

    /**
     * Gets the value of the baseImponibleACoste property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBaseImponibleACoste() {
        return baseImponibleACoste;
    }

    /**
     * Sets the value of the baseImponibleACoste property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBaseImponibleACoste(String value) {
        this.baseImponibleACoste = value;
    }

    /**
     * Gets the value of the descripcionOperacion property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDescripcionOperacion() {
        return descripcionOperacion;
    }

    /**
     * Sets the value of the descripcionOperacion property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDescripcionOperacion(String value) {
        this.descripcionOperacion = value;
    }

    /**
     * Gets the value of the refExterna property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRefExterna() {
        return refExterna;
    }

    /**
     * Sets the value of the refExterna property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRefExterna(String value) {
        this.refExterna = value;
    }

    /**
     * Gets the value of the facturaSimplificadaArticulos7273 property.
     * 
     * @return
     *     possible object is
     *     {@link SimplificadaCualificadaType }
     *     
     */
    public SimplificadaCualificadaType getFacturaSimplificadaArticulos7273() {
        return facturaSimplificadaArticulos7273;
    }

    /**
     * Sets the value of the facturaSimplificadaArticulos7273 property.
     * 
     * @param value
     *     allowed object is
     *     {@link SimplificadaCualificadaType }
     *     
     */
    public void setFacturaSimplificadaArticulos7273(SimplificadaCualificadaType value) {
        this.facturaSimplificadaArticulos7273 = value;
    }

    /**
     * Gets the value of the entidadSucedida property.
     * 
     * @return
     *     possible object is
     *     {@link PersonaFisicaJuridicaUnicaESType }
     *     
     */
    public PersonaFisicaJuridicaUnicaESType getEntidadSucedida() {
        return entidadSucedida;
    }

    /**
     * Sets the value of the entidadSucedida property.
     * 
     * @param value
     *     allowed object is
     *     {@link PersonaFisicaJuridicaUnicaESType }
     *     
     */
    public void setEntidadSucedida(PersonaFisicaJuridicaUnicaESType value) {
        this.entidadSucedida = value;
    }

    /**
     * Gets the value of the regPrevioGGEEoREDEMEoCompetencia property.
     * 
     * @return
     *     possible object is
     *     {@link RegPrevioGGEEoREDEMEoCompetenciaType }
     *     
     */
    public RegPrevioGGEEoREDEMEoCompetenciaType getRegPrevioGGEEoREDEMEoCompetencia() {
        return regPrevioGGEEoREDEMEoCompetencia;
    }

    /**
     * Sets the value of the regPrevioGGEEoREDEMEoCompetencia property.
     * 
     * @param value
     *     allowed object is
     *     {@link RegPrevioGGEEoREDEMEoCompetenciaType }
     *     
     */
    public void setRegPrevioGGEEoREDEMEoCompetencia(RegPrevioGGEEoREDEMEoCompetenciaType value) {
        this.regPrevioGGEEoREDEMEoCompetencia = value;
    }

    /**
     * Gets the value of the macrodato property.
     * 
     * @return
     *     possible object is
     *     {@link MacrodatoType }
     *     
     */
    public MacrodatoType getMacrodato() {
        return macrodato;
    }

    /**
     * Sets the value of the macrodato property.
     * 
     * @param value
     *     allowed object is
     *     {@link MacrodatoType }
     *     
     */
    public void setMacrodato(MacrodatoType value) {
        this.macrodato = value;
    }


    /**
     * El ID de los tickets agrupados, �nicamente se rellena en el caso de agrupaci�n de tickets en factura
     * 
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="IDFacturaAgrupada" type="{https://www2.agenciatributaria.gob.es/static_files/common/internet/dep/aplicaciones/es/aeat/ssii/fact/ws/SuministroInformacion.xsd}IDFacturaARType" maxOccurs="unbounded"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "idFacturaAgrupada"
    })
    public static class FacturasAgrupadas {

        @XmlElement(name = "IDFacturaAgrupada", required = true)
        protected List<IDFacturaARType> idFacturaAgrupada;

        /**
         * Gets the value of the idFacturaAgrupada property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the idFacturaAgrupada property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getIDFacturaAgrupada().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link IDFacturaARType }
         * 
         * 
         */
        public List<IDFacturaARType> getIDFacturaAgrupada() {
            if (idFacturaAgrupada == null) {
                idFacturaAgrupada = new ArrayList<IDFacturaARType>();
            }
            return this.idFacturaAgrupada;
        }

    }


    /**
     * El ID de las facturas rectificadas, �nicamente se rellena en el caso de rectificaci�n de facturas
     * 
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="IDFacturaRectificada" type="{https://www2.agenciatributaria.gob.es/static_files/common/internet/dep/aplicaciones/es/aeat/ssii/fact/ws/SuministroInformacion.xsd}IDFacturaARType" maxOccurs="unbounded"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "idFacturaRectificada"
    })
    public static class FacturasRectificadas {

        @XmlElement(name = "IDFacturaRectificada", required = true)
        protected List<IDFacturaARType> idFacturaRectificada;

        /**
         * Gets the value of the idFacturaRectificada property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the idFacturaRectificada property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getIDFacturaRectificada().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link IDFacturaARType }
         * 
         * 
         */
        public List<IDFacturaARType> getIDFacturaRectificada() {
            if (idFacturaRectificada == null) {
                idFacturaRectificada = new ArrayList<IDFacturaARType>();
            }
            return this.idFacturaRectificada;
        }

    }

}
