//
// Este archivo ha sido generado por la arquitectura JavaTM para la implantaci�n de la referencia de enlace (JAXB) XML v2.2.11 
// Visite <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Todas las modificaciones realizadas en este archivo se perder�n si se vuelve a compilar el esquema de origen. 
// Generado el: 2017.05.30 a las 03:33:12 PM CEST 
//


package net.aonsolutions.aon.sii;

public enum ClaveRegimenEspecialOTrascendenciaRecibidasType {


    /**
     *	Operaci�n de r�gimen general.
     */
    _01,

    /**
     *	Operaciones por las que los empresarios satisfacen compensaciones en las adquisiciones a personas acogidas al R�gimen especial de la agricultura, ganaderia y pesca.
     */
    _02,
    
    /**
     *	Operaciones a las que se aplique el r�gimen especial de bienes usados, objetos de
	 * 	arte, antig�edades y objetos de colecci�n.
     */
    _03,

    /**
     *	R�gimen especial del oro de inversi�n.
     */
    _04,

    /**
     *	R�gimen especial de las agencias de viajes. 
     */
    _05,

    /**
     *	R�gimen especial grupo de entidades en IVA (Nivel Avanzado).
     */
    _06,
    
    /**
     *	R�gimen especial del criterio de caja
     */
    _07,

    /**
     *	Operaciones sujetas al IPSI / IGIC (Impuesto sobre la Producci�n, los Servicios y la
	 *	Importaci�n / Impuesto General Indirecto Canario).
     */
    _08,

    /**
     *	Adquisiciones Intracomunitarias de bienes y prestaciones de servicios
     */
    _09,


    /**
     *	Operaciones de arrendamiento de local de negocio.
     */
    _12,

    /**
     *	Factura correspondiente a una importacion (informada sin asociar a un DUA)
     */
    _13,

    /**
     *	Primer sementre 2017 y otras facturas anteriores a la inclusi�n en el SII.
     */
    _14,
    ;

	public String getName(){
		return this.toString().substring(1);
	}
    
	public byte value() {
        return (byte) this.ordinal();
    }

}
