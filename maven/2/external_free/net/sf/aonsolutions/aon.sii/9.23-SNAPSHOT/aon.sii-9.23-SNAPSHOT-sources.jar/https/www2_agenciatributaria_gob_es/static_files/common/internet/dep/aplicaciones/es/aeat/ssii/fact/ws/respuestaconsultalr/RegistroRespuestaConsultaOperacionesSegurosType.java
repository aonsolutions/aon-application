
package https.www2_agenciatributaria_gob_es.static_files.common.internet.dep.aplicaciones.es.aeat.ssii.fact.ws.respuestaconsultalr;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import https.www2_agenciatributaria_gob_es.static_files.common.internet.dep.aplicaciones.es.aeat.ssii.fact.ws.suministroinformacion.DatosPresentacion2Type;


/**
 * <p>Java class for RegistroRespuestaConsultaOperacionesSegurosType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="RegistroRespuestaConsultaOperacionesSegurosType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="DatosOperacionesSeguros" type="{https://www2.agenciatributaria.gob.es/static_files/common/internet/dep/aplicaciones/es/aeat/ssii/fact/ws/RespuestaConsultaLR.xsd}RespuestaOperacionesSegurosType"/&gt;
 *         &lt;element name="DatosPresentacion" type="{https://www2.agenciatributaria.gob.es/static_files/common/internet/dep/aplicaciones/es/aeat/ssii/fact/ws/SuministroInformacion.xsd}DatosPresentacion2Type"/&gt;
 *         &lt;element name="EstadoOperacionesSeguros" type="{https://www2.agenciatributaria.gob.es/static_files/common/internet/dep/aplicaciones/es/aeat/ssii/fact/ws/RespuestaConsultaLR.xsd}EstadoFactura2Type"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "RegistroRespuestaConsultaOperacionesSegurosType", propOrder = {
    "datosOperacionesSeguros",
    "datosPresentacion",
    "estadoOperacionesSeguros"
})
public class RegistroRespuestaConsultaOperacionesSegurosType {

    @XmlElement(name = "DatosOperacionesSeguros", required = true)
    protected RespuestaOperacionesSegurosType datosOperacionesSeguros;
    @XmlElement(name = "DatosPresentacion", required = true)
    protected DatosPresentacion2Type datosPresentacion;
    @XmlElement(name = "EstadoOperacionesSeguros", required = true)
    protected EstadoFactura2Type estadoOperacionesSeguros;

    /**
     * Gets the value of the datosOperacionesSeguros property.
     * 
     * @return
     *     possible object is
     *     {@link RespuestaOperacionesSegurosType }
     *     
     */
    public RespuestaOperacionesSegurosType getDatosOperacionesSeguros() {
        return datosOperacionesSeguros;
    }

    /**
     * Sets the value of the datosOperacionesSeguros property.
     * 
     * @param value
     *     allowed object is
     *     {@link RespuestaOperacionesSegurosType }
     *     
     */
    public void setDatosOperacionesSeguros(RespuestaOperacionesSegurosType value) {
        this.datosOperacionesSeguros = value;
    }

    /**
     * Gets the value of the datosPresentacion property.
     * 
     * @return
     *     possible object is
     *     {@link DatosPresentacion2Type }
     *     
     */
    public DatosPresentacion2Type getDatosPresentacion() {
        return datosPresentacion;
    }

    /**
     * Sets the value of the datosPresentacion property.
     * 
     * @param value
     *     allowed object is
     *     {@link DatosPresentacion2Type }
     *     
     */
    public void setDatosPresentacion(DatosPresentacion2Type value) {
        this.datosPresentacion = value;
    }

    /**
     * Gets the value of the estadoOperacionesSeguros property.
     * 
     * @return
     *     possible object is
     *     {@link EstadoFactura2Type }
     *     
     */
    public EstadoFactura2Type getEstadoOperacionesSeguros() {
        return estadoOperacionesSeguros;
    }

    /**
     * Sets the value of the estadoOperacionesSeguros property.
     * 
     * @param value
     *     allowed object is
     *     {@link EstadoFactura2Type }
     *     
     */
    public void setEstadoOperacionesSeguros(EstadoFactura2Type value) {
        this.estadoOperacionesSeguros = value;
    }

}
