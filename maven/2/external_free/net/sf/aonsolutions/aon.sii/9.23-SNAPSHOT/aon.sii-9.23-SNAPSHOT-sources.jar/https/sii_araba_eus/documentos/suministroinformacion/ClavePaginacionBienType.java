
package https.sii_araba_eus.documentos.suministroinformacion;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 *  Datos de identificaci�n de factura 
 * 
 * <p>Java class for ClavePaginacionBienType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ClavePaginacionBienType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="IDEmisorFactura"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="NombreRazon" type="{https://sii.araba.eus/documentos/SuministroInformacion.xsd}TextMax120Type"/&gt;
 *                   &lt;choice&gt;
 *                     &lt;element name="NIF" type="{https://sii.araba.eus/documentos/SuministroInformacion.xsd}NIFType"/&gt;
 *                     &lt;element name="IDOtro" type="{https://sii.araba.eus/documentos/SuministroInformacion.xsd}IDOtroType"/&gt;
 *                   &lt;/choice&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="NumSerieFacturaEmisor" type="{https://sii.araba.eus/documentos/SuministroInformacion.xsd}TextoIDFacturaType"/&gt;
 *         &lt;element name="FechaExpedicionFacturaEmisor" type="{https://sii.araba.eus/documentos/SuministroInformacion.xsd}fecha"/&gt;
 *         &lt;element name="IdentificacionBien" type="{https://sii.araba.eus/documentos/SuministroInformacion.xsd}TextMax40Type"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ClavePaginacionBienType", propOrder = {
    "idEmisorFactura",
    "numSerieFacturaEmisor",
    "fechaExpedicionFacturaEmisor",
    "identificacionBien"
})
public class ClavePaginacionBienType {

    @XmlElement(name = "IDEmisorFactura", required = true)
    protected ClavePaginacionBienType.IDEmisorFactura idEmisorFactura;
    @XmlElement(name = "NumSerieFacturaEmisor", required = true)
    protected String numSerieFacturaEmisor;
    @XmlElement(name = "FechaExpedicionFacturaEmisor", required = true)
    protected String fechaExpedicionFacturaEmisor;
    @XmlElement(name = "IdentificacionBien", required = true)
    protected String identificacionBien;

    /**
     * Gets the value of the idEmisorFactura property.
     * 
     * @return
     *     possible object is
     *     {@link ClavePaginacionBienType.IDEmisorFactura }
     *     
     */
    public ClavePaginacionBienType.IDEmisorFactura getIDEmisorFactura() {
        return idEmisorFactura;
    }

    /**
     * Sets the value of the idEmisorFactura property.
     * 
     * @param value
     *     allowed object is
     *     {@link ClavePaginacionBienType.IDEmisorFactura }
     *     
     */
    public void setIDEmisorFactura(ClavePaginacionBienType.IDEmisorFactura value) {
        this.idEmisorFactura = value;
    }

    /**
     * Gets the value of the numSerieFacturaEmisor property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNumSerieFacturaEmisor() {
        return numSerieFacturaEmisor;
    }

    /**
     * Sets the value of the numSerieFacturaEmisor property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNumSerieFacturaEmisor(String value) {
        this.numSerieFacturaEmisor = value;
    }

    /**
     * Gets the value of the fechaExpedicionFacturaEmisor property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFechaExpedicionFacturaEmisor() {
        return fechaExpedicionFacturaEmisor;
    }

    /**
     * Sets the value of the fechaExpedicionFacturaEmisor property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFechaExpedicionFacturaEmisor(String value) {
        this.fechaExpedicionFacturaEmisor = value;
    }

    /**
     * Gets the value of the identificacionBien property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdentificacionBien() {
        return identificacionBien;
    }

    /**
     * Sets the value of the identificacionBien property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdentificacionBien(String value) {
        this.identificacionBien = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="NombreRazon" type="{https://sii.araba.eus/documentos/SuministroInformacion.xsd}TextMax120Type"/&gt;
     *         &lt;choice&gt;
     *           &lt;element name="NIF" type="{https://sii.araba.eus/documentos/SuministroInformacion.xsd}NIFType"/&gt;
     *           &lt;element name="IDOtro" type="{https://sii.araba.eus/documentos/SuministroInformacion.xsd}IDOtroType"/&gt;
     *         &lt;/choice&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "nombreRazon",
        "nif",
        "idOtro"
    })
    public static class IDEmisorFactura {

        @XmlElement(name = "NombreRazon", required = true)
        protected String nombreRazon;
        @XmlElement(name = "NIF")
        protected String nif;
        @XmlElement(name = "IDOtro")
        protected IDOtroType idOtro;

        /**
         * Gets the value of the nombreRazon property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getNombreRazon() {
            return nombreRazon;
        }

        /**
         * Sets the value of the nombreRazon property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setNombreRazon(String value) {
            this.nombreRazon = value;
        }

        /**
         * Gets the value of the nif property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getNIF() {
            return nif;
        }

        /**
         * Sets the value of the nif property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setNIF(String value) {
            this.nif = value;
        }

        /**
         * Gets the value of the idOtro property.
         * 
         * @return
         *     possible object is
         *     {@link IDOtroType }
         *     
         */
        public IDOtroType getIDOtro() {
            return idOtro;
        }

        /**
         * Sets the value of the idOtro property.
         * 
         * @param value
         *     allowed object is
         *     {@link IDOtroType }
         *     
         */
        public void setIDOtro(IDOtroType value) {
            this.idOtro = value;
        }

    }

}
