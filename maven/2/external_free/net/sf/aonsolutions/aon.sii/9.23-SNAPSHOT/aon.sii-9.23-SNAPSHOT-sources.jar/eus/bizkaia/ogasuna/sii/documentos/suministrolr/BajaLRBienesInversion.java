
package eus.bizkaia.ogasuna.sii.documentos.suministrolr;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import eus.bizkaia.ogasuna.sii.documentos.suministroinformacion.SuministroInformacionBaja;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://www.bizkaia.eus/ogasuna/sii/documentos/SuministroInformacion.xsd}SuministroInformacionBaja"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="RegistroLRBajaBienesInversion" type="{http://www.bizkaia.eus/ogasuna/sii/documentos/SuministroLR.xsd}LRBajaBienesInversionType" maxOccurs="10000"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "registroLRBajaBienesInversion"
})
@XmlRootElement(name = "BajaLRBienesInversion")
public class BajaLRBienesInversion
    extends SuministroInformacionBaja
{

    @XmlElement(name = "RegistroLRBajaBienesInversion", required = true)
    protected List<LRBajaBienesInversionType> registroLRBajaBienesInversion;

    /**
     * Gets the value of the registroLRBajaBienesInversion property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the registroLRBajaBienesInversion property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRegistroLRBajaBienesInversion().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link LRBajaBienesInversionType }
     * 
     * 
     */
    public List<LRBajaBienesInversionType> getRegistroLRBajaBienesInversion() {
        if (registroLRBajaBienesInversion == null) {
            registroLRBajaBienesInversion = new ArrayList<LRBajaBienesInversionType>();
        }
        return this.registroLRBajaBienesInversion;
    }

}
