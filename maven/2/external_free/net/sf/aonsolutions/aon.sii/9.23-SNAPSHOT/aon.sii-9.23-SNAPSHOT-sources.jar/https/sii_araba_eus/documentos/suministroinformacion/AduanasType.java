
package https.sii_araba_eus.documentos.suministroinformacion;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * Desglose cuando corresponda de la informaci�n asociada a los documentos de aduanas
 * 
 * <p>Java class for AduanasType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AduanasType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="NumeroDUA" type="{https://sii.araba.eus/documentos/SuministroInformacion.xsd}TextMax40Type" minOccurs="0"/&gt;
 *         &lt;element name="FechaRegContableDUA" type="{https://sii.araba.eus/documentos/SuministroInformacion.xsd}fecha" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AduanasType", propOrder = {
    "numeroDUA",
    "fechaRegContableDUA"
})
public class AduanasType {

    @XmlElement(name = "NumeroDUA")
    protected String numeroDUA;
    @XmlElement(name = "FechaRegContableDUA")
    protected String fechaRegContableDUA;

    /**
     * Gets the value of the numeroDUA property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNumeroDUA() {
        return numeroDUA;
    }

    /**
     * Sets the value of the numeroDUA property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNumeroDUA(String value) {
        this.numeroDUA = value;
    }

    /**
     * Gets the value of the fechaRegContableDUA property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFechaRegContableDUA() {
        return fechaRegContableDUA;
    }

    /**
     * Sets the value of the fechaRegContableDUA property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFechaRegContableDUA(String value) {
        this.fechaRegContableDUA = value;
    }

}
