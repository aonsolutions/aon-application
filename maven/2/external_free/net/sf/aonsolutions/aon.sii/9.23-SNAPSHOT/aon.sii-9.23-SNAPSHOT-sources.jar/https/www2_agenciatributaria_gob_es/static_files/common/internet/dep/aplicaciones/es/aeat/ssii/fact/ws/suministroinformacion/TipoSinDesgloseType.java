
package https.www2_agenciatributaria_gob_es.static_files.common.internet.dep.aplicaciones.es.aeat.ssii.fact.ws.suministroinformacion;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * Tipo de Operacion sin calificar si se trata de una Prestacin de Servicios o una Entrega de Bienes
 * 
 * <p>Java class for TipoSinDesgloseType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="TipoSinDesgloseType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Sujeta" type="{https://www2.agenciatributaria.gob.es/static_files/common/internet/dep/aplicaciones/es/aeat/ssii/fact/ws/SuministroInformacion.xsd}SujetaType" minOccurs="0"/&gt;
 *         &lt;element name="NoSujeta" type="{https://www2.agenciatributaria.gob.es/static_files/common/internet/dep/aplicaciones/es/aeat/ssii/fact/ws/SuministroInformacion.xsd}NoSujetaType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TipoSinDesgloseType", propOrder = {
    "sujeta",
    "noSujeta"
})
public class TipoSinDesgloseType {

    @XmlElement(name = "Sujeta")
    protected SujetaType sujeta;
    @XmlElement(name = "NoSujeta")
    protected NoSujetaType noSujeta;

    /**
     * Gets the value of the sujeta property.
     * 
     * @return
     *     possible object is
     *     {@link SujetaType }
     *     
     */
    public SujetaType getSujeta() {
        return sujeta;
    }

    /**
     * Sets the value of the sujeta property.
     * 
     * @param value
     *     allowed object is
     *     {@link SujetaType }
     *     
     */
    public void setSujeta(SujetaType value) {
        this.sujeta = value;
    }

    /**
     * Gets the value of the noSujeta property.
     * 
     * @return
     *     possible object is
     *     {@link NoSujetaType }
     *     
     */
    public NoSujetaType getNoSujeta() {
        return noSujeta;
    }

    /**
     * Sets the value of the noSujeta property.
     * 
     * @param value
     *     allowed object is
     *     {@link NoSujetaType }
     *     
     */
    public void setNoSujeta(NoSujetaType value) {
        this.noSujeta = value;
    }

}
