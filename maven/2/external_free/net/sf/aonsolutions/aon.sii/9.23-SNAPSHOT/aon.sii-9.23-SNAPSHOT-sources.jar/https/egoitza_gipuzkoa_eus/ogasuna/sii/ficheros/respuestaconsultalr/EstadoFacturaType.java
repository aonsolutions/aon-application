
package https.egoitza_gipuzkoa_eus.ogasuna.sii.ficheros.respuestaconsultalr;

import java.math.BigInteger;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for EstadoFacturaType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="EstadoFacturaType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="EstadoCuadre" type="{https://egoitza.gipuzkoa.eus/ogasuna/sii/ficheros/SuministroInformacion.xsd}EstadoCuadreType" minOccurs="0"/&gt;
 *         &lt;element name="TimestampEstadoCuadre" type="{https://egoitza.gipuzkoa.eus/ogasuna/sii/ficheros/SuministroInformacion.xsd}Timestamp" minOccurs="0"/&gt;
 *         &lt;element name="TimestampUltimaModificacion" type="{https://egoitza.gipuzkoa.eus/ogasuna/sii/ficheros/SuministroInformacion.xsd}Timestamp"/&gt;
 *         &lt;element name="EstadoRegistro" type="{https://egoitza.gipuzkoa.eus/ogasuna/sii/ficheros/RespuestaConsultaLR.xsd}EstadoRegistroSIIType"/&gt;
 *         &lt;element name="CodigoErrorRegistro" type="{https://egoitza.gipuzkoa.eus/ogasuna/sii/ficheros/RespuestaConsultaLR.xsd}ErrorDetalleType" minOccurs="0"/&gt;
 *         &lt;element name="DescripcionErrorRegistro" type="{https://egoitza.gipuzkoa.eus/ogasuna/sii/ficheros/SuministroInformacion.xsd}TextMax500Type" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "EstadoFacturaType", propOrder = {
    "estadoCuadre",
    "timestampEstadoCuadre",
    "timestampUltimaModificacion",
    "estadoRegistro",
    "codigoErrorRegistro",
    "descripcionErrorRegistro"
})
public class EstadoFacturaType {

    @XmlElement(name = "EstadoCuadre")
    protected String estadoCuadre;
    @XmlElement(name = "TimestampEstadoCuadre")
    protected String timestampEstadoCuadre;
    @XmlElement(name = "TimestampUltimaModificacion", required = true)
    protected String timestampUltimaModificacion;
    @XmlElement(name = "EstadoRegistro", required = true)
    @XmlSchemaType(name = "string")
    protected EstadoRegistroSIIType estadoRegistro;
    @XmlElement(name = "CodigoErrorRegistro")
    protected BigInteger codigoErrorRegistro;
    @XmlElement(name = "DescripcionErrorRegistro")
    protected String descripcionErrorRegistro;

    /**
     * Gets the value of the estadoCuadre property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEstadoCuadre() {
        return estadoCuadre;
    }

    /**
     * Sets the value of the estadoCuadre property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEstadoCuadre(String value) {
        this.estadoCuadre = value;
    }

    /**
     * Gets the value of the timestampEstadoCuadre property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTimestampEstadoCuadre() {
        return timestampEstadoCuadre;
    }

    /**
     * Sets the value of the timestampEstadoCuadre property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTimestampEstadoCuadre(String value) {
        this.timestampEstadoCuadre = value;
    }

    /**
     * Gets the value of the timestampUltimaModificacion property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTimestampUltimaModificacion() {
        return timestampUltimaModificacion;
    }

    /**
     * Sets the value of the timestampUltimaModificacion property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTimestampUltimaModificacion(String value) {
        this.timestampUltimaModificacion = value;
    }

    /**
     * Gets the value of the estadoRegistro property.
     * 
     * @return
     *     possible object is
     *     {@link EstadoRegistroSIIType }
     *     
     */
    public EstadoRegistroSIIType getEstadoRegistro() {
        return estadoRegistro;
    }

    /**
     * Sets the value of the estadoRegistro property.
     * 
     * @param value
     *     allowed object is
     *     {@link EstadoRegistroSIIType }
     *     
     */
    public void setEstadoRegistro(EstadoRegistroSIIType value) {
        this.estadoRegistro = value;
    }

    /**
     * Gets the value of the codigoErrorRegistro property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getCodigoErrorRegistro() {
        return codigoErrorRegistro;
    }

    /**
     * Sets the value of the codigoErrorRegistro property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setCodigoErrorRegistro(BigInteger value) {
        this.codigoErrorRegistro = value;
    }

    /**
     * Gets the value of the descripcionErrorRegistro property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDescripcionErrorRegistro() {
        return descripcionErrorRegistro;
    }

    /**
     * Sets the value of the descripcionErrorRegistro property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDescripcionErrorRegistro(String value) {
        this.descripcionErrorRegistro = value;
    }

}
