
package eus.bizkaia.ogasuna.sii.documentos.respuestaconsultalr;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for RespuestaConsultaLRFacturasEmitidasType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="RespuestaConsultaLRFacturasEmitidasType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://www.bizkaia.eus/ogasuna/sii/documentos/RespuestaConsultaLR.xsd}RespuestaConsultaLRFacturasType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="RegistroRespuestaConsultaLRFacturasEmitidas" type="{http://www.bizkaia.eus/ogasuna/sii/documentos/RespuestaConsultaLR.xsd}RegistroRespuestaConsultaEmitidasType" maxOccurs="10000" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "RespuestaConsultaLRFacturasEmitidasType", propOrder = {
    "registroRespuestaConsultaLRFacturasEmitidas"
})
public class RespuestaConsultaLRFacturasEmitidasType
    extends RespuestaConsultaLRFacturasType
{

    @XmlElement(name = "RegistroRespuestaConsultaLRFacturasEmitidas")
    protected List<RegistroRespuestaConsultaEmitidasType> registroRespuestaConsultaLRFacturasEmitidas;

    /**
     * Gets the value of the registroRespuestaConsultaLRFacturasEmitidas property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the registroRespuestaConsultaLRFacturasEmitidas property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRegistroRespuestaConsultaLRFacturasEmitidas().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link RegistroRespuestaConsultaEmitidasType }
     * 
     * 
     */
    public List<RegistroRespuestaConsultaEmitidasType> getRegistroRespuestaConsultaLRFacturasEmitidas() {
        if (registroRespuestaConsultaLRFacturasEmitidas == null) {
            registroRespuestaConsultaLRFacturasEmitidas = new ArrayList<RegistroRespuestaConsultaEmitidasType>();
        }
        return this.registroRespuestaConsultaLRFacturasEmitidas;
    }

}
