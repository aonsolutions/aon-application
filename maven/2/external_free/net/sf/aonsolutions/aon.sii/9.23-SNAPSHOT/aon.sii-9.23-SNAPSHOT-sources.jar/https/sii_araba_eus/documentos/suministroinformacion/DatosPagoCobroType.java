
package https.sii_araba_eus.documentos.suministroinformacion;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for DatosPagoCobroType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DatosPagoCobroType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Fecha" type="{https://sii.araba.eus/documentos/SuministroInformacion.xsd}fecha"/&gt;
 *         &lt;element name="Importe" type="{https://sii.araba.eus/documentos/SuministroInformacion.xsd}ImporteSgn12.2Type"/&gt;
 *         &lt;element name="Medio" type="{https://sii.araba.eus/documentos/SuministroInformacion.xsd}MedioPagoType"/&gt;
 *         &lt;element name="Cuenta_O_Medio" type="{https://sii.araba.eus/documentos/SuministroInformacion.xsd}TextMax34Type" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DatosPagoCobroType", propOrder = {
    "fecha",
    "importe",
    "medio",
    "cuentaOMedio"
})
public class DatosPagoCobroType {

    @XmlElement(name = "Fecha", required = true)
    protected String fecha;
    @XmlElement(name = "Importe", required = true)
    protected String importe;
    @XmlElement(name = "Medio", required = true)
    protected String medio;
    @XmlElement(name = "Cuenta_O_Medio")
    protected String cuentaOMedio;

    /**
     * Gets the value of the fecha property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFecha() {
        return fecha;
    }

    /**
     * Sets the value of the fecha property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFecha(String value) {
        this.fecha = value;
    }

    /**
     * Gets the value of the importe property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getImporte() {
        return importe;
    }

    /**
     * Sets the value of the importe property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setImporte(String value) {
        this.importe = value;
    }

    /**
     * Gets the value of the medio property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMedio() {
        return medio;
    }

    /**
     * Sets the value of the medio property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMedio(String value) {
        this.medio = value;
    }

    /**
     * Gets the value of the cuentaOMedio property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCuentaOMedio() {
        return cuentaOMedio;
    }

    /**
     * Sets the value of the cuentaOMedio property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCuentaOMedio(String value) {
        this.cuentaOMedio = value;
    }

}
