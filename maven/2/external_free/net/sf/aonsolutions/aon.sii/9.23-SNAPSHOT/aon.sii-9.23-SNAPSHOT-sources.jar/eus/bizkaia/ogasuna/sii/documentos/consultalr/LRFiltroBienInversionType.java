
package eus.bizkaia.ogasuna.sii.documentos.consultalr;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import eus.bizkaia.ogasuna.sii.documentos.suministroinformacion.ClavePaginacionBienType;
import eus.bizkaia.ogasuna.sii.documentos.suministroinformacion.FacturaModificadaType;
import eus.bizkaia.ogasuna.sii.documentos.suministroinformacion.IDFacturaConsulta1Type;
import eus.bizkaia.ogasuna.sii.documentos.suministroinformacion.RangoFechaPresentacionType;
import eus.bizkaia.ogasuna.sii.documentos.suministroinformacion.RegistroSii;


/**
 * <p>Java class for LRFiltroBienInversionType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="LRFiltroBienInversionType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://www.bizkaia.eus/ogasuna/sii/documentos/SuministroInformacion.xsd}RegistroSii"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="IDFactura" type="{http://www.bizkaia.eus/ogasuna/sii/documentos/SuministroInformacion.xsd}IDFacturaConsulta1Type" minOccurs="0"/&gt;
 *         &lt;element name="FechaPresentacion" type="{http://www.bizkaia.eus/ogasuna/sii/documentos/SuministroInformacion.xsd}RangoFechaPresentacionType" minOccurs="0"/&gt;
 *         &lt;element name="FacturaModificada" type="{http://www.bizkaia.eus/ogasuna/sii/documentos/SuministroInformacion.xsd}FacturaModificadaType" minOccurs="0"/&gt;
 *         &lt;element name="IdentificacionBien" type="{http://www.bizkaia.eus/ogasuna/sii/documentos/SuministroInformacion.xsd}TextMax40Type" minOccurs="0"/&gt;
 *         &lt;element name="ClavePaginacion" type="{http://www.bizkaia.eus/ogasuna/sii/documentos/SuministroInformacion.xsd}ClavePaginacionBienType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "LRFiltroBienInversionType", propOrder = {
    "idFactura",
    "fechaPresentacion",
    "facturaModificada",
    "identificacionBien",
    "clavePaginacion"
})
public class LRFiltroBienInversionType
    extends RegistroSii
{

    @XmlElement(name = "IDFactura")
    protected IDFacturaConsulta1Type idFactura;
    @XmlElement(name = "FechaPresentacion")
    protected RangoFechaPresentacionType fechaPresentacion;
    @XmlElement(name = "FacturaModificada")
    @XmlSchemaType(name = "string")
    protected FacturaModificadaType facturaModificada;
    @XmlElement(name = "IdentificacionBien")
    protected String identificacionBien;
    @XmlElement(name = "ClavePaginacion")
    protected ClavePaginacionBienType clavePaginacion;

    /**
     * Gets the value of the idFactura property.
     * 
     * @return
     *     possible object is
     *     {@link IDFacturaConsulta1Type }
     *     
     */
    public IDFacturaConsulta1Type getIDFactura() {
        return idFactura;
    }

    /**
     * Sets the value of the idFactura property.
     * 
     * @param value
     *     allowed object is
     *     {@link IDFacturaConsulta1Type }
     *     
     */
    public void setIDFactura(IDFacturaConsulta1Type value) {
        this.idFactura = value;
    }

    /**
     * Gets the value of the fechaPresentacion property.
     * 
     * @return
     *     possible object is
     *     {@link RangoFechaPresentacionType }
     *     
     */
    public RangoFechaPresentacionType getFechaPresentacion() {
        return fechaPresentacion;
    }

    /**
     * Sets the value of the fechaPresentacion property.
     * 
     * @param value
     *     allowed object is
     *     {@link RangoFechaPresentacionType }
     *     
     */
    public void setFechaPresentacion(RangoFechaPresentacionType value) {
        this.fechaPresentacion = value;
    }

    /**
     * Gets the value of the facturaModificada property.
     * 
     * @return
     *     possible object is
     *     {@link FacturaModificadaType }
     *     
     */
    public FacturaModificadaType getFacturaModificada() {
        return facturaModificada;
    }

    /**
     * Sets the value of the facturaModificada property.
     * 
     * @param value
     *     allowed object is
     *     {@link FacturaModificadaType }
     *     
     */
    public void setFacturaModificada(FacturaModificadaType value) {
        this.facturaModificada = value;
    }

    /**
     * Gets the value of the identificacionBien property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdentificacionBien() {
        return identificacionBien;
    }

    /**
     * Sets the value of the identificacionBien property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdentificacionBien(String value) {
        this.identificacionBien = value;
    }

    /**
     * Gets the value of the clavePaginacion property.
     * 
     * @return
     *     possible object is
     *     {@link ClavePaginacionBienType }
     *     
     */
    public ClavePaginacionBienType getClavePaginacion() {
        return clavePaginacion;
    }

    /**
     * Sets the value of the clavePaginacion property.
     * 
     * @param value
     *     allowed object is
     *     {@link ClavePaginacionBienType }
     *     
     */
    public void setClavePaginacion(ClavePaginacionBienType value) {
        this.clavePaginacion = value;
    }

}
