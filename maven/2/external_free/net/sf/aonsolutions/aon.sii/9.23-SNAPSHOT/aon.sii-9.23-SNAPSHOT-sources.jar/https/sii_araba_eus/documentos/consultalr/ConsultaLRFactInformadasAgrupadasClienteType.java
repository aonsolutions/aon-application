
package https.sii_araba_eus.documentos.consultalr;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import https.sii_araba_eus.documentos.suministroinformacion.ConsultaInformacionCliente;


/**
 * <p>Java class for ConsultaLRFactInformadasAgrupadasClienteType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ConsultaLRFactInformadasAgrupadasClienteType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{https://sii.araba.eus/documentos/SuministroInformacion.xsd}ConsultaInformacionCliente"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="FiltroConsulta" type="{https://sii.araba.eus/documentos/ConsultaLR.xsd}LRFiltroFactInformadasAgrupadasClienteType"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ConsultaLRFactInformadasAgrupadasClienteType", propOrder = {
    "filtroConsulta"
})
public class ConsultaLRFactInformadasAgrupadasClienteType
    extends ConsultaInformacionCliente
{

    @XmlElement(name = "FiltroConsulta", required = true)
    protected LRFiltroFactInformadasAgrupadasClienteType filtroConsulta;

    /**
     * Gets the value of the filtroConsulta property.
     * 
     * @return
     *     possible object is
     *     {@link LRFiltroFactInformadasAgrupadasClienteType }
     *     
     */
    public LRFiltroFactInformadasAgrupadasClienteType getFiltroConsulta() {
        return filtroConsulta;
    }

    /**
     * Sets the value of the filtroConsulta property.
     * 
     * @param value
     *     allowed object is
     *     {@link LRFiltroFactInformadasAgrupadasClienteType }
     *     
     */
    public void setFiltroConsulta(LRFiltroFactInformadasAgrupadasClienteType value) {
        this.filtroConsulta = value;
    }

}
