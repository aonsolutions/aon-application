
package https.egoitza_gipuzkoa_eus.ogasuna.sii.ficheros.suministroinformacion;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * Tipo de Operacion Sujeta
 * 
 * <p>Java class for SujetaType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="SujetaType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Exenta" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="DetalleExenta" type="{https://egoitza.gipuzkoa.eus/ogasuna/sii/ficheros/SuministroInformacion.xsd}DetalleExentaType" maxOccurs="7"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="NoExenta" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="TipoNoExenta" type="{https://egoitza.gipuzkoa.eus/ogasuna/sii/ficheros/SuministroInformacion.xsd}TipoOperacionSujetaNoExentaType"/&gt;
 *                   &lt;element name="DesgloseIVA"&gt;
 *                     &lt;complexType&gt;
 *                       &lt;complexContent&gt;
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                           &lt;sequence&gt;
 *                             &lt;element name="DetalleIVA" type="{https://egoitza.gipuzkoa.eus/ogasuna/sii/ficheros/SuministroInformacion.xsd}DetalleIVAEmitidaType" maxOccurs="6"/&gt;
 *                           &lt;/sequence&gt;
 *                         &lt;/restriction&gt;
 *                       &lt;/complexContent&gt;
 *                     &lt;/complexType&gt;
 *                   &lt;/element&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SujetaType", propOrder = {
    "exenta",
    "noExenta"
})
public class SujetaType {

    @XmlElement(name = "Exenta")
    protected SujetaType.Exenta exenta;
    @XmlElement(name = "NoExenta")
    protected SujetaType.NoExenta noExenta;

    /**
     * Gets the value of the exenta property.
     * 
     * @return
     *     possible object is
     *     {@link SujetaType.Exenta }
     *     
     */
    public SujetaType.Exenta getExenta() {
        return exenta;
    }

    /**
     * Sets the value of the exenta property.
     * 
     * @param value
     *     allowed object is
     *     {@link SujetaType.Exenta }
     *     
     */
    public void setExenta(SujetaType.Exenta value) {
        this.exenta = value;
    }

    /**
     * Gets the value of the noExenta property.
     * 
     * @return
     *     possible object is
     *     {@link SujetaType.NoExenta }
     *     
     */
    public SujetaType.NoExenta getNoExenta() {
        return noExenta;
    }

    /**
     * Sets the value of the noExenta property.
     * 
     * @param value
     *     allowed object is
     *     {@link SujetaType.NoExenta }
     *     
     */
    public void setNoExenta(SujetaType.NoExenta value) {
        this.noExenta = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="DetalleExenta" type="{https://egoitza.gipuzkoa.eus/ogasuna/sii/ficheros/SuministroInformacion.xsd}DetalleExentaType" maxOccurs="7"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "detalleExenta"
    })
    public static class Exenta {

        @XmlElement(name = "DetalleExenta", required = true)
        protected List<DetalleExentaType> detalleExenta;

        /**
         * Gets the value of the detalleExenta property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the detalleExenta property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getDetalleExenta().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link DetalleExentaType }
         * 
         * 
         */
        public List<DetalleExentaType> getDetalleExenta() {
            if (detalleExenta == null) {
                detalleExenta = new ArrayList<DetalleExentaType>();
            }
            return this.detalleExenta;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="TipoNoExenta" type="{https://egoitza.gipuzkoa.eus/ogasuna/sii/ficheros/SuministroInformacion.xsd}TipoOperacionSujetaNoExentaType"/&gt;
     *         &lt;element name="DesgloseIVA"&gt;
     *           &lt;complexType&gt;
     *             &lt;complexContent&gt;
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                 &lt;sequence&gt;
     *                   &lt;element name="DetalleIVA" type="{https://egoitza.gipuzkoa.eus/ogasuna/sii/ficheros/SuministroInformacion.xsd}DetalleIVAEmitidaType" maxOccurs="6"/&gt;
     *                 &lt;/sequence&gt;
     *               &lt;/restriction&gt;
     *             &lt;/complexContent&gt;
     *           &lt;/complexType&gt;
     *         &lt;/element&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "tipoNoExenta",
        "desgloseIVA"
    })
    public static class NoExenta {

        @XmlElement(name = "TipoNoExenta", required = true)
        @XmlSchemaType(name = "string")
        protected TipoOperacionSujetaNoExentaType tipoNoExenta;
        @XmlElement(name = "DesgloseIVA", required = true)
        protected SujetaType.NoExenta.DesgloseIVA desgloseIVA;

        /**
         * Gets the value of the tipoNoExenta property.
         * 
         * @return
         *     possible object is
         *     {@link TipoOperacionSujetaNoExentaType }
         *     
         */
        public TipoOperacionSujetaNoExentaType getTipoNoExenta() {
            return tipoNoExenta;
        }

        /**
         * Sets the value of the tipoNoExenta property.
         * 
         * @param value
         *     allowed object is
         *     {@link TipoOperacionSujetaNoExentaType }
         *     
         */
        public void setTipoNoExenta(TipoOperacionSujetaNoExentaType value) {
            this.tipoNoExenta = value;
        }

        /**
         * Gets the value of the desgloseIVA property.
         * 
         * @return
         *     possible object is
         *     {@link SujetaType.NoExenta.DesgloseIVA }
         *     
         */
        public SujetaType.NoExenta.DesgloseIVA getDesgloseIVA() {
            return desgloseIVA;
        }

        /**
         * Sets the value of the desgloseIVA property.
         * 
         * @param value
         *     allowed object is
         *     {@link SujetaType.NoExenta.DesgloseIVA }
         *     
         */
        public void setDesgloseIVA(SujetaType.NoExenta.DesgloseIVA value) {
            this.desgloseIVA = value;
        }


        /**
         * Desglose por tipos de iva
         * 
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType&gt;
         *   &lt;complexContent&gt;
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *       &lt;sequence&gt;
         *         &lt;element name="DetalleIVA" type="{https://egoitza.gipuzkoa.eus/ogasuna/sii/ficheros/SuministroInformacion.xsd}DetalleIVAEmitidaType" maxOccurs="6"/&gt;
         *       &lt;/sequence&gt;
         *     &lt;/restriction&gt;
         *   &lt;/complexContent&gt;
         * &lt;/complexType&gt;
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "detalleIVA"
        })
        public static class DesgloseIVA {

            @XmlElement(name = "DetalleIVA", required = true)
            protected List<DetalleIVAEmitidaType> detalleIVA;

            /**
             * Gets the value of the detalleIVA property.
             * 
             * <p>
             * This accessor method returns a reference to the live list,
             * not a snapshot. Therefore any modification you make to the
             * returned list will be present inside the JAXB object.
             * This is why there is not a <CODE>set</CODE> method for the detalleIVA property.
             * 
             * <p>
             * For example, to add a new item, do as follows:
             * <pre>
             *    getDetalleIVA().add(newItem);
             * </pre>
             * 
             * 
             * <p>
             * Objects of the following type(s) are allowed in the list
             * {@link DetalleIVAEmitidaType }
             * 
             * 
             */
            public List<DetalleIVAEmitidaType> getDetalleIVA() {
                if (detalleIVA == null) {
                    detalleIVA = new ArrayList<DetalleIVAEmitidaType>();
                }
                return this.detalleIVA;
            }

        }

    }

}
