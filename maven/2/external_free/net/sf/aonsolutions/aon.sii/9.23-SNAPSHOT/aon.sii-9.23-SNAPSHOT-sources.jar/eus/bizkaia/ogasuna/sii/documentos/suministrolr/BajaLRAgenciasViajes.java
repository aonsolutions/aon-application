
package eus.bizkaia.ogasuna.sii.documentos.suministrolr;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import eus.bizkaia.ogasuna.sii.documentos.suministroinformacion.SuministroInformacionBaja;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{http://www.bizkaia.eus/ogasuna/sii/documentos/SuministroInformacion.xsd}SuministroInformacionBaja"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="RegistroLRBajaAgenciasViajes" type="{http://www.bizkaia.eus/ogasuna/sii/documentos/SuministroLR.xsd}LRBajaAgenciasViajesType" maxOccurs="10000"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "registroLRBajaAgenciasViajes"
})
@XmlRootElement(name = "BajaLRAgenciasViajes")
public class BajaLRAgenciasViajes
    extends SuministroInformacionBaja
{

    @XmlElement(name = "RegistroLRBajaAgenciasViajes", required = true)
    protected List<LRBajaAgenciasViajesType> registroLRBajaAgenciasViajes;

    /**
     * Gets the value of the registroLRBajaAgenciasViajes property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the registroLRBajaAgenciasViajes property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRegistroLRBajaAgenciasViajes().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link LRBajaAgenciasViajesType }
     * 
     * 
     */
    public List<LRBajaAgenciasViajesType> getRegistroLRBajaAgenciasViajes() {
        if (registroLRBajaAgenciasViajes == null) {
            registroLRBajaAgenciasViajes = new ArrayList<LRBajaAgenciasViajesType>();
        }
        return this.registroLRBajaAgenciasViajes;
    }

}
