
package https.egoitza_gipuzkoa_eus.ogasuna.sii.ficheros.consultalr;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import https.egoitza_gipuzkoa_eus.ogasuna.sii.ficheros.suministroinformacion.ConsultaInformacion;


/**
 * <p>Java class for LRConsultaBienesInversionType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="LRConsultaBienesInversionType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{https://egoitza.gipuzkoa.eus/ogasuna/sii/ficheros/SuministroInformacion.xsd}ConsultaInformacion"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="FiltroConsulta" type="{https://egoitza.gipuzkoa.eus/ogasuna/sii/ficheros/ConsultaLR.xsd}LRFiltroBienInversionType"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "LRConsultaBienesInversionType", propOrder = {
    "filtroConsulta"
})
public class LRConsultaBienesInversionType
    extends ConsultaInformacion
{

    @XmlElement(name = "FiltroConsulta", required = true)
    protected LRFiltroBienInversionType filtroConsulta;

    /**
     * Gets the value of the filtroConsulta property.
     * 
     * @return
     *     possible object is
     *     {@link LRFiltroBienInversionType }
     *     
     */
    public LRFiltroBienInversionType getFiltroConsulta() {
        return filtroConsulta;
    }

    /**
     * Sets the value of the filtroConsulta property.
     * 
     * @param value
     *     allowed object is
     *     {@link LRFiltroBienInversionType }
     *     
     */
    public void setFiltroConsulta(LRFiltroBienInversionType value) {
        this.filtroConsulta = value;
    }

}
