
package https.sii_araba_eus.documentos.consultalr;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import https.sii_araba_eus.documentos.suministroinformacion.ContraparteConsultaType;
import https.sii_araba_eus.documentos.suministroinformacion.FacturaModificadaType;
import https.sii_araba_eus.documentos.suministroinformacion.IDFacturaConsulta2Type;
import https.sii_araba_eus.documentos.suministroinformacion.IDFacturaExpedidaBCType;
import https.sii_araba_eus.documentos.suministroinformacion.RangoFechaPresentacionType;
import https.sii_araba_eus.documentos.suministroinformacion.RegistroSii;


/**
 * <p>Java class for LRFiltroEmitidasType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="LRFiltroEmitidasType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{https://sii.araba.eus/documentos/SuministroInformacion.xsd}RegistroSii"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="IDFactura" type="{https://sii.araba.eus/documentos/SuministroInformacion.xsd}IDFacturaConsulta2Type" minOccurs="0"/&gt;
 *         &lt;element name="Contraparte" type="{https://sii.araba.eus/documentos/SuministroInformacion.xsd}ContraparteConsultaType" minOccurs="0"/&gt;
 *         &lt;element name="FechaPresentacion" type="{https://sii.araba.eus/documentos/SuministroInformacion.xsd}RangoFechaPresentacionType" minOccurs="0"/&gt;
 *         &lt;element name="FechaCuadre" type="{https://sii.araba.eus/documentos/SuministroInformacion.xsd}RangoFechaPresentacionType" minOccurs="0"/&gt;
 *         &lt;element name="FacturaModificada" type="{https://sii.araba.eus/documentos/SuministroInformacion.xsd}FacturaModificadaType" minOccurs="0"/&gt;
 *         &lt;element name="EstadoCuadre" type="{https://sii.araba.eus/documentos/SuministroInformacion.xsd}EstadoCuadreType" minOccurs="0"/&gt;
 *         &lt;element name="ClavePaginacion" type="{https://sii.araba.eus/documentos/SuministroInformacion.xsd}IDFacturaExpedidaBCType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "LRFiltroEmitidasType", propOrder = {
    "idFactura",
    "contraparte",
    "fechaPresentacion",
    "fechaCuadre",
    "facturaModificada",
    "estadoCuadre",
    "clavePaginacion"
})
public class LRFiltroEmitidasType
    extends RegistroSii
{

    @XmlElement(name = "IDFactura")
    protected IDFacturaConsulta2Type idFactura;
    @XmlElement(name = "Contraparte")
    protected ContraparteConsultaType contraparte;
    @XmlElement(name = "FechaPresentacion")
    protected RangoFechaPresentacionType fechaPresentacion;
    @XmlElement(name = "FechaCuadre")
    protected RangoFechaPresentacionType fechaCuadre;
    @XmlElement(name = "FacturaModificada")
    @XmlSchemaType(name = "string")
    protected FacturaModificadaType facturaModificada;
    @XmlElement(name = "EstadoCuadre")
    protected String estadoCuadre;
    @XmlElement(name = "ClavePaginacion")
    protected IDFacturaExpedidaBCType clavePaginacion;

    /**
     * Gets the value of the idFactura property.
     * 
     * @return
     *     possible object is
     *     {@link IDFacturaConsulta2Type }
     *     
     */
    public IDFacturaConsulta2Type getIDFactura() {
        return idFactura;
    }

    /**
     * Sets the value of the idFactura property.
     * 
     * @param value
     *     allowed object is
     *     {@link IDFacturaConsulta2Type }
     *     
     */
    public void setIDFactura(IDFacturaConsulta2Type value) {
        this.idFactura = value;
    }

    /**
     * Gets the value of the contraparte property.
     * 
     * @return
     *     possible object is
     *     {@link ContraparteConsultaType }
     *     
     */
    public ContraparteConsultaType getContraparte() {
        return contraparte;
    }

    /**
     * Sets the value of the contraparte property.
     * 
     * @param value
     *     allowed object is
     *     {@link ContraparteConsultaType }
     *     
     */
    public void setContraparte(ContraparteConsultaType value) {
        this.contraparte = value;
    }

    /**
     * Gets the value of the fechaPresentacion property.
     * 
     * @return
     *     possible object is
     *     {@link RangoFechaPresentacionType }
     *     
     */
    public RangoFechaPresentacionType getFechaPresentacion() {
        return fechaPresentacion;
    }

    /**
     * Sets the value of the fechaPresentacion property.
     * 
     * @param value
     *     allowed object is
     *     {@link RangoFechaPresentacionType }
     *     
     */
    public void setFechaPresentacion(RangoFechaPresentacionType value) {
        this.fechaPresentacion = value;
    }

    /**
     * Gets the value of the fechaCuadre property.
     * 
     * @return
     *     possible object is
     *     {@link RangoFechaPresentacionType }
     *     
     */
    public RangoFechaPresentacionType getFechaCuadre() {
        return fechaCuadre;
    }

    /**
     * Sets the value of the fechaCuadre property.
     * 
     * @param value
     *     allowed object is
     *     {@link RangoFechaPresentacionType }
     *     
     */
    public void setFechaCuadre(RangoFechaPresentacionType value) {
        this.fechaCuadre = value;
    }

    /**
     * Gets the value of the facturaModificada property.
     * 
     * @return
     *     possible object is
     *     {@link FacturaModificadaType }
     *     
     */
    public FacturaModificadaType getFacturaModificada() {
        return facturaModificada;
    }

    /**
     * Sets the value of the facturaModificada property.
     * 
     * @param value
     *     allowed object is
     *     {@link FacturaModificadaType }
     *     
     */
    public void setFacturaModificada(FacturaModificadaType value) {
        this.facturaModificada = value;
    }

    /**
     * Gets the value of the estadoCuadre property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEstadoCuadre() {
        return estadoCuadre;
    }

    /**
     * Sets the value of the estadoCuadre property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEstadoCuadre(String value) {
        this.estadoCuadre = value;
    }

    /**
     * Gets the value of the clavePaginacion property.
     * 
     * @return
     *     possible object is
     *     {@link IDFacturaExpedidaBCType }
     *     
     */
    public IDFacturaExpedidaBCType getClavePaginacion() {
        return clavePaginacion;
    }

    /**
     * Sets the value of the clavePaginacion property.
     * 
     * @param value
     *     allowed object is
     *     {@link IDFacturaExpedidaBCType }
     *     
     */
    public void setClavePaginacion(IDFacturaExpedidaBCType value) {
        this.clavePaginacion = value;
    }

}
