/*
 * Copyright  1999-2004 The Apache Software Foundation.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 *  This file has been modified by Ministerio de Industria, Energ�a y Turismo 
*/
package adsi.org.apache.xml.security.keys.keyresolver.implementations;

import java.security.Key;
import java.security.PublicKey;
import java.security.cert.X509Certificate;

import javax.crypto.SecretKey;

import org.w3c.dom.Element;

import adsi.org.apache.xml.security.encryption.EncryptedKey;
import adsi.org.apache.xml.security.encryption.XMLCipher;
import adsi.org.apache.xml.security.keys.keyresolver.KeyResolverSpi;
import adsi.org.apache.xml.security.keys.storage.StorageResolver;
import adsi.org.apache.xml.security.utils.EncryptionConstants;
import adsi.org.apache.xml.security.utils.XMLUtils;


/**
 * The <code>EncryptedKeyResolver</code> is not a generic resolver.  It can 
 * only be for specific instantiations, as the key being unwrapped will 
 * always be of a particular type and will always have been wrapped by 
 * another key which needs to be recursively resolved.
 *
 * The <code>EncryptedKeyResolver</code> can therefore only be instantiated
 * with an algorithm.  It can also be instantiated with a key (the KEK) or 
 * will search the static KeyResolvers to find the appropriate key.
 *
 * @author Berin Lautenbach
 */

public class EncryptedKeyResolver extends KeyResolverSpi {

	/** {@link org.apache.commons.logging} logging facility */
    static org.apache.commons.logging.Log log = 
        org.apache.commons.logging.LogFactory.getLog(
                        RSAKeyValueResolver.class.getName());

		
	Key _kek;
	String _algorithm;

	/**
	 * Constructor for use when a KEK needs to be derived from a KeyInfo
	 * list
	 * @param algorithm
	 */
	public EncryptedKeyResolver(String algorithm) {		
		_kek = null;
        _algorithm=algorithm;
	}

	/**
	 * Constructor used for when a KEK has been set
	 * @param algorithm
	 * @param kek
	 */

	public EncryptedKeyResolver(String algorithm, Key kek) {		
		_algorithm = algorithm;
		_kek = kek;

	}
	
    /** @inheritDoc */
   public PublicKey engineLookupAndResolvePublicKey(
           Element element, String BaseURI, StorageResolver storage) {

	   return null;
   }

   /** @inheritDoc */
   public X509Certificate engineLookupResolveX509Certificate(
           Element element, String BaseURI, StorageResolver storage) {
      return null;
   }

   /** @inheritDoc */
   public javax.crypto.SecretKey engineLookupAndResolveSecretKey(
           Element element, String BaseURI, StorageResolver storage) {
	   SecretKey key=null;
	   if (log.isDebugEnabled())
		  	log.debug("EncryptedKeyResolver - Can I resolve " + element.getTagName());

	      if (element == null) {
	         return null;
	      }

	      boolean isEncryptedKey = XMLUtils.elementIsInEncryptionSpace(element,
	                              EncryptionConstants._TAG_ENCRYPTEDKEY);

	      if (isEncryptedKey) {
			  log.debug("Passed an Encrypted Key");
			  try {
				  XMLCipher cipher = XMLCipher.getInstance();
				  cipher.init(XMLCipher.UNWRAP_MODE, _kek);
				  EncryptedKey ek = cipher.loadEncryptedKey(element);
				  key = (SecretKey) cipher.decryptKey(ek, _algorithm);
			  }
			  catch (Exception e) {}
	      }
		  	      
      return key;
   }
}
