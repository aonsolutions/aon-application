/*
 * Copyright  1999-2004 The Apache Software Foundation.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 *  This file has been modified by Ministerio de Industria, Energ�a y Turismo 
*/
package adsi.org.apache.xml.security.keys.content.x509;

import java.math.BigInteger;
import java.security.cert.X509Certificate;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import adsi.org.apache.xml.security.exceptions.XMLSecurityException;
import adsi.org.apache.xml.security.utils.Constants;
import adsi.org.apache.xml.security.utils.RFC2253Parser;
import adsi.org.apache.xml.security.utils.SignatureElementProxy;
import adsi.org.apache.xml.security.utils.XMLUtils;

/**
 *
 * @author $Author: mullan $
 */
public class XMLX509IssuerSerial extends SignatureElementProxy
        implements XMLX509DataContent {

    /** {@link org.apache.commons.logging} logging facility */
    static org.apache.commons.logging.Log log = 
        org.apache.commons.logging.LogFactory.getLog(
                    XMLX509IssuerSerial.class.getName());

    /**
     * Constructor XMLX509IssuerSerial
     *
     * @param element
     * @param baseURI
     * @throws XMLSecurityException
     */
    public XMLX509IssuerSerial(Element element, String baseURI)
           throws XMLSecurityException {
        super(element, baseURI);
    }

    /**
     * Constructor XMLX509IssuerSerial
     *
     * @param doc
     * @param x509IssuerName
     * @param x509SerialNumber
     */
    public XMLX509IssuerSerial(Document doc, String x509IssuerName,
                               BigInteger x509SerialNumber) {

        super(doc);
        XMLUtils.addReturnToElement(this._constructionElement);
        addTextElement(x509IssuerName, Constants._TAG_X509ISSUERNAME);
        addTextElement(x509SerialNumber.toString(), Constants._TAG_X509SERIALNUMBER);
    }

    /**
     * Constructor XMLX509IssuerSerial
     *
     * @param doc
     * @param x509IssuerName
     * @param x509SerialNumber
     */
    public XMLX509IssuerSerial(Document doc, String x509IssuerName,
                               String x509SerialNumber) {
        this(doc, x509IssuerName, new BigInteger(x509SerialNumber));
    }

    /**
     * Constructor XMLX509IssuerSerial
     *
     * @param doc
     * @param x509IssuerName
     * @param x509SerialNumber
     */
    public XMLX509IssuerSerial(Document doc, String x509IssuerName,
                               int x509SerialNumber) {
        this(doc, x509IssuerName,
             new BigInteger(Integer.toString(x509SerialNumber)));
    }

    /**
     * Constructor XMLX509IssuerSerial
     *
     * @param doc
     * @param x509certificate
     */
    public XMLX509IssuerSerial(Document doc, X509Certificate x509certificate) {

        this(doc,
             RFC2253Parser.normalize(x509certificate.getIssuerDN().getName()),
             x509certificate.getSerialNumber());
    }

    /**
     * Method getSerialNumber
     *
     * @return the serial number
     */
    public BigInteger getSerialNumber() {

        String text = this.getTextFromChildElement
	    (Constants._TAG_X509SERIALNUMBER, Constants.SignatureSpecNS);
        if (log.isDebugEnabled())
      	    log.debug("X509SerialNumber text: " + text);

        return new BigInteger(text);
    }

    /**
     * Method getSerialNumberInteger
     *
     * @return the serial number as plain int
     */
    public int getSerialNumberInteger() {
        return this.getSerialNumber().intValue();
    }

    /**
     * Method getIssuerName
     *
     * @return the issuer name
     */
    public String getIssuerName()  {

        return RFC2253Parser
           .normalize(this
              .getTextFromChildElement(Constants._TAG_X509ISSUERNAME,
                                       Constants.SignatureSpecNS));
    }

    /** @inheritDoc */
    public boolean equals(Object obj) {

	if (obj == null) {
	    return false;
	}
        if (!this.getClass().getName().equals(obj.getClass().getName())) {
            return false;
        }

        XMLX509IssuerSerial other = (XMLX509IssuerSerial) obj;

        return this.getSerialNumber().equals(other.getSerialNumber())
               && this.getIssuerName().equals(other.getIssuerName());
    }

    public int hashCode() {
	// uncomment when JDK 1.4 is required
	// assert false : "hashCode not designed";
	return 82;
    }

    /** @inheritDoc */
    public String getBaseLocalName() {
        return Constants._TAG_X509ISSUERSERIAL;
    }
}
